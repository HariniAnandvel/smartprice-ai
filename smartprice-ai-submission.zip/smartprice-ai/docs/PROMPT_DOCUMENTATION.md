---
title: "Prompt Documentation — SmartPrice AI Ultra"
subtitle: "AI Growth & Automation Associate (Work From Home) — Assessment Submission"
author: "Harini A"
date: "26 October 2026"
---

# How to read this document (honesty note)

Every prompt below is labelled with one of three tags:

- **VERBATIM** — copied exactly from the conversation with the AI assistant.
- **EXCERPT** — only part of the prompt was available in the conversation; the available part is copied exactly and the rest is stated as unavailable.
- **NOT AVAILABLE / RECONSTRUCTED** — the prompt text is not in the conversation; only the assistant's summary of it survives. These are described, never presented as original prompts.

Facts about results come from the assistant's recorded tool output in the conversation (tests, builds, commands) or from the project files. Where something was **not** verified, it says so in the Testing section.

**Scope note.** The submission project is **SmartPrice AI Ultra** (Parts 1–9). The same conversation also contains an earlier, separate prototype, **FutureFork AI** (a decision simulator); it is summarised in Appendix B so the record of the conversation is complete.

# 1. Project Overview

| Item | Details |
|---|---|
| **Project name** | SmartPrice AI Ultra |
| **Type** | Full-stack web application (React + FastAPI) |
| **Problem statement** | Sellers, analysts and shoppers often hold price data in spreadsheets or on competitor web pages, but turning it into trustworthy insight is slow and error-prone: column names differ between files, prices are malformed, history is missing, and tools often show a filename or a "success" message without really analysing anything. |
| **Target users** | Small online sellers, growth/pricing analysts and e-commerce operations teams who need to compare prices, spot unusual prices and track changes without building their own tooling. *(Inferred from the project's README and UI; adjust if your video describes the users differently.)* |
| **Solution** | The user uploads a CSV/XLSX/XLS file (or collects a public product page). The backend validates and parses the real contents, detects columns, normalises prices, saves the data as a **dataset**, and runs a real analysis (statistics, competitor gaps, price history, outliers, data-quality warnings). Every page then reads from the selected dataset. Alerts, CSV/PDF reports and an optional AI Q&A layer build on the same data. |
| **Automation value** | Replaces manual spreadsheet cleaning and comparison with an automated pipeline: ingest → validate → map → analyse → alert → report. |

# 2. AI Tools Used

| Tool | Purpose | Evidence |
|---|---|---|
| **Claude (Anthropic) via the claude.ai chat interface** | Generated the application code, tests, documentation and demo data; diagnosed bugs; ran commands and tests in its sandbox. This conversation was handled by Claude Sonnet 5.5. The model used in the earlier SmartPrice build sessions was not recorded in the conversation. | Entire conversation |
| **Claude's code-execution sandbox (bash, file creation)** | Installed dependencies, ran `pytest`, `vitest`, `tsc`, the production build, and a live API run; created the downloadable zip files. | Tool output in the conversation |
| **Optional LLM adapter inside the app** (`backend/app/services/llm.py`) | Answers product questions only if `LLM_API_KEY` is configured; otherwise a clearly labelled deterministic fallback is used. | **Not tested against a live provider** |

No other AI tool is claimed. (Standard engineering tools — FastAPI, pandas, React, Vite, pytest, Vitest — are libraries used in the project, not AI tools.)

# 3. Original Prompts

These are the prompts that started each stage of the SmartPrice project. Full text of the large ones is in the appendices.

## Prompt 1 — Project specification  *(EXCERPT)*

**Original prompt (available part, verbatim):**

~~~text
# PROJECT: SmartPrice AI Ultra — Premium 3D Web Intelligence Platform Act as a world-class UI/UX designer, senior React engineer, Python backend architect, data intelligence engineer, and 3D motion designer. Build a complete, production-minded, full-stack web application named **SmartPrice AI
~~~

*The conversation preserves only this opening of the specification (the pasted text was cut off). The rest is not available and is not reproduced here.*

**Purpose:** Define the product — a premium, full-stack, 3D-styled price-intelligence platform — and set the assistant's roles (designer, React engineer, Python architect, data engineer, motion designer).

**Result obtained** *(from the assistant's progress log in the conversation)*: Stage 1 produced a FastAPI backend only: authentication (bcrypt + JWT), a URL collector with private-address blocking and robots.txt checks, CSV import, a demo-data seeder, price analytics, alerts, and CSV reports. The log states the code and tests had **not been run** at that point.

**Improvement made:** — (first prompt)

## Prompt 2 — Completeness demand  *(VERBATIM)*

**Original prompt:**

~~~text
the React frontend, with the 3D scene and transitions
PDF reports
the LLM adapter
alert edit/toggle
the Competitors, Reports and AuditEvents tables
settings and password update
why these are not yet build i want everything bro what happen
~~~

**Purpose:** Challenge the assistant for leaving features out of Stage 1 and require the full scope.

**Result obtained** *(from the progress log)*: Stage 2 added alert edit/toggle, in-app notifications, Competitors / Notifications / Reports / AuditEvents tables, an insights question endpoint with LLM-or-deterministic fallback, PDF reports, and settings (profile, preferences, password change, data wipe). A later stage added the React frontend (landing page with 3D hero, login/register, dashboard, trends, competitors, insights, alerts, reports, settings) and tests; the log reports 6 backend tests and 4 frontend tests passing, a clean type-check and a successful production build.

**Improvement made:** The prompt turned a minimal first pass into a full-scope build and led the assistant to actually run tests ("this time I ran everything").

## Prompt 3 — Follow-up that produced the final polish  *(NOT AVAILABLE)*

The progress log shows a further round (simplified-animation setting applied immediately, Dark/Light glass appearance, in-page search). The user prompt that triggered it is **not present** in the conversation, so it is not reproduced.

# 4. Prompt Iterations

## Prompt 4 — Running the project  *(VERBATIM)*

**Original prompt:** `just say how to run it`

**Purpose:** Get beginner-friendly run steps for the backend and frontend.

**Result obtained:** Step-by-step Windows commands (virtual environment, `pip install`, `uvicorn`, `npm install`, `npm run dev`) with a troubleshooting list. The assistant stated the folder names were assumed because the project files had not yet been seen.

**Improvement made:** The assistant was explicit about what it was inferring from the log.

## Prompt 5 — Debugging input (terminal output)  *(EXCERPT)*

**Original prompt (available part, verbatim):**

~~~text
Using cached six-1.17.0-py2.py3-none-any.whl (11 kB)
Collecting dnspython>=2.0.0
  Downloading dnspython-2.8.0-py3-none-any.whl (331 kB)
...
Installing collected packages: pytz, passlib, websockets, ... fastapi
~~~

**Purpose:** Ask, implicitly, whether the installation was working.

**Result obtained:** The assistant explained the output was normal (still installing), told the user to wait for "Successfully installed", and gave the next commands.

**Improvement made:** Clear success criteria for each step.

## Prompt 6 — Screenshots of the running API  *(NO TEXT)*

Two screenshots of the FastAPI `/docs` page showing alerts, reports, notifications, competitors, insights, settings, audit, collect-history and health endpoints.

**Purpose:** Show the backend was running.

**Result obtained:** The assistant confirmed from the visible endpoint list that the backend was up and directed the user to open the React frontend.

## Prompt 7 — Demo data and documentation request  *(VERBATIM)*

**Original prompt:**

~~~text
need demo data to upload in this and also need entire project documentation and the full prompt of this conversation about this project
~~~

**Purpose:** Obtain sample data to try the CSV import, project documentation and the project prompt.

**Result obtained:** A synthetic CSV (4 products × 3 sellers × 30 days = 360 rows, including one deliberate price drop and one blank price), a documentation file and a **reconstructed** project prompt (labelled as reconstructed because the original specification was incomplete).

**Improvement made / problem exposed:** The CSV used a `product_name` column, which the original importer did not understand — this exposed the upload bug fixed in Prompt 8.

## Prompt 8 — Repair and upgrade  *(VERBATIM — full text in Appendix A)*

**Original prompt (opening):**

~~~text
# SMARTPRICE AI ULTRA — FULL FUNCTIONALITY REPAIR + PREMIUM UI OVERHAUL
Act as a senior full-stack engineer, React UI/UX specialist, data intelligence engineer, debugging expert, and advanced motion designer.
This is an existing project for a job assessment. Your task is to inspect, debug, repair, and upgrade the actual application. […]
CRITICAL: Do not merely change the CSS, display an uploaded filename, generate fake analysis results, or create a static design mockup. Trace the real execution path, fix the underlying problems, implement missing functionality, and test the results.
~~~

**Purpose:** Fix the real problem (an upload that only displayed a filename), connect the entire application to uploaded data, improve the design and transitions, and require testing without fake success.

**Result obtained:** The assistant inspected the real code and found five root causes (see Section 7), then built the upload → analysis → dataset pipeline, dataset-driven dashboard, page transitions, and 26 new backend tests and 12 new frontend tests (one outdated dashboard test was replaced).

**Improvement made:** This was the decisive prompt. It forced a **root-cause-first** approach and banned fake results; the earlier build had shown a filename and a toast while processing nothing.

## Prompt 9 — Running the fixed project  *(VERBATIM)*

**Original prompt:** `how to run`

**Result obtained:** Two-window run steps for `smartprice-ai-fixed.zip`, the upload walkthrough using `sample-data/smartprice_demo_data.csv`, and troubleshooting.

## Prompt 10 — Submission preparation  *(SUMMARISED, not reproduced)*

The request for prompt documentation, a submission link and a final checklist. It produced this document, the README, deployment files, `SUBMISSION_GUIDE.md` and `SUBMISSION_CHECKLIST.md`.

# 5. Prompt Engineering Process

| Stage | What the prompt looked like | What it produced | Why it changed |
|---|---|---|---|
| 1. Vision prompt | Role-based, feature-rich product specification (Prompt 1) | A backend-only first pass, unverified | Too large for one pass; no verification requirement |
| 2. Completeness pressure | Short, blunt list of missing features (Prompt 2) | Remaining backend features, then the frontend, then tests | Naming exact gaps made the assistant close them |
| 3. Practical prompts | Single-line requests with real output attached (Prompts 4–7) | Run steps, interpretation of terminal output and screenshots | Showing real output let the assistant give accurate next steps |
| 4. Repair prompt | Phased, root-cause-first, explicit prohibitions ("do not fake"), required verification and honest reporting (Prompt 8) | Real diagnosis, working pipeline, tests, honest limitations | Constraints targeted the exact failure mode |

**Key prompt-engineering lessons from this project**

1. **Prohibit the failure mode explicitly.** "Do not merely … display an uploaded filename … generate fake analysis results" led the assistant to trace the real code path instead of restyling the page.
2. **Demand evidence.** "Never claim success without verification" and "report which tests were actually executed" produced a Testing record that separates executed from unverified work.
3. **Phase the work.** Phases (audit → fix pipeline → connect app → design → verify) kept the highest-priority bug first.
4. **Attach real artefacts.** Terminal output, screenshots and the actual zip file allowed diagnosis from facts rather than guesses.
5. **Specify honesty rules for the product itself.** Rules such as "do not invent missing prices, timestamps or currencies" became real behaviour (missing prices stay *unavailable*, missing dates are flagged *inferred*, demo data is labelled).

# 6. Implementation — How the Prompts Became Code

| Prompt requirement | Implementation (files) |
|---|---|
| Real file upload, validation, formats | `backend/app/services/ingest.py` (extension + signature + size checks; CSV/XLSX/XLS), `backend/app/api/datasets.py` |
| Intelligent column mapping with confidence | `ingest.detect_mapping` (synonyms + fuzzy match, ambiguity flags); mapping review UI in `frontend/src/pages/Upload.tsx` |
| Real analysis engine | `backend/app/services/dataset_analysis.py` (pandas: statistics, cross-source gaps, distribution, IQR outliers, trends only with dated history, insights) |
| Persisted datasets and history | `Dataset` model, `GET /api/datasets`, `migrate_schema()` in `backend/app/core/db.py` |
| One data flow through the whole app | `frontend/src/components/datasets.tsx` (dataset context); all pages scoped with `?dataset_id=` |
| Upload states, progress, cancel, success only after backend confirms | `Upload.tsx` and `uploadForm()` in `frontend/src/services/api.ts` (XHR progress + AbortController) |
| Unreachable backend explained | `ApiError` with status 0 in `api.ts` |
| Smooth page transitions | `frontend/src/layouts/AppLayout.tsx` (`AnimatePresence`, keyed outlet, `Suspense` inside the layout) |
| Distinctive upload UI | CSS-3D tilting data-sheet illustration; animated success mark (only after backend success) |
| Demo data labelled | `DEMO DATA` badge; idempotent demo seeding |
| Tests | `backend/app/tests/*`, `frontend/src/test/*` |

# 7. Challenges and Solutions (real issues from this conversation)

| # | Issue | How it was found | Resolution |
|---|---|---|---|
| 1 | Upload only displayed a filename / toast; nothing analysed | Reading `Scrape.tsx` and `routes.py` | Built the dataset pipeline (Section 6) |
| 2 | Importer accepted only columns named exactly `name`, `source`, `price`; every other header made all rows fail silently | Reading `/import/csv`; reproduced with the demo CSV (`product_name`) | Column detection + mapping step + per-row rejection reasons |
| 3 | Files over 2 MB were silently truncated; re-importing a file crashed with a database uniqueness error | Code inspection | Explicit size limit with clear error; SHA-256 duplicate detection (HTTP 409); removed fragile uniqueness constraint |
| 4 | No dataset concept: dashboard showed only the first product | Reading `Dashboard.tsx` | Dataset model, history, selection and scoped endpoints |
| 5 | Page exit animations never ran between app pages (constant route key; a lazy page could blank the layout) | Reading `App.tsx` | Keyed `AnimatePresence` inside `AppLayout`, `Suspense` inside the layout |
| 6 | Database migration crashed on an old database (index list read after the table was renamed) | Test run on the old-schema database created by the baseline run | Read indexes first |
| 7 | SQLite DDL is not transactional, so a failed migration left a half-migrated database (old table renamed, new table empty) | Test re-run | Migration made resumable and idempotent; data verified preserved |
| 8 | Copying old rows failed because the new `date_inferred` column was NOT NULL | Migration unit test | Added a server default |
| 9 | A test helper wrote CSV without quoting, so `₹1,299.50` split into two columns | Failing test analysed | Switched the helper to Python's `csv` writer (a test bug, not an app bug) |
| 10 | An insight compared mean and median across different products, which is misleading | Reviewing the live API output | Restricted to single-product datasets |
| 11 | `pip install` refused on the system Python (externally managed environment) | Command output | Used a virtual environment |
| 12 | *(Earlier prototype)* a shell command created a literal `{futurefork,tests,…}` folder because the shell had no brace expansion | Command output | Removed it and created folders explicitly |
| 13 | *(Earlier prototype)* the sample report listed the optimistic scenario's adjusted inputs as "user-supplied" | Reading the generated report | Fixed; regression test added |

# 8. Final Outcome

**Completed features (verified in code):**

- Authentication (register, login, current user) with hashed passwords and JWT.
- CSV / XLSX / XLS upload with content validation, column mapping, preview, progress, cancel and retry.
- Persisted datasets, upload history that survives a refresh, dataset switching and deletion, duplicate-file detection.
- Real analysis: counts, mean / median / min / max / standard deviation, per-product and cross-source price gaps, price distribution, IQR outliers (method stated), trends only when dated history exists, data-quality warnings, deterministic insights.
- Dashboard, trends, competitors, insights, alerts (create / edit / toggle / delete; in-app notifications only), CSV and PDF reports, settings (profile, theme, simplified motion, password change, data wipe) and an audit log.
- URL collection from public pages (structured data only), blocking private/internal addresses and respecting robots.txt.
- Demo data clearly labelled **DEMO DATA**.

**How it works:** file → backend validation → parsing → mapping → normalisation → saved dataset → analysis API → React state → dashboard and reports.

**Value:** it turns messy price files into trustworthy, explainable insight automatically, and it tells the user honestly when the data is insufficient (for example, no trend without dated history).

# 9. Testing

All results below were produced by commands run during this conversation. Final re-run on 26 October 2026 before packaging.

| Test | Result |
|---|---|
| Backend unit and integration tests (`pytest`) | **32 passed.** Covers: valid CSV, XLSX and XLS upload; invalid / empty / corrupted / renamed files; size limit; missing required fields; ambiguous mapping; malformed prices, missing values and duplicates; persistence and retrieval by dataset id; dataset switching; analysis calculations and outliers; "no history" honesty; authentication required on the dataset endpoints; cross-user isolation; alerts firing on uploaded data; schema migration; production secret guard |
| Frontend tests (`vitest`) | **15 passed.** Covers: file sent to the backend with the mapping; success shown only after the backend responds; unsupported type rejected without a request; backend-unreachable message; ambiguous mapping needs confirmation; duplicate-file warning; cancel; dashboard showing the selected dataset and refreshing on switch; empty and no-history states; DEMO DATA label; sidebar navigation; structured API errors |
| Type check (`tsc --noEmit`) and production build (`npm run build`) | Clean / successful |
| Live API run (real server, real HTTP) with the earlier demo CSV | 360 rows read, 359 valid, 1 price treated as unavailable, 4 products, planted price drop flagged, re-upload rejected (HTTP 409), `.exe` rejected (HTTP 415) |
| Production secret guard | App refuses to start with `ENVIRONMENT=production` and the default `SECRET_KEY`; starts and answers `/api/health` with a real key |
| Publish check | A throw-away git repository confirmed `.env`, `*.db`, `node_modules`, `dist` and virtual environments are excluded and no secret strings are tracked |
| Baseline before changes | 6 backend and 4 frontend tests passed on the original project |

**Remaining limitations (not verified or not done):**

- The application has **not been opened in a real browser by the assistant**: the 3D landing hero, glass styling, responsive layouts at tablet/mobile sizes and the transitions are untested visually. Frontend tests run in jsdom only.
- The wider visual redesign is partial (Upload and Dashboard pages, layout transitions, counters, dropzone visual); the landing page, Alerts, Settings and Reports styling and a full responsive audit are untouched.
- No live LLM provider test; no live-site collection test; email/push notifications are not implemented.
- PDF upload is unsupported; Excel files read the first sheet only; the auth token is stored in `localStorage` (use HTTP-only cookies in production).
- Deployment has **not** been performed by the assistant; no live URL exists unless you create one (see `SUBMISSION_GUIDE.md`).

# Appendix A — Prompt 8 in full (VERBATIM)

~~~text
# SMARTPRICE AI ULTRA — FULL FUNCTIONALITY REPAIR + PREMIUM UI OVERHAUL

Act as a senior full-stack engineer, React UI/UX specialist, data intelligence engineer, debugging expert, and advanced motion designer.

This is an existing project for a job assessment. Your task is to inspect, debug, repair, and upgrade the actual application. Preserve existing useful functionality, project structure, and working integrations.

The objective is to deliver a genuinely functional data intelligence platform with a premium, futuristic, 3D glassmorphism interface and exceptionally smooth navigation.

CRITICAL: Do not merely change the CSS, display an uploaded filename, generate fake analysis results, or create a static design mockup. Trace the real execution path, fix the underlying problems, implement missing functionality, and test the results.

## PHASE 1 — AUDIT THE EXISTING PROJECT

Before modifying anything:

1. Inspect the complete frontend and backend structure.
2. Identify the framework, routing, upload components, API endpoints, database models, data-processing functions, chart components, and animation libraries already in use.
3. Trace the entire upload process from the file input to the backend, data parser, analysis service, database, and rendered results.
4. Check browser console errors, network requests, server logs, failed API calls, incorrect response formats, and missing dependencies.
5. Identify why uploading a file currently shows only its filename without actually analysing the file or linking the results to the dashboard.
6. Create a concise list of root causes and implement fixes.

Do not assume that the frontend, backend, or database is responsible until the actual code has been inspected.

Do not overwrite the project or delete working modules. Make focused changes and explain important modifications.

## PHASE 2 — FIX FILE UPLOAD AND REAL DATA ANALYSIS

This is the highest-priority requirement.

The upload workflow must process the actual file contents. Selecting a file and displaying its name does not count as successful processing.

### Supported input

Support the file formats appropriate to the existing application, preferably:
- CSV
- XLSX
- XLS

Add PDF support only if it is relevant to the application's data-extraction requirements and can be implemented reliably.

Implement:
- File type and extension validation.
- MIME-type and file-signature checks where applicable.
- Configurable file-size limits.
- Clear validation messages.
- Duplicate-upload handling.
- Upload progress and processing status.
- Cancellation where feasible.
- Safe handling of malformed files and empty datasets.

Never trust the filename or extension alone.

### Required processing pipeline

Implement and verify this complete sequence:

1. User selects or drags a file into the upload area.
2. The frontend uploads the actual file bytes to the correct backend endpoint using multipart/form-data.
3. The backend receives and validates the file.
4. The backend parses the actual contents using appropriate libraries such as pandas, openpyxl, or xlrd where necessary.
5. The application detects column names, data types, row count, missing values, duplicate records, and potential data-quality issues.
6. The application identifies relevant fields such as product name, price, currency, source, category, rating, and timestamp when present.
7. The user can review a preview of the parsed data and correct column mappings when automatic detection is uncertain.
8. The backend normalizes the data and runs real analysis.
9. The processed dataset and its analysis metadata are persisted in the existing database.
10. The frontend receives a structured response containing the dataset ID, actual row counts, column information, validation results, and analysis status.
11. The frontend fetches the saved analysis using the returned dataset ID.
12. Dashboard cards, charts, product tables, competitor comparisons, and insights update using that dataset.
13. The uploaded dataset remains available after a page refresh and can be selected again from upload history.

Use the existing backend framework and architecture. If it is FastAPI, implement a correct multipart upload endpoint and connect it to the actual processing service.

Do not parse a file in the browser and then pretend the backend has analysed it. Keep the backend authoritative for validation, persistence, and analysis.

### Intelligent column mapping

Do not assume every uploaded file has the same column names.

Recognize reasonable variations such as:
- product, product_name, item, item_name
- price, selling_price, current_price, amount
- brand, manufacturer, seller
- rating, review_score
- category, product_category
- date, timestamp, observed_at
- source, website, store

Use configurable mapping rules and confidence indicators. Ask the user to map ambiguous columns rather than guessing silently.

Do not invent missing prices, timestamps, currencies, ratings, or historical observations.

### Real analysis engine

Implement useful analyses based on the fields that actually exist:

- Total valid records and unique products.
- Average, median, minimum, and maximum price.
- Missing and duplicate record counts.
- Product-level price comparisons.
- Price distributions and category summaries when applicable.
- Historical trends only when valid historical observations exist.
- Percentage price changes only when a legitimate comparison baseline exists.
- Outlier detection with an explanation of the selected method.
- Data-quality warnings.
- Actionable insights supported by actual calculations.

For insufficient data, show an honest message explaining what additional data is needed.

For example, a single row may support a product count and a price value, but it cannot establish a historical price trend.

Use pandas and appropriate statistical methods. Do not generate random chart data or hardcode successful analysis results.

### Upload interface states

Create clear, polished states for:
- Idle.
- Dragging a file.
- Uploading.
- Validating.
- Reading file contents.
- Mapping columns.
- Analysing.
- Saving results.
- Completed successfully.
- Partially processed.
- Failed.
- Cancelled.

Display real progress when the underlying process can measure it. Do not invent percentage progress.

Include a data preview table, validation summary, processing log, retry option, and a link to the generated analysis.

If the backend is unreachable, explain the connection problem instead of showing fake success.

## PHASE 3 — CONNECT THE ENTIRE APPLICATION

Uploading data must have a visible, meaningful effect throughout the application.

Establish one consistent data flow:

Uploaded file → Backend processing → Persisted dataset → Analysis service → API response → React state/query cache → Dashboard and charts.

Requirements:

- Return and preserve a stable dataset ID.
- Associate every analysis result with its dataset ID.
- Fetch actual records from the backend.
- Invalidate or refresh relevant queries after successful uploads.
- Avoid stale charts and disconnected frontend state.
- Ensure that a newly uploaded dataset can be selected in analytics and reports.
- Display the selected dataset and its processing status.
- Support dataset switching.
- Handle deleted, failed, or inaccessible datasets gracefully.
- Preserve the user's selected dataset when navigating between related pages, where appropriate.

Use the existing state-management approach if it is sound. Otherwise, introduce a suitable, maintainable solution.

All dashboard metrics and charts must correspond to the selected dataset or clearly documented live data source.

Label sample data as DEMO DATA. Never mix sample data and real uploaded records without explicitly identifying them.

## PHASE 4 — PREMIUM REACT DESIGN OVERHAUL

Create a sophisticated, coherent, high-end SaaS design.

Visual direction:
- Deep midnight blue and navy backgrounds.
- Electric blue and cyan lighting.
- Violet and magenta accent gradients.
- Realistic translucent glass cards.
- Layered depth, restrained bloom, soft reflections, and luminous borders.
- Elegant typography and excellent visual hierarchy.
- Premium spacing and consistent component dimensions.
- High-quality charts and beautifully designed empty states.

Avoid generic templates, crowded cards, inconsistent margins, oversized headings, random colors, excessive glow, and unreadable translucent text.

### Layout precision

Audit every page at desktop, tablet, and mobile sizes.

Use a consistent spacing scale, grid system, typography scale, border radius, shadows, and reusable design tokens.

Ensure:
- Headings align consistently.
- Sidebar and top navigation remain stable.
- Cards have balanced padding and consistent heights where appropriate.
- Chart labels do not overlap.
- Tables remain readable.
- Forms have consistent widths and alignment.
- Buttons have consistent heights and interaction states.
- Long text wraps naturally.
- No horizontal overflow or unintended layout shifts.
- Responsive layouts reorganize intelligently instead of simply shrinking everything.

Use proper loading skeletons, meaningful empty states, and clear validation feedback.

## PHASE 5 — ADVANCED 3D VISUAL EXPERIENCE

Use the existing compatible animation and 3D stack where possible.

Preferred tools:
- React Three Fiber and Three.js for selected 3D scenes.
- Drei for useful 3D helpers.
- Framer Motion for UI and route animations.
- CSS transforms, perspective, gradients, and backdrop filters for lightweight glass effects.

Create:
- A beautiful 3D landing-page hero with floating data elements.
- A subtle animated AI assistant or holographic orb.
- Elegant glass cards with layered depth.
- Pointer-responsive tilt on selected cards.
- Animated chart entrances.
- Subtle floating particles and ambient lighting.
- Refined animated icons and interactive controls.
- A visually distinctive upload dropzone with a 3D file or data illustration.
- A delightful success animation after REAL processing completes.

The upload success animation must be triggered only after the backend confirms that processing and persistence succeeded.

Keep the 3D effects purposeful, premium, and restrained. Do not make the entire application a heavy 3D scene.

Use lazy loading, lightweight fallbacks, and reduced-motion alternatives.

## PHASE 6 — BUTTER-SMOOTH PAGE TRANSITIONS

Inspect the existing React Router configuration and animation implementation before changing them.

Implement a consistent transition system using Framer Motion and AnimatePresence, or the equivalent already present.

Required effects:
- Smooth fade and directional slide between pages.
- Subtle scale and blur transitions.
- Coordinated exit and entrance animations.
- Shared-element transitions for appropriate matching cards.
- Staggered entrance of dashboard sections.
- Smooth sidebar expansion and collapse.
- Animated counters and chart reveals.
- Fluid modal and drawer transitions.
- Beautiful hover, press, focus, and loading feedback.
- Consistent easing and durations.
- No accidental double animations or flickering.

Technical requirements:
- Keep route keys stable and correct.
- Prevent blank flashes during navigation.
- Avoid remounting the entire dashboard unnecessarily.
- Preserve important user and dataset state.
- Do not add artificial delays before navigation.
- Keep interactive controls usable during transitions.
- Respect prefers-reduced-motion.
- Provide fallbacks for devices with limited graphics performance.

Transitions should feel continuous, polished, and responsive rather than slow or theatrical.

## PHASE 7 — DATA INTELLIGENCE FEATURES

Verify the existing functionality before adding new features.

Where applicable, implement:
- Product management.
- Data collection from permitted public sources.
- CSV/XLSX import.
- Product price history.
- Competitor comparison.
- Price trend analysis.
- Data-quality insights.
- Price alerts.
- AI-assisted recommendations.
- Downloadable CSV and PDF reports.

Use genuine calculations and persisted records.

For web collection, validate URLs, block private and internal network destinations, set timeouts, apply rate limits, and respect website terms and access restrictions.

For AI features, use the configured provider securely through the backend. If no provider key exists, use a clearly labelled deterministic analysis fallback.

Never claim that live scraping, historical tracking, notifications, or AI processing occurred when it did not.

## PHASE 8 — TESTING AND VERIFICATION

Do not stop when the code compiles.

Create and execute appropriate tests for:

1. Valid CSV upload.
2. Valid XLSX upload.
3. Invalid file type.
4. Corrupted or empty file.
5. Missing required fields.
6. Ambiguous column mapping.
7. Malformed prices and missing values.
8. Successful database persistence.
9. Retrieving a dataset by its ID.
10. Dashboard refresh after uploading.
11. Switching between datasets.
12. Correct analytical calculations.
13. API failure and retry behavior.
14. Authentication and protected routes.
15. Reports and chart data.
16. Route transitions and navigation.

Use unit tests for the parser and analysis engine, API integration tests for uploads and persistence, and frontend tests for the most important user flows.

Run the available build, lint, and test commands. Fix the failures you introduce and investigate existing failures relevant to the task.

If browser-based testing tools are available, verify the rendered application, responsive layouts, console, network requests, and the full upload workflow.

Report which tests were actually executed and which remain unverified.

## PHASE 9 — FINAL DELIVERABLE

Provide:
- A concise explanation of the original upload root cause.
- The files changed and the reason for each major change.
- The complete working implementation in the existing repository.
- Any required environment variables.
- Database initialization instructions.
- Exact frontend and backend startup commands.
- A step-by-step test procedure for uploading a real file.
- A description of implemented transitions and 3D effects.
- Known limitations and any remaining work.

Prioritize working functionality, elegant engineering, and visual quality together.

Start by inspecting the existing repository. Fix the upload-to-analysis pipeline first, then verify the end-to-end data flow, improve the design system, implement the transitions, and test the completed application.

Do not merely give me instructions, a proposed architecture, or sample snippets. Make the actual code changes wherever your environment permits. Never claim success without verification.
~~~

# Appendix B — Earlier prototype in the same conversation: FutureFork AI

*Included so the record of the conversation is complete. It is a separate project from SmartPrice AI Ultra.*

**What it is:** a decision simulator ("One decision. Multiple possible futures.") that turns a business decision into optimistic, realistic and worst-case simulations with transparent calculations.

## Prompt B1 — Master build prompt  *(EXCERPT, verbatim parts)*

~~~text
MASTER BUILD PROMPT — FUTUREFORK AI
The Decision Simulator: Explore the Futures Hidden Inside One Choice
Act as my senior AI engineer, Python developer, 3D UI/UX designer, simulation engineer, prompt engineer, software tester, and deployment mentor.
Build a complete, functional, visually extraordinary AI project called FutureFork AI.
This is a real recruitment-assessment project. I need a working application with meaningful functionality, verifiable calculations, documented AI prompts, test cases, a deployment guide, and a demo presentation.
[…]
FINAL GOAL: Deliver a real, working FutureFork AI decision-simulation application with a futuristic interactive 3D experience, transparent scenario calculations, meaningful uncertainty analysis, documented AI prompts, automated tests, and a verified deployment path.
~~~

*The full prompt (about 2,300 words, with 11 numbered sections) is in the conversation; only these parts are reproduced here.*

**Result obtained:** A Streamlit application (`futurefork/engine.py` deterministic simulation, Plotly 3D branching view, Butterfly Effect, Uncertainty Radar, Evidence panel, Experiment Planner, CSV/Markdown export), an optional validated AI interpreter with manual fallback, 33 automated tests (all passed when run), documentation and a sample report. A real bug (scenario inputs mislabelled in the report) was found and fixed during the build.

## Prompt B2 — `what should i do now`  *(VERBATIM)*
**Result:** A prioritised plan: run it locally, review it visually, learn to explain it, then deploy.

## Prompt B3 — Dissatisfaction and v2 request  *(VERBATIM)*

~~~text
just give me the prompt of this entire concept and also i am even not satsified with ouput it is like someone cant even that understand what is happen and also there asked build website but seeing that is not a company login page and other to see what happen it need to swtich automatically with smooth god level 3d transition everything need to be clear and tranparent transition but also need wonderful output need god level just click the visual of the 3d model need to speak now give me the prompt it should be ready product smooth and neat product
~~~

**Purpose:** Replace a dashboard-style result with a clear, guided, website-style product with cinematic 3D transitions and a clickable model that speaks.

**Result obtained:** A second-generation prompt (React + Three.js website with a continuous camera journey, plain-language rules, and click-to-speak narration using the browser Web Speech API). **That v2 website was not built in this conversation.**

**Improvement made:** Added plain-language requirements and a guided scene-by-scene flow to address "nobody can understand what is happening".

## Prompt B4 — `hi`  *(VERBATIM)*
**Result:** Greeting; the conversation moved on to SmartPrice AI Ultra.
