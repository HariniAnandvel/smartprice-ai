from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .core.config import settings
from .core.db import Base, engine, migrate_schema
from . import models  # noqa: F401
from .api.routes import router
from .api.routes2 import router as router2
from .api.datasets import router as router3

if settings.ENVIRONMENT == "production" and settings.SECRET_KEY in ("dev-only-change-me", "change-me", ""):
    raise RuntimeError("SECRET_KEY must be set to a long random value when ENVIRONMENT=production")
Base.metadata.create_all(engine)  # schema init; use Alembic for production migrations
migrate_schema()  # upgrades older SQLite files in place
app = FastAPI(title="SmartPrice AI Ultra")
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS.split(","),
                   allow_methods=["*"], allow_headers=["*"])
app.include_router(router)
app.include_router(router2)
app.include_router(router3)

@app.get("/api/health")
def health(): return {"ok": True}
