import pytest
from app.core.config import Settings

def test_production_refuses_default_secret(monkeypatch):
    """Importing the app in production with the default key must fail."""
    import importlib, app.main as m
    monkeypatch.setenv("ENVIRONMENT", "production"); monkeypatch.setenv("SECRET_KEY", "change-me")
    from app.core import config
    monkeypatch.setattr(config.settings, "ENVIRONMENT", "production"); monkeypatch.setattr(config.settings, "SECRET_KEY", "change-me")
    with pytest.raises(RuntimeError):
        importlib.reload(m)
    monkeypatch.setattr(config.settings, "ENVIRONMENT", "development")
    importlib.reload(m)
