import os, pathlib
# Use an isolated database for tests (must be set before the app is imported).
db = pathlib.Path("test_smartprice.db")
if db.exists():
    db.unlink()
os.environ["DATABASE_URL"] = "sqlite:///./test_smartprice.db"
