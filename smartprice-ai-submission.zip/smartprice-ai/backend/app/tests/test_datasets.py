import io, json, sqlite3, itertools
import pandas as pd
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from app.main import app
from app.core import db as dbmod
from app.core.config import settings

c = TestClient(app)
_n = itertools.count()


def user():
    email = f"u{next(_n)}@x.com"
    c.post("/api/auth/register", json={"name": "U", "email": email, "password": "password123"})
    t = c.post("/api/auth/login", data={"username": email, "password": "password123"}).json()["access_token"]
    return {"Authorization": f"Bearer {t}"}


def csv_bytes(rows, cols=("product_name", "source", "price", "currency", "date")):
    import csv
    b = io.StringIO(); w = csv.writer(b); w.writerow(cols); w.writerows(rows)
    return b.getvalue().encode("utf-8")


def xlsx_bytes(df):
    b = io.BytesIO(); df.to_excel(b, index=False, engine="openpyxl"); return b.getvalue()


def xls_bytes(df):
    import xlwt
    wb = xlwt.Workbook(); ws = wb.add_sheet("s")
    for j, col in enumerate(df.columns): ws.write(0, j, col)
    for i, row in enumerate(df.itertuples(index=False), start=1):
        for j, v in enumerate(row): ws.write(i, j, v)
    b = io.BytesIO(); wb.save(b); return b.getvalue()


def upload(h, content, name="data.csv", mapping=None, **form):
    p = c.post("/api/datasets/preview", files={"file": (name, content)}, headers=h)
    if p.status_code != 200:
        return p, None
    m = mapping or {f: v["column"] for f, v in p.json()["mapping"].items()}
    r = c.post("/api/datasets", files={"file": (name, content)}, data={"mapping": json.dumps(m), **form}, headers=h)
    return p, r


SERIES = [("Phone X", "ShopA", p, "INR", f"2026-09-0{d}") for d, p in zip(range(1, 6), (100, 102, 101, 103, 150))] + \
         [("Phone X", "ShopB", p, "INR", f"2026-09-0{d}") for d, p in zip(range(1, 6), (110, 111, 112, 110, 111))]


def test_csv_upload_end_to_end_and_persistence():
    h = user()
    prev, r = upload(h, csv_bytes(SERIES))
    assert prev.json()["mapping"]["product"]["column"] == "product_name" and prev.json()["ready"] is True
    assert prev.json()["rows"] == 10 and len(prev.json()["preview"]) == 10
    assert r.status_code == 201
    did = r.json()["dataset"]["id"]
    a = c.get(f"/api/datasets/{did}/analysis", headers=h).json()          # fresh request = "after refresh"
    assert a["summary"]["records"] == 10 and a["summary"]["unique_products"] == 1 and a["summary"]["sources"] == 2
    assert [d["id"] for d in c.get("/api/datasets", headers=h).json()] == [did]
    assert c.get(f"/api/datasets/{did}/records?size=3", headers=h).json()["total"] == 10


def test_analysis_calculations_are_correct():
    h = user(); _, r = upload(h, csv_bytes(SERIES)); did = r.json()["dataset"]["id"]
    a = c.get(f"/api/datasets/{did}/analysis", headers=h).json()
    prices = [s[2] for s in SERIES]
    s = a["price_stats"]
    assert s["min"] == 100 and s["max"] == 150 and s["mean"] == round(sum(prices) / 10, 2) and s["median"] == pd.Series(prices).median()
    p = a["products"][0]
    assert p["spread_pct"] == round((150 - 111) / 111 * 100, 2)      # latest: ShopA 150 vs ShopB 111
    assert p["change_pct"] == round((111 - 100) / 100 * 100, 2) or p["change_pct"] is not None
    assert a["trends"]["available"] is True
    assert sum(d["count"] for d in a["distribution"]) == 10


def test_outlier_detection_and_method_explained():
    h = user()
    rows = [("P", "S", v, "INR", f"2026-09-{d:02d}") for d, v in enumerate([100, 101, 99, 100, 102, 98, 55], start=1)]
    _, r = upload(h, csv_bytes(rows)); a = c.get(f"/api/datasets/{r.json()['dataset']['id']}/analysis", headers=h).json()
    assert [o["price"] for o in a["outliers"]["items"]] == [55.0] and "IQR" in a["outliers"]["method"]


def test_no_history_is_reported_honestly():
    h = user(); rows = [("A", "S", 10, "INR"), ("B", "S", 20, "INR")]
    _, r = upload(h, csv_bytes(rows, cols=("item", "store", "selling_price", "currency")))
    d = r.json()["dataset"]; a = c.get(f"/api/datasets/{d['id']}/analysis", headers=h).json()
    assert a["trends"]["available"] is False and "No price history" in a["trends"]["note"]
    assert all(p["change_pct"] is None for p in a["products"]) and d["quality"]["dates_inferred"] == 2


def test_xlsx_and_xls_upload():
    h = user(); df = pd.DataFrame({"Item Name": ["A", "B"], "Current Price": [10.5, 20], "Website": ["S1", "S2"]})
    for name, data in (("f.xlsx", xlsx_bytes(df)), ("f.xls", xls_bytes(df))):
        prev, r = upload(h, data, name)
        assert prev.json()["mapping"]["price"]["column"] == "Current Price", name
        assert r.status_code == 201 and r.json()["dataset"]["rows_valid"] == 2, name


@pytest.mark.parametrize("name,content,status", [
    ("a.txt", b"product,price\nx,1", 415), ("a.exe", b"MZ\x90", 415), ("empty.csv", b"", 400),
    ("fake.xlsx", b"product,price\nx,1\n", 415), ("fake.xls", b"hello", 415),
    ("bin.csv", b"product,price\x00\x01\x02", 415), ("renamed.csv", b"PK\x03\x04abcdef", 415),
    ("broken.xlsx", b"PK\x03\x04" + b"garbage" * 50, 422), ("headeronly.csv", b"product,price\n", 422),
])
def test_invalid_files_rejected_with_clear_errors(name, content, status):
    h = user(); r = c.post("/api/datasets/preview", files={"file": (name, content)}, headers=h)
    assert r.status_code == status and r.json()["detail"]
    assert c.get("/api/datasets", headers=h).json() == []                   # nothing persisted


def test_size_limit(monkeypatch):
    monkeypatch.setattr(settings, "MAX_UPLOAD_MB", 1); h = user()
    big = b"product,price\n" + b"a,1\n" * 400_000
    assert c.post("/api/datasets/preview", files={"file": ("big.csv", big)}, headers=h).status_code == 413


def test_missing_required_field_and_ambiguous_mapping():
    h = user()
    p = c.post("/api/datasets/preview", files={"file": ("a.csv", b"product,source\nx,y\n")}, headers=h).json()
    assert p["ready"] is False and p["mapping"]["price"]["column"] is None
    r = c.post("/api/datasets", files={"file": ("a.csv", b"product,source\nx,y\n")}, data={"mapping": json.dumps({"product": "product"})}, headers=h)
    assert r.status_code == 422 and "price" in r.json()["detail"]
    amb = c.post("/api/datasets/preview", files={"file": ("a.csv", b"name,seller,amount\nx,s,5\n")}, headers=h).json()
    assert amb["ready"] is False and amb["mapping"]["product"]["needs_confirmation"] and amb["mapping"]["price"]["needs_confirmation"]
    # the user can resolve it by choosing columns explicitly
    r = c.post("/api/datasets", files={"file": ("a.csv", b"name,seller,amount\nx,s,5\n")},
               data={"mapping": json.dumps({"product": "name", "price": "amount", "source": "seller"})}, headers=h)
    assert r.status_code == 201


def test_malformed_prices_missing_values_and_duplicates():
    h = user()
    rows = [("A", "S", "₹1,299.50", "", "2026-09-01"), ("A", "S", "1.299,50", "", "2026-09-02"), ("B", "S", "abc", "", "2026-09-01"),
            ("C", "S", "-5", "", "2026-09-01"), ("D", "S", "", "", "2026-09-01"), ("", "S", "9", "", "2026-09-01"),
            ("A", "S", "₹1,299.50", "", "2026-09-01")]
    _, r = upload(h, csv_bytes(rows)); d = r.json()["dataset"]; q = d["quality"]
    assert d["status"] == "partial" and d["rows_total"] == 7 and d["rows_skipped"] == 3
    assert q["skipped_bad_price"] == 2 and q["skipped_no_product"] == 1 and q["unavailable_price"] == 1 and q["duplicates_removed"] == 1
    assert q["issues"] and {i["field"] for i in q["issues"]} >= {"price", "product"}
    a = c.get(f"/api/datasets/{d['id']}/analysis", headers=h).json()
    assert a["price_stats"]["min"] == 1299.5 and a["summary"]["unavailable"] == 1 and a["summary"]["primary_currency"] == "INR"
    assert any("unavailable" in w for w in a["quality"]["warnings"])


def test_all_rows_invalid_fails_without_persisting():
    h = user(); r = c.post("/api/datasets", files={"file": ("a.csv", b"product,price\nx,abc\ny,-1\n")},
                           data={"mapping": json.dumps({"product": "product", "price": "price"})}, headers=h)
    assert r.status_code == 422 and r.json()["detail"]["code"] == "no_valid_rows"
    assert c.get("/api/datasets", headers=h).json() == [] and c.get("/api/products", headers=h).json()["total"] == 0


def test_duplicate_upload_detected():
    h = user(); data = csv_bytes(SERIES); _, r1 = upload(h, data)
    p, r2 = upload(h, data)
    assert p.json()["duplicate_of"]["id"] == r1.json()["dataset"]["id"] and r2.status_code == 409
    assert r2.json()["detail"]["code"] == "duplicate"
    _, r3 = upload(h, data, force="true"); assert r3.status_code == 201
    assert len(c.get("/api/datasets", headers=h).json()) == 2


def test_dataset_switching_scopes_every_view():
    h = user()
    _, a = upload(h, csv_bytes([("Alpha", "S", 10, "INR", "2026-09-01"), ("Alpha", "S", 12, "INR", "2026-09-02")]), "a.csv")
    _, b = upload(h, csv_bytes([("Beta", "S", 99, "INR", "2026-09-01"), ("Beta", "S", 90, "INR", "2026-09-02")]), "b.csv")
    da, db_ = a.json()["dataset"]["id"], b.json()["dataset"]["id"]
    pa = c.get(f"/api/products?dataset_id={da}", headers=h).json()["items"]; pb = c.get(f"/api/products?dataset_id={db_}", headers=h).json()["items"]
    assert [p["name"] for p in pa] == ["Alpha"] and [p["name"] for p in pb] == ["Beta"]
    assert c.get(f"/api/analytics/{pa[0]['id']}?dataset_id={da}", headers=h).json()["latest"] == 12
    assert c.get(f"/api/reports/{pb[0]['id']}/csv?dataset_id={db_}", headers=h).text.count("Beta") == 2


def test_delete_dataset_and_inaccessible_dataset():
    h, other = user(), user(); _, r = upload(h, csv_bytes(SERIES)); did = r.json()["dataset"]["id"]
    assert c.get(f"/api/datasets/{did}/analysis", headers=other).status_code == 404
    assert c.delete(f"/api/datasets/{did}", headers=other).status_code == 404
    assert c.delete(f"/api/datasets/{did}", headers=h).status_code == 204
    assert c.get(f"/api/datasets/{did}/analysis", headers=h).status_code == 404
    assert c.get("/api/products", headers=h).json()["total"] == 0


def test_dataset_endpoints_require_auth():
    for m, u in (("get", "/api/datasets"), ("post", "/api/datasets/preview"), ("get", "/api/datasets/1/analysis"), ("delete", "/api/datasets/1")):
        assert getattr(c, m)(u).status_code == 401


def test_legacy_import_endpoint_still_works_and_demo_seed_is_idempotent():
    h = user(); r = c.post("/api/import/csv", files={"file": ("x.csv", b"name,source,price,currency,date\nA,S,10,INR,2026-09-01\nA,S,12,INR,2026-09-02\n")}, headers=h)
    assert r.status_code == 200 and r.json()["imported"] == 2 and r.json()["dataset_id"]
    h2 = user(); c.post("/api/demo/seed", headers=h2); s = c.post("/api/demo/seed", headers=h2).json()
    assert s["seeded"] is False
    ds = c.get("/api/datasets", headers=h2).json(); assert len(ds) == 1 and ds[0]["is_demo"] is True
    assert c.get(f"/api/datasets/{ds[0]['id']}/records", headers=h2).json()["total"] == 60


def test_alert_fires_on_uploaded_data():
    h = user(); _, r = upload(h, csv_bytes([("W", "S", 100, "INR", "2026-09-01")]))
    pid = c.get("/api/products", headers=h).json()["items"][0]["id"]
    c.post("/api/alerts", json={"product_id": pid, "kind": "target_price", "threshold": 50}, headers=h)
    _, r2 = upload(h, csv_bytes([("W", "S", 40, "INR", "2026-09-02")]))
    assert r2.json()["alerts_triggered"] == 1 and len(c.get("/api/notifications", headers=h).json()) == 1


def test_schema_migration_preserves_old_data(tmp_path):
    f = tmp_path / "old.db"; con = sqlite3.connect(f)
    con.executescript("""CREATE TABLE price_observations (id INTEGER PRIMARY KEY, product_id INT, source VARCHAR(100), source_url VARCHAR(1000),
      price FLOAT, currency VARCHAR(3), status VARCHAR(20), is_demo BOOLEAN, observed_at DATETIME,
      CONSTRAINT uq_obs UNIQUE (product_id, source, observed_at));
      CREATE INDEX ix_obs_prod_time ON price_observations (product_id, observed_at);
      INSERT INTO price_observations VALUES (1,1,'S',NULL,10.0,'INR','success',0,'2026-09-01 00:00:00');""")
    con.commit(); con.close()
    eng = create_engine(f"sqlite:///{f}")
    dbmod.migrate_schema(eng); dbmod.migrate_schema(eng)                      # idempotent
    with eng.connect() as cx:
        cols = [r[1] for r in cx.execute(text("pragma table_info(price_observations)"))]
        assert "dataset_id" in cols and cx.execute(text("select price from price_observations")).scalar() == 10.0
        cx.execute(text("insert into price_observations (product_id,source,price,currency,status,is_demo,observed_at,date_inferred) values (1,'S',11,'INR','success',0,'2026-09-01 00:00:00',0)"))  # old uniqueness gone
        assert "price_observations_old" not in [r[0] for r in cx.execute(text("select name from sqlite_master"))]
