import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.services.ssrf import validate_public_url

c = TestClient(app)

@pytest.mark.parametrize("u", ["http://127.0.0.1/x", "http://localhost", "http://169.254.169.254/", "ftp://a.com"])
def test_ssrf_blocked(u):
    with pytest.raises(ValueError):
        validate_public_url(u)

def test_auth_and_flow():
    r = c.post("/api/auth/register", json={"name": "T", "email": "t@x.com", "password": "password123"})
    assert r.status_code in (201, 409)
    r = c.post("/api/auth/login", data={"username": "t@x.com", "password": "password123"})
    h = {"Authorization": "Bearer " + r.json()["access_token"]}
    assert c.post("/api/demo/seed", headers=h).status_code == 200
    pid = c.get("/api/products", headers=h).json()["items"][0]["id"]
    assert c.get(f"/api/analytics/{pid}", headers=h).json()["enough_data"] is True
    assert c.post("/api/collect", json={"url": "http://127.0.0.1"}, headers=h).status_code == 400
    assert c.get("/api/products").status_code == 401

def _auth():
    c.post("/api/auth/register", json={"name": "S2", "email": "s2@x.com", "password": "password123"})
    r = c.post("/api/auth/login", data={"username": "s2@x.com", "password": "password123"})
    return {"Authorization": "Bearer " + r.json()["access_token"]}

def test_stage2_features():
    h = _auth(); c.post("/api/demo/seed", headers=h)
    pid = c.get("/api/products", headers=h).json()["items"][0]["id"]
    a = c.post("/api/alerts", json={"product_id": pid, "kind": "target_price", "threshold": 1}, headers=h).json()["id"]
    assert c.patch(f"/api/alerts/{a}", json={"enabled": False}, headers=h).json()["enabled"] is False
    assert c.get(f"/api/reports/{pid}/pdf", headers=h).content[:4] == b"%PDF"
    assert "DemoShop" in c.get(f"/api/reports/{pid}/csv", headers=h).text
    assert c.post(f"/api/insights/{pid}/ask", json={"question": "trend?"}, headers=h).json()["mode"] == "deterministic"
    assert c.post("/api/settings/password", json={"current_password": "bad", "new_password": "newpassword1"}, headers=h).status_code == 400
    assert c.patch("/api/settings", json={"prefs": {"theme": "light"}}, headers=h).status_code == 200
    assert c.get("/api/settings", headers=h).json()["prefs"]["theme"] == "light"
    assert c.delete("/api/settings/data", headers=h).status_code == 200
    assert c.get("/api/products", headers=h).json()["total"] == 0
