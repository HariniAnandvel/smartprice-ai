import csv, io, json
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import PlainTextResponse
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from ..core.db import get_db
from ..core.security import hash_password, verify_password, make_token, current_user
from ..models import User, Product, PriceObservation, Alert, ScrapeJob, Dataset
from ..services import analytics, ingest, alerts as alert_svc
from ..services.collector import collect
from ..services.ssrf import validate_public_url

router = APIRouter(prefix="/api")

class Register(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class ScrapeIn(BaseModel):
    url: str

class AlertIn(BaseModel):
    product_id: int
    kind: str = Field(pattern="^(target_price|pct_drop)$")
    threshold: float = Field(gt=0)
    enabled: bool = True

@router.post("/auth/register", status_code=201)
def register(body: Register, db: Session = Depends(get_db)):
    if db.scalar(select(User).where(User.email == body.email.lower())):
        raise HTTPException(409, "Email already registered")
    u = User(name=body.name, email=body.email.lower(), password_hash=hash_password(body.password))
    db.add(u); db.commit()
    return {"access_token": make_token(u.id), "token_type": "bearer"}

@router.post("/auth/login")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(User.email == form.username.lower()))
    if not u or not verify_password(form.password, u.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": make_token(u.id), "token_type": "bearer"}

@router.get("/auth/me")
def me(u: User = Depends(current_user)):
    return {"id": u.id, "name": u.name, "email": u.email}

def _record(db, user, name, source, price, currency, url=None, status="success", demo=False, when=None, dataset_id=None):
    p = db.scalar(select(Product).where(Product.user_id == user.id, Product.name == name))
    if not p:
        p = Product(user_id=user.id, name=name, is_demo=demo); db.add(p); db.flush()
    o = PriceObservation(product_id=p.id, dataset_id=dataset_id, source=source, source_url=url, price=price, currency=currency,
                         status=status, is_demo=demo, observed_at=when or datetime.now(timezone.utc))
    db.add(o); db.flush()
    return p, o, alert_svc.evaluate(db, p.id, o)

LIVE_NAME = "Live collection (URL collector)"

@router.post("/collect")
def collect_url(body: ScrapeIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        validate_public_url(body.url)
    except ValueError as e:
        raise HTTPException(400, str(e))
    res = collect(body.url)
    fired = []
    if res["status"] in ("success", "partial") and res.get("name"):
        live = db.scalar(select(Dataset).where(Dataset.user_id == u.id, Dataset.name == LIVE_NAME))
        if not live:  # collected pages join the same dataset flow as uploads
            live = Dataset(user_id=u.id, name=LIVE_NAME, status="completed", quality=json.dumps({"live": True})); db.add(live); db.flush()
        live.rows_total += 1; live.rows_valid += 1 if res.get("price") is not None else 0
        _, _, fired = _record(db, u, res["name"], body.url.split("/")[2], res.get("price"),
                              res.get("currency", "INR"), body.url, res["status"], dataset_id=live.id)
    db.add(ScrapeJob(user_id=u.id, url=body.url, status=res["status"], message=res["message"]))
    db.commit()
    return {**res, "alerts_triggered": len(fired)}

@router.post("/import/csv")
async def import_csv(file: UploadFile = File(...), u: User = Depends(current_user), db: Session = Depends(get_db)):
    """Backward-compatible one-step import: auto-detects columns, then uses the dataset pipeline.
    The website uses /api/datasets/preview + /api/datasets (with a mapping review step) instead."""
    from . import datasets as ds
    content, ftype, df = await ds._read(file)
    m = ingest.detect_mapping(list(df.columns))
    missing = [f for f in ingest.REQUIRED if not m[f]["column"]]
    if missing:
        raise HTTPException(422, f"Could not find column(s) for {', '.join(missing)}. Found columns: {', '.join(df.columns)}")
    r = await ds.create(file=_Replay(file, content), mapping=json.dumps({f: m[f]["column"] for f in ingest.FIELDS}), name="", force=True, u=u, db=db)
    return {"imported": r["dataset"]["rows_valid"], "skipped": r["dataset"]["rows_skipped"], "dataset_id": r["dataset"]["id"]}

class _Replay:
    """Lets an already-read upload be read again."""
    def __init__(self, f, content): self.filename, self._c = f.filename, content
    async def read(self, n=-1): return self._c

DEMO_NAME = "Demo data (sample, not real)"

@router.post("/demo/seed")
def seed(u: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = db.scalar(select(Dataset).where(Dataset.user_id == u.id, Dataset.is_demo.is_(True)))
    if existing:
        return {"seeded": False, "dataset_id": existing.id, "label": "demonstration data (already loaded)"}
    ds = Dataset(user_id=u.id, name=DEMO_NAME, filename=None, status="completed", is_demo=True, rows_total=60, rows_valid=60,
                 quality=json.dumps({"rows_total": 60, "demo": True}))
    db.add(ds); db.flush()
    base = datetime.now(timezone.utc) - timedelta(days=29)
    for src, start in (("DemoShop A", 1200), ("DemoShop B", 1260)):
        for d in range(30):
            _record(db, u, "Demo Headphones", src, round(start - d * 2 + (d % 5) * 6, 2), "INR",
                    demo=True, when=base + timedelta(days=d), dataset_id=ds.id)
    db.commit()
    return {"seeded": True, "dataset_id": ds.id, "label": "demonstration data"}

@router.get("/products")
def products(page: int = 1, size: int = 20, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Product).where(Product.user_id == u.id)
    if dataset_id is not None:
        q = q.where(Product.id.in_(select(PriceObservation.product_id).where(PriceObservation.dataset_id == dataset_id)))
    total = db.scalar(select(func.count()).select_from(q.subquery()))
    rows = db.scalars(q.offset((page - 1) * size).limit(size)).all()
    return {"total": total, "items": [{"id": p.id, "name": p.name, "is_demo": p.is_demo} for p in rows]}

def obs_of(p, dataset_id=None):
    return [o for o in p.observations if dataset_id is None or o.dataset_id == dataset_id]

def _own(db, u, pid):
    p = db.get(Product, pid)
    if not p or p.user_id != u.id:
        raise HTTPException(404, "Product not found")
    return p

@router.get("/analytics/{pid}")
def trend(pid: int, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid); obs = obs_of(p, dataset_id)
    return {"product": p.name, "is_demo": any(o.is_demo for o in obs), **analytics.summarize(obs),
            "series": [{"t": o.observed_at.isoformat(), "source": o.source, "price": o.price}
                       for o in sorted(obs, key=lambda o: o.observed_at)]}

@router.get("/competitors/{pid}")
def competitors(pid: int, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid)
    latest = {}
    for o in sorted(obs_of(p, dataset_id), key=lambda o: o.observed_at):
        latest[o.source] = o
    prices = [o.price for o in latest.values() if o.price is not None]
    best = min(prices) if prices else None
    return [{"source": s, "price": o.price, "currency": o.currency, "observed_at": o.observed_at.isoformat(),
             "available": o.price is not None,
             "gap_pct": round((o.price - best) / best * 100, 2) if o.price is not None and best else None}
            for s, o in latest.items()]

@router.get("/insights/{pid}")
def insights(pid: int, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid)
    return analytics.insight_text(p.name, analytics.summarize(obs_of(p, dataset_id)))

@router.post("/alerts", status_code=201)
def create_alert(body: AlertIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    _own(db, u, body.product_id)
    a = Alert(user_id=u.id, **body.model_dump()); db.add(a); db.commit()
    return {"id": a.id}

@router.get("/alerts")
def list_alerts(u: User = Depends(current_user), db: Session = Depends(get_db)):
    return [{"id": a.id, "product_id": a.product_id, "kind": a.kind, "threshold": a.threshold,
             "enabled": a.enabled, "last_triggered_at": a.last_triggered_at}
            for a in db.scalars(select(Alert).where(Alert.user_id == u.id))]

@router.delete("/alerts/{aid}", status_code=204)
def delete_alert(aid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a or a.user_id != u.id: raise HTTPException(404, "Alert not found")
    db.delete(a); db.commit()

@router.get("/reports/{pid}/csv")
def report_csv(pid: int, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid)
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["product", "source", "price", "currency", "observed_at", "demo"])
    for o in sorted(obs_of(p, dataset_id), key=lambda o: o.observed_at):
        w.writerow([p.name, o.source, "" if o.price is None else o.price, o.currency, o.observed_at.isoformat(), o.is_demo])
    return PlainTextResponse(out.getvalue(), media_type="text/csv")
