import json
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from ..core.config import settings
from ..core.db import get_db
from ..core.security import current_user
from ..models import User, Product, PriceObservation, Dataset, Alert
from ..services import ingest, alerts as alert_svc
from ..services.dataset_analysis import analyze, meta

router = APIRouter(prefix="/api/datasets", tags=["datasets"])


async def _read(file: UploadFile):
    limit = settings.MAX_UPLOAD_MB * 1_000_000
    content = await file.read(limit + 1)
    try:
        ftype = ingest.validate_file(file.filename or "", content, limit)
        df = ingest.read_frame(content, ftype, settings.MAX_UPLOAD_ROWS)
    except ingest.UploadError as e:
        raise HTTPException(e.status, str(e))
    return content, ftype, df


def _existing(db, u, digest):
    return db.scalar(select(Dataset).where(Dataset.user_id == u.id, Dataset.file_hash == digest))


@router.post("/preview")
async def preview(file: UploadFile = File(...), u: User = Depends(current_user), db: Session = Depends(get_db)):
    """Validate and read the real file, detect columns and suggest a mapping. Persists nothing."""
    content, ftype, df = await _read(file)
    digest = ingest.file_hash(content)
    dup = _existing(db, u, digest)
    mapping = ingest.detect_mapping(list(df.columns))
    return {"filename": file.filename, "file_type": ftype, "file_size": len(content), "file_hash": digest,
            "rows": len(df), "columns": ingest.describe_columns(df), "mapping": mapping,
            "required": ingest.REQUIRED, "ready": all(mapping[f]["column"] and not mapping[f]["needs_confirmation"] for f in ingest.REQUIRED),
            "exact_duplicate_rows": int(df.duplicated().sum()),
            "preview": df.head(10).to_dict(orient="records"),
            "duplicate_of": {"id": dup.id, "name": dup.name} if dup else None}


@router.post("", status_code=201)
async def create(file: UploadFile = File(...), mapping: str = Form(...), name: str = Form(""), force: bool = Form(False),
                 u: User = Depends(current_user), db: Session = Depends(get_db)):
    content, ftype, df = await _read(file)
    digest = ingest.file_hash(content)
    dup = _existing(db, u, digest)
    if dup and not force:
        raise HTTPException(409, {"code": "duplicate", "message": f"This exact file was already imported as '{dup.name}'.", "dataset_id": dup.id})
    try:
        m = json.loads(mapping)
        if not isinstance(m, dict):
            raise ValueError
        m = {f: (m.get(f) or None) for f in ingest.FIELDS}
    except ValueError:
        raise HTTPException(400, "mapping must be a JSON object of field -> column name")
    now = datetime.now(timezone.utc)
    try:
        res = ingest.normalize(df, m, now)
    except ingest.UploadError as e:
        raise HTTPException(e.status, str(e))
    c = res["counts"]
    if c["rows_valid"] == 0:
        raise HTTPException(422, {"code": "no_valid_rows", "message": "No valid price records were found with this mapping.",
                                  "counts": c, "issues": res["issues"][:20]})
    ds = Dataset(user_id=u.id, name=(name.strip() or file.filename or "Dataset")[:300], filename=file.filename, file_hash=digest,
                 file_size=len(content), file_type=ftype, status="partial" if c["rows_skipped"] else "completed",
                 rows_total=c["rows_total"], rows_valid=c["rows_valid"], rows_skipped=c["rows_skipped"],
                 mapping=json.dumps(m), columns=json.dumps(ingest.describe_columns(df)),
                 quality=json.dumps({**c, "issues": res["issues"][:50], "issue_count": len(res["issues"])}))
    db.add(ds); db.flush()
    cache = {p.name: p for p in db.scalars(select(Product).where(Product.user_id == u.id))}
    touched = {}
    for r in res["records"]:
        p = cache.get(r["name"])
        if not p:
            p = Product(user_id=u.id, name=r["name"]); db.add(p); db.flush(); cache[r["name"]] = p
        o = PriceObservation(product_id=p.id, dataset_id=ds.id, source=r["source"], price=r["price"], currency=r["currency"],
                             status="success" if r["price"] is not None else "unavailable", observed_at=r["observed_at"],
                             date_inferred=r["date_inferred"], category=r["category"], brand=r["brand"], rating=r["rating"])
        db.add(o)
        if r["price"] is not None and (p.id not in touched or o.observed_at >= touched[p.id].observed_at):
            touched[p.id] = o
    db.flush()
    fired = sum(len(alert_svc.evaluate(db, pid, o)) for pid, o in touched.items())  # latest price per product only
    db.commit()
    return {"dataset": meta(ds), "alerts_triggered": fired, "analysis_url": f"/api/datasets/{ds.id}/analysis"}


@router.get("")
def history(u: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Dataset).where(Dataset.user_id == u.id).order_by(Dataset.id.desc()))
    out = []
    for d in rows:
        m = meta(d); m.pop("columns"); m.pop("mapping"); m["quality"] = {k: v for k, v in m["quality"].items() if k != "issues"}
        out.append(m)
    return out


def _own_ds(db, u, did) -> Dataset:
    d = db.get(Dataset, did)
    if not d or d.user_id != u.id:
        raise HTTPException(404, "Dataset not found (it may have been deleted)")
    return d


@router.get("/{did}")
def one(did: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    return meta(_own_ds(db, u, did))


@router.get("/{did}/analysis")
def analysis(did: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    return analyze(db, _own_ds(db, u, did))


@router.get("/{did}/records")
def records(did: int, page: int = 1, size: int = 25, u: User = Depends(current_user), db: Session = Depends(get_db)):
    d = _own_ds(db, u, did); size = max(1, min(size, 200)); page = max(1, page)
    q = select(Product.name, PriceObservation).join(Product, Product.id == PriceObservation.product_id).where(PriceObservation.dataset_id == d.id)
    total = db.scalar(select(func.count()).select_from(PriceObservation).where(PriceObservation.dataset_id == d.id))
    rows = db.execute(q.order_by(PriceObservation.id).offset((page - 1) * size).limit(size)).all()
    return {"total": total, "page": page, "items": [{"product": n, "source": o.source, "price": o.price, "currency": o.currency,
            "observed_at": o.observed_at.isoformat(), "date_inferred": o.date_inferred, "category": o.category, "brand": o.brand, "rating": o.rating} for n, o in rows]}


@router.delete("/{did}", status_code=204)
def delete(did: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    d = _own_ds(db, u, did)
    pids = set(db.scalars(select(PriceObservation.product_id).where(PriceObservation.dataset_id == d.id)))
    for o in db.scalars(select(PriceObservation).where(PriceObservation.dataset_id == d.id)): db.delete(o)
    db.flush()
    for pid in pids:  # remove products that now have no observations anywhere, with their alerts
        if not db.scalar(select(func.count()).select_from(PriceObservation).where(PriceObservation.product_id == pid)):
            for a in db.scalars(select(Alert).where(Alert.product_id == pid)): db.delete(a)
            p = db.get(Product, pid)
            if p: db.delete(p)
    db.delete(d); db.commit()
