import json
from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..core.db import get_db
from ..core.security import current_user, verify_password, hash_password
from ..models import User, Product, Alert, Competitor, Notification, Report, AuditEvent, Dataset
from ..services import analytics, llm
from ..services.pdf import build_pdf
from .routes import _own, obs_of

router = APIRouter(prefix="/api")

def audit(db, u, action): db.add(AuditEvent(user_id=u.id, action=action))

class AlertPatch(BaseModel):
    kind: str | None = Field(None, pattern="^(target_price|pct_drop)$")
    threshold: float | None = Field(None, gt=0)
    enabled: bool | None = None

@router.patch("/alerts/{aid}")
def patch_alert(aid: int, body: AlertPatch, u: User = Depends(current_user), db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a or a.user_id != u.id: raise HTTPException(404, "Alert not found")
    for k, v in body.model_dump(exclude_none=True).items(): setattr(a, k, v)
    db.commit(); return {"id": a.id, "kind": a.kind, "threshold": a.threshold, "enabled": a.enabled}

@router.get("/notifications")
def notifications(u: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(Notification).where(Notification.user_id == u.id).order_by(Notification.id.desc()).limit(50))
    return [{"id": n.id, "message": n.message, "read": n.read, "via": n.delivered_via, "at": n.created_at} for n in rows]

@router.post("/notifications/{nid}/read")
def read_notification(nid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    n = db.get(Notification, nid)
    if not n or n.user_id != u.id: raise HTTPException(404, "Not found")
    n.read = True; db.commit(); return {"ok": True}

class CompIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    domain: str = Field(min_length=3, max_length=255)

@router.post("/competitors", status_code=201)
def add_competitor(b: CompIn, u: User = Depends(current_user), db: Session = Depends(get_db)):
    c = Competitor(user_id=u.id, name=b.name, domain=b.domain.lower()); db.add(c); db.commit(); return {"id": c.id}

@router.get("/competitors")
def list_competitors(u: User = Depends(current_user), db: Session = Depends(get_db)):
    return [{"id": c.id, "name": c.name, "domain": c.domain}
            for c in db.scalars(select(Competitor).where(Competitor.user_id == u.id))]

@router.delete("/competitors/{cid}", status_code=204)
def del_competitor(cid: int, u: User = Depends(current_user), db: Session = Depends(get_db)):
    c = db.get(Competitor, cid)
    if not c or c.user_id != u.id: raise HTTPException(404, "Not found")
    db.delete(c); db.commit()

class Ask(BaseModel):
    question: str = Field(min_length=1, max_length=500)

@router.post("/insights/{pid}/ask")
def ask(pid: int, b: Ask, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid)
    return llm.answer(b.question, p.name, analytics.summarize(obs_of(p, dataset_id)))

@router.get("/reports/{pid}/pdf")
def report_pdf(pid: int, dataset_id: int | None = None, u: User = Depends(current_user), db: Session = Depends(get_db)):
    p = _own(db, u, pid)
    obs = sorted(obs_of(p, dataset_id), key=lambda o: o.observed_at)
    data = build_pdf(p.name, analytics.summarize(obs), obs, any(o.is_demo for o in obs))
    db.add(Report(user_id=u.id, product_id=pid, fmt="pdf")); audit(db, u, f"report_pdf:{pid}"); db.commit()
    return Response(data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="report-{pid}.pdf"'})

class ProfilePatch(BaseModel):
    name: str | None = Field(None, min_length=1, max_length=100)
    prefs: dict | None = None  # appearance, reduced_motion, notification toggles

@router.get("/settings")
def get_settings(u: User = Depends(current_user)):
    return {"name": u.name, "email": u.email, "prefs": json.loads(u.prefs or "{}")}

@router.patch("/settings")
def patch_settings(b: ProfilePatch, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if b.name: u.name = b.name
    if b.prefs is not None:
        s = json.dumps(b.prefs)
        if len(s) > 2000: raise HTTPException(400, "Preferences too large")
        u.prefs = s
    db.commit(); return {"ok": True}

class PwChange(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=128)

@router.post("/settings/password")
def change_password(b: PwChange, u: User = Depends(current_user), db: Session = Depends(get_db)):
    if not verify_password(b.current_password, u.password_hash): raise HTTPException(400, "Current password is incorrect")
    u.password_hash = hash_password(b.new_password); audit(db, u, "password_change"); db.commit(); return {"ok": True}

@router.delete("/settings/data")
def wipe_data(u: User = Depends(current_user), db: Session = Depends(get_db)):
    for a in db.scalars(select(Alert).where(Alert.user_id == u.id)): db.delete(a)
    for n in db.scalars(select(Notification).where(Notification.user_id == u.id)): db.delete(n)
    for r in db.scalars(select(Report).where(Report.user_id == u.id)): db.delete(r)
    for p in db.scalars(select(Product).where(Product.user_id == u.id)): db.delete(p)
    db.flush()
    for d in db.scalars(select(Dataset).where(Dataset.user_id == u.id)): db.delete(d)
    audit(db, u, "data_wipe"); db.commit(); return {"ok": True}

@router.get("/audit")
def audit_log(u: User = Depends(current_user), db: Session = Depends(get_db)):
    return [{"action": e.action, "at": e.created_at}
            for e in db.scalars(select(AuditEvent).where(AuditEvent.user_id == u.id).order_by(AuditEvent.id.desc()).limit(50))]

from ..models import ScrapeJob

@router.get("/collect/history")
def collect_history(u: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(ScrapeJob).where(ScrapeJob.user_id == u.id).order_by(ScrapeJob.id.desc()).limit(30))
    return [{"url": j.url, "status": j.status, "message": j.message, "at": j.created_at} for j in rows]
