import json, re, urllib.robotparser
from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup
from .ssrf import validate_public_url

UA = "SmartPriceBot/1.0"
MAX_BYTES = 2_000_000

def robots_allows(url: str) -> bool:
    p = urlparse(url)
    rp = urllib.robotparser.RobotFileParser()
    try:
        r = httpx.get(f"{p.scheme}://{p.netloc}/robots.txt", timeout=5, headers={"User-Agent": UA})
        if r.status_code >= 400:
            return True
        rp.parse(r.text.splitlines())
    except httpx.HTTPError:
        return True
    return rp.can_fetch(UA, url)

def collect(url: str) -> dict:
    validate_public_url(url)
    if not robots_allows(url):
        return {"status": "blocked", "message": "robots.txt disallows collection. Use CSV import instead."}
    try:
        with httpx.Client(timeout=10, follow_redirects=False, headers={"User-Agent": UA}) as c:
            r = c.get(url)
    except httpx.HTTPError as e:
        return {"status": "failed", "message": f"Request failed: {e.__class__.__name__}"}
    if r.status_code in (401, 403, 429):
        return {"status": "blocked", "message": f"Site refused automated access ({r.status_code}). Use CSV import."}
    if r.status_code != 200 or len(r.content) > MAX_BYTES:
        return {"status": "failed", "message": f"Unusable response ({r.status_code})"}
    soup = BeautifulSoup(r.text, "html.parser")
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(tag.string or "")
        except json.JSONDecodeError:
            continue
        for item in (data if isinstance(data, list) else [data]):
            if isinstance(item, dict) and item.get("@type") == "Product":
                offer = item.get("offers") or {}
                if isinstance(offer, list): offer = offer[0] if offer else {}
                price = offer.get("price")
                try: price = float(re.sub(r"[^\d.]", "", str(price))) if price is not None else None
                except ValueError: price = None
                return {"status": "success" if price is not None else "partial",
                        "name": item.get("name"), "price": price,
                        "currency": offer.get("priceCurrency", "INR"),
                        "message": "Extracted from structured data"}
    return {"status": "partial", "message": "No structured product data found. Use CSV import."}
