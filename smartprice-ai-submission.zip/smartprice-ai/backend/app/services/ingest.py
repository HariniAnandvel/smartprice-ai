"""File ingestion: validation, parsing, column detection and normalisation.

Nothing here invents data. Missing prices stay missing, missing dates are flagged as
inferred, and every rejected row is recorded with a reason.
"""
from __future__ import annotations

import csv
import difflib
import hashlib
import io
import math
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ALLOWED = ("csv", "xlsx", "xls")
XLSX_SIG = b"PK\x03\x04"
XLS_SIG = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
FIELDS = ["product", "price", "source", "currency", "date", "category", "brand", "rating"]
REQUIRED = ["product", "price"]

SYNONYMS = {
    "product": ["product", "product_name", "item", "item_name", "name", "title", "product_title"],
    "price": ["price", "selling_price", "current_price", "amount", "sale_price", "offer_price", "mrp", "cost"],
    "source": ["source", "website", "store", "seller", "retailer", "shop", "marketplace", "platform"],
    "currency": ["currency", "currency_code"],
    "date": ["date", "timestamp", "observed_at", "datetime", "scraped_at", "collected_at", "created_at", "time"],
    "category": ["category", "product_category", "department", "segment", "type"],
    "brand": ["brand", "manufacturer", "make", "vendor"],
    "rating": ["rating", "review_score", "stars", "avg_rating", "score"],
}
AMBIGUOUS = {"name", "seller", "amount", "cost", "type", "score", "time", "make", "mrp"}
SYMBOL_CCY = {"₹": "INR", "rs": "INR", "inr": "INR", "$": "USD", "usd": "USD", "€": "EUR", "eur": "EUR", "£": "GBP", "gbp": "GBP"}
MISSING_TOKENS = {"", "nan", "n/a", "na", "null", "none", "-", "--", "unavailable", "out of stock"}


class UploadError(ValueError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def file_hash(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def validate_file(filename: str, content: bytes, max_bytes: int) -> str:
    """Return the verified file type. Never trusts the extension alone."""
    if not content:
        raise UploadError("The file is empty.")
    if len(content) > max_bytes:
        raise UploadError(f"File is too large (limit {max_bytes // 1_000_000} MB).", 413)
    ext = Path(filename or "").suffix.lower().lstrip(".")
    if ext not in ALLOWED:
        raise UploadError(f"Unsupported file type '.{ext}'. Upload a .csv, .xlsx or .xls file.", 415)
    head = content[:8]
    if ext == "xlsx" and not head.startswith(XLSX_SIG):
        raise UploadError("This file is named .xlsx but its contents are not a valid Excel workbook.", 415)
    if ext == "xls" and not head.startswith(XLS_SIG):
        raise UploadError("This file is named .xls but its contents are not a valid legacy Excel file.", 415)
    if ext == "csv":
        if head.startswith(XLSX_SIG) or head.startswith(XLS_SIG):
            raise UploadError("This looks like an Excel file renamed to .csv. Save it with the right extension.", 415)
        if b"\x00" in content[:4096]:
            raise UploadError("This file contains binary data and is not a valid CSV.", 415)
    return ext


def _decode(content: bytes) -> str:
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return content.decode(enc)
        except UnicodeDecodeError:
            continue
    return content.decode("latin-1")


def read_frame(content: bytes, ftype: str, max_rows: int) -> pd.DataFrame:
    try:
        if ftype == "csv":
            text = _decode(content)
            try:
                delim = csv.Sniffer().sniff(text[:5000], delimiters=",;\t|").delimiter
            except csv.Error:
                delim = ","
            df = pd.read_csv(io.StringIO(text), sep=delim, dtype=str, keep_default_na=False, skip_blank_lines=True)
        else:
            engine = "openpyxl" if ftype == "xlsx" else "xlrd"
            df = pd.read_excel(io.BytesIO(content), dtype=str, keep_default_na=False, engine=engine, sheet_name=0)
    except UploadError:
        raise
    except Exception as exc:  # corrupted, password-protected, malformed
        raise UploadError(f"The file could not be read ({type(exc).__name__}). It may be corrupted or malformed.", 422)
    df.columns = [str(c).strip() for c in df.columns]
    df = df.loc[:, [c for c in df.columns if c and not c.lower().startswith("unnamed:") or df[c].astype(str).str.strip().ne("").any()]]
    df = df.apply(lambda col: col.astype(str).str.strip())
    df = df[df.apply(lambda r: r.ne("").any(), axis=1)].reset_index(drop=True)
    if df.shape[1] == 0 or len(df) == 0:
        raise UploadError("The file has no data rows.", 422)
    if len(df) > max_rows:
        raise UploadError(f"Too many rows ({len(df):,}); the limit is {max_rows:,}.", 413)
    return df


def _norm(c: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(c).strip().lower()).strip("_")


def detect_mapping(columns: list[str]) -> dict:
    """Suggest which column holds each field, with a confidence and an ambiguity flag."""
    cand: dict[str, list[dict]] = {f: [] for f in FIELDS}
    for col in columns:
        n = _norm(col)
        for f, syns in SYNONYMS.items():
            conf = 0.0
            if n in syns:
                conf = 0.75 if n in AMBIGUOUS else 1.0
            elif any(len(s) > 3 and "_" not in s and s in n.split("_") for s in syns):
                conf = 0.7
            else:
                best = max(difflib.SequenceMatcher(None, n, s).ratio() for s in syns)
                if best >= 0.85:
                    conf = round(best * 0.8, 2)
            if conf:
                cand[f].append({"column": col, "confidence": conf})
    mapping, used = {}, set()
    for f in ["price", "product", "source", "currency", "date", "category", "brand", "rating"]:
        opts = sorted([o for o in cand[f] if o["column"] not in used], key=lambda o: -o["confidence"])
        if opts:
            top = opts[0]
            tie = len(opts) > 1 and opts[1]["confidence"] >= top["confidence"] - 0.05
            mapping[f] = {"column": top["column"], "confidence": top["confidence"],
                          "needs_confirmation": top["confidence"] < 0.8 or tie,
                          "candidates": [o["column"] for o in opts[:4]]}
            used.add(top["column"])
        else:
            mapping[f] = {"column": None, "confidence": 0.0, "needs_confirmation": f in REQUIRED, "candidates": []}
    return {f: mapping[f] for f in FIELDS}


def parse_price(v) -> tuple[float | None, str | None, str | None]:
    """Return (price, problem, currency_symbol_found). problem in {None,'missing','malformed','non_positive'}."""
    s = "" if v is None else str(v).strip()
    if s.lower() in MISSING_TOKENS:
        return None, "missing", None
    sym = None
    m = re.search(r"(?i)(rs\.?|inr|usd|eur|gbp|[₹$€£])", s)
    if m:
        sym = SYMBOL_CCY.get(m.group(1).lower().rstrip("."))
    s2 = re.sub(r"(?i)(rs\.?|inr|usd|eur|gbp|[₹$€£])", "", s).replace(" ", "")
    if re.fullmatch(r"-?\d{1,3}(\.\d{3})+,\d+", s2):
        s2 = s2.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d+,\d{1,2}", s2):
        s2 = s2.replace(",", ".")
    else:
        s2 = s2.replace(",", "")
    try:
        x = float(s2)
    except ValueError:
        return None, "malformed", sym
    if not math.isfinite(x) or x <= 0:
        return None, "non_positive", sym
    return x, None, sym


def describe_columns(df: pd.DataFrame) -> list[dict]:
    out = []
    for c in df.columns:
        col = df[c]
        nonempty = col[col.ne("")]
        n = max(len(nonempty), 1)
        num = sum(parse_price(x)[1] != "malformed" and parse_price(x)[0] is not None for x in nonempty.head(500))
        sample = nonempty.head(500)
        try:
            dt = pd.to_datetime(sample, errors="coerce", utc=True, format="mixed").notna().sum()
        except (TypeError, ValueError):
            dt = 0
        kind = "number" if num / min(n, 500) > 0.9 else "date" if dt / max(len(sample), 1) > 0.9 and not num else "text"
        out.append({"name": c, "type": kind, "non_empty": int(len(nonempty)), "missing": int(len(col) - len(nonempty)),
                    "samples": [str(x) for x in nonempty.head(3)]})
    return out


def normalize(df: pd.DataFrame, mapping: dict[str, str | None], observed_default: datetime | None = None) -> dict:
    """Turn the raw frame into clean observation records plus a full account of what was rejected."""
    observed_default = observed_default or datetime.now(timezone.utc)
    col = lambda f: mapping.get(f) if mapping.get(f) in df.columns else None
    for f in REQUIRED:
        if not col(f):
            raise UploadError(f"Required field '{f}' is not mapped to a column.", 422)
    dates = None
    if col("date"):
        try:
            dates = pd.to_datetime(df[col("date")].replace("", pd.NA), errors="coerce", utc=True, format="mixed")
        except (TypeError, ValueError):
            dates = pd.to_datetime(df[col("date")].replace("", pd.NA), errors="coerce", utc=True)
    records, issues, seen = [], [], set()
    c = {"rows_total": len(df), "skipped_no_product": 0, "skipped_bad_price": 0, "unavailable_price": 0,
         "duplicates_removed": 0, "dates_inferred": 0, "dates_unparseable": 0, "ratings_invalid": 0}
    for i in range(len(df)):
        row = df.iloc[i]
        rn = i + 2  # spreadsheet row number (header = row 1)
        name = row[col("product")].strip()
        if not name:
            c["skipped_no_product"] += 1; issues.append({"row": rn, "field": "product", "reason": "missing product name"}); continue
        if len(name) > 300:
            name = name[:300]; issues.append({"row": rn, "field": "product", "reason": "name truncated to 300 chars"})
        price, problem, sym = parse_price(row[col("price")])
        if problem in ("malformed", "non_positive"):
            c["skipped_bad_price"] += 1
            issues.append({"row": rn, "field": "price", "reason": f"{problem.replace('_', ' ')} price '{row[col('price')]}'"}); continue
        if problem == "missing":
            c["unavailable_price"] += 1
        ccy = None
        if col("currency"):
            raw = row[col("currency")].strip()
            ccy = SYMBOL_CCY.get(raw.lower()) or (raw.upper()[:3] if raw.isalpha() and len(raw) >= 3 else None)
        ccy = ccy or sym or "UNK"
        when, inferred = observed_default, True
        if dates is not None and pd.notna(dates.iloc[i]):
            when, inferred = dates.iloc[i].to_pydatetime(), False
        elif dates is not None and row[col("date")].strip():
            c["dates_unparseable"] += 1; issues.append({"row": rn, "field": "date", "reason": f"unparseable date '{row[col('date')]}'"})
        if inferred:
            c["dates_inferred"] += 1
        source = (row[col("source")].strip() if col("source") else "") or "unspecified"
        key = (name.lower(), source.lower(), when.isoformat(), price)
        if key in seen:
            c["duplicates_removed"] += 1; continue
        seen.add(key)
        rating = None
        if col("rating") and row[col("rating")].strip():
            try:
                r = float(row[col("rating")].replace(",", "."))
                rating = r if math.isfinite(r) and r >= 0 else None
            except ValueError:
                pass
            if rating is None:
                c["ratings_invalid"] += 1
        records.append({"name": name, "source": source[:100], "price": price, "currency": ccy, "observed_at": when,
                        "date_inferred": inferred, "category": (row[col("category")].strip()[:200] or None) if col("category") else None,
                        "brand": (row[col("brand")].strip()[:200] or None) if col("brand") else None, "rating": rating})
    valid = sum(1 for r in records if r["price"] is not None)
    skipped = c["skipped_no_product"] + c["skipped_bad_price"]
    return {"records": records, "issues": issues, "counts": {**c, "rows_valid": valid, "rows_skipped": skipped,
            "has_date_column": bool(col("date"))}}
