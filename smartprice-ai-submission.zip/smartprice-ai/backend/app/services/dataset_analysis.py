"""Real analysis of a persisted dataset. Everything is computed from stored observations."""
from __future__ import annotations

import json

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Dataset, PriceObservation, Product

OUTLIER_METHOD = ("Tukey IQR fences: within each product+source series with at least 5 prices, a price is flagged if it is "
                  "below Q1 - 1.5*IQR or above Q3 + 1.5*IQR. Flags are statistical hints, not errors.")


def _frame(db: Session, dataset: Dataset) -> pd.DataFrame:
    rows = db.execute(select(Product.name, Product.id, PriceObservation).join(Product, Product.id == PriceObservation.product_id)
                      .where(PriceObservation.dataset_id == dataset.id)).all()
    return pd.DataFrame([{"product": n, "pid": pid, "source": o.source, "price": o.price, "currency": o.currency, "t": o.observed_at,
                          "inferred": o.date_inferred, "category": o.category, "brand": o.brand, "rating": o.rating}
                         for n, pid, o in rows])


def meta(d: Dataset) -> dict:
    return {"id": d.id, "name": d.name, "filename": d.filename, "file_type": d.file_type, "file_size": d.file_size,
            "status": d.status, "is_demo": d.is_demo, "rows_total": d.rows_total, "rows_valid": d.rows_valid,
            "rows_skipped": d.rows_skipped, "created_at": d.created_at.isoformat(), "mapping": json.loads(d.mapping or "{}"),
            "columns": json.loads(d.columns or "[]"), "quality": json.loads(d.quality or "{}")}


def analyze(db: Session, dataset: Dataset) -> dict:
    df = _frame(db, dataset)
    q = json.loads(dataset.quality or "{}")
    out = {"dataset": meta(dataset), "is_demo": dataset.is_demo}
    if df.empty:
        return {**out, "enough_data": False, "insights": ["This dataset contains no stored observations."]}
    valid = df[df.price.notna()].copy()
    ccy_counts = valid.currency.value_counts()
    primary = ccy_counts.index[0] if len(ccy_counts) else None
    warnings = []
    if len(ccy_counts) > 1:
        warnings.append(f"Multiple currencies found ({', '.join(f'{c}: {n}' for c, n in ccy_counts.items())}); "
                        f"statistics use {primary} only and are not converted.")
    if primary == "UNK":
        warnings.append("No currency was given in the file; prices are shown without a currency.")
    if q.get("unavailable_price"):
        warnings.append(f"{q['unavailable_price']} rows had no price and are treated as unavailable (not zero).")
    if q.get("rows_skipped"):
        warnings.append(f"{q['rows_skipped']} rows were rejected (see issues list).")
    if q.get("duplicates_removed"):
        warnings.append(f"{q['duplicates_removed']} exact duplicate rows were removed.")
    if q.get("dates_inferred"):
        warnings.append(f"{q['dates_inferred']} rows had no usable date; they are stamped with the upload time and excluded from trends.")
    pv = valid[valid.currency == primary] if primary else valid
    stats = None
    if len(pv):
        stats = {"mean": round(float(pv.price.mean()), 2), "median": round(float(pv.price.median()), 2),
                 "min": float(pv.price.min()), "max": float(pv.price.max()),
                 "std": round(float(pv.price.std()), 2) if len(pv) > 1 else None, "currency": primary}
    real = pv[~pv.inferred]
    history = real.groupby("product").t.nunique()
    has_history = bool((history >= 2).any())
    # products
    products = []
    for name, g in pv.groupby("product"):
        latest = g.sort_values("t").groupby("source").tail(1)
        item = {"id": int(g.pid.iloc[0]), "name": name, "observations": int(len(g)), "sources": int(g.source.nunique()), "min": float(g.price.min()),
                "max": float(g.price.max()), "mean": round(float(g.price.mean()), 2), "latest": float(g.sort_values("t").price.iloc[-1]),
                "cheapest_source": latest.sort_values("price").source.iloc[0], "spread_pct": None, "change_pct": None}
        if len(latest) >= 2 and latest.price.min() > 0:
            item["spread_pct"] = round(float((latest.price.max() - latest.price.min()) / latest.price.min() * 100), 2)
        r = g[~g.inferred].sort_values("t")
        if r.t.nunique() >= 2 and r.price.iloc[0] > 0:
            item["change_pct"] = round(float((r.price.iloc[-1] - r.price.iloc[0]) / r.price.iloc[0] * 100), 2)
        products.append(item)
    products.sort(key=lambda p: -p["observations"])
    # distribution
    dist = []
    if len(pv):
        lo, hi = float(pv.price.min()), float(pv.price.max())
        if lo == hi:
            dist = [{"range": f"{lo:g}", "count": int(len(pv))}]
        else:
            counts, edges = np.histogram(pv.price, bins=min(10, max(2, int(len(pv) ** 0.5))))
            dist = [{"range": f"{edges[i]:,.0f}–{edges[i + 1]:,.0f}", "count": int(counts[i])} for i in range(len(counts))]
    cats = []
    if pv.category.notna().any():
        for c, g in pv.dropna(subset=["category"]).groupby("category"):
            cats.append({"category": c, "count": int(len(g)), "products": int(g["product"].nunique()), "mean_price": round(float(g.price.mean()), 2)})
        cats.sort(key=lambda x: -x["count"])
    # outliers
    outliers = []
    for (p, s), g in pv.groupby(["product", "source"]):
        if len(g) < 5:
            continue
        q1, q3 = g.price.quantile(.25), g.price.quantile(.75); iqr = q3 - q1
        if iqr <= 0:
            continue
        lo_f, hi_f = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        for r in g[(g.price < lo_f) | (g.price > hi_f)].itertuples():
            outliers.append({"product": p, "source": s, "price": float(r.price), "observed_at": r.t.isoformat(),
                             "expected_range": [round(float(lo_f), 2), round(float(hi_f), 2)]})
    trends = {"available": has_history, "items": [{"product": p["name"], "change_pct": p["change_pct"]} for p in products if p["change_pct"] is not None][:50],
              "note": None if has_history else "No price history: no product has two or more dated observations, so trends and "
                      "percentage changes cannot be calculated. Add a date/timestamp column with repeated observations per product."}
    # insights (every statement is backed by a calculation above)
    ins = [f"{len(products)} product(s) across {int(pv.source.nunique())} source(s); {len(pv)} valid price records."]
    if stats and len(products) == 1 and stats["median"] and abs(stats["mean"] - stats["median"]) / stats["median"] > 0.2:
        ins.append(f"Mean ({stats['mean']:,.0f}) and median ({stats['median']:,.0f}) differ by more than 20%, so prices are skewed; prefer the median.")
    spread = sorted([p for p in products if p["spread_pct"] is not None], key=lambda p: -p["spread_pct"])
    if spread:
        t = spread[0]; ins.append(f"Largest cross-source gap: '{t['name']}' is {t['spread_pct']}% cheaper at {t['cheapest_source']} than at the most expensive source (latest prices).")
    else:
        ins.append("Competitor comparison needs the same product listed by at least two sources; none found in this dataset.")
    moved = sorted([p for p in products if p["change_pct"] is not None], key=lambda p: -abs(p["change_pct"]))
    if moved:
        t = moved[0]; ins.append(f"Largest price move: '{t['name']}' changed {t['change_pct']}% between its first and latest dated observation.")
    else:
        ins.append(trends["note"])
    if outliers:
        ins.append(f"{len(outliers)} unusual price(s) flagged by the IQR method; review them before relying on averages.")
    return {**out, "enough_data": len(pv) > 0, "summary": {"records": int(len(df)), "valid_prices": int(len(valid)),
            "unavailable": int(len(df) - len(valid)), "unique_products": int(df["product"].nunique()), "sources": int(df.source.nunique()),
            "currencies": [str(c) for c in ccy_counts.index], "primary_currency": primary, "has_history": has_history,
            "date_range": None if real.empty else {"from": real.t.min().isoformat(), "to": real.t.max().isoformat()}},
            "price_stats": stats, "quality": {**q, "warnings": warnings}, "products": products[:200], "distribution": dist,
            "categories": cats, "outliers": {"method": OUTLIER_METHOD, "items": outliers[:100]}, "trends": trends, "insights": ins}
