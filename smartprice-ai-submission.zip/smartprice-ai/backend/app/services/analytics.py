import pandas as pd

def summarize(observations) -> dict:
    rows = [{"t": o.observed_at, "price": o.price} for o in observations
            if o.price is not None and o.status != "failed"]
    if len(rows) < 2:
        return {"enough_data": False, "points": len(rows),
                "note": "At least 2 real observations are needed for trend analysis."}
    df = pd.DataFrame(rows).sort_values("t")
    first, last = float(df.price.iloc[0]), float(df.price.iloc[-1])
    unusual = []
    if len(df) >= 5 and df.price.std():
        m, s = df.price.mean(), df.price.std()
        unusual = [{"t": str(r.t), "price": float(r.price)} for r in df.itertuples() if abs(r.price - m) > 2 * s]
    return {"enough_data": True, "points": len(df), "first": first, "latest": last,
            "change_abs": round(last - first, 2),
            "change_pct": round((last - first) / first * 100, 2) if first else None,
            "min": float(df.price.min()), "max": float(df.price.max()), "unusual": unusual}

def insight_text(name: str, s: dict) -> dict:
    if not s["enough_data"]:
        return {"mode": "deterministic", "text": f"{name}: {s['note']}"}
    d = "down" if s["change_abs"] < 0 else "up" if s["change_abs"] > 0 else "flat"
    rec = ("Price is near its observed low; reasonable time to buy." if s["latest"] <= s["min"] * 1.02
           else "Price is above its observed low; consider waiting or setting an alert.")
    return {"mode": "deterministic",
            "text": f"{name} is {d} {abs(s['change_pct'] or 0)}% across {s['points']} observations "
                    f"(low {s['min']}, high {s['max']}). {rec}"}
