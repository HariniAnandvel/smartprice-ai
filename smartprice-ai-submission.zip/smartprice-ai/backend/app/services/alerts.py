from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import Alert, PriceObservation, Notification, now

def evaluate(db: Session, product_id: int, new_obs: PriceObservation) -> list:
    if new_obs.price is None:
        return []
    prev = db.scalars(select(PriceObservation).where(
        PriceObservation.product_id == product_id, PriceObservation.price.is_not(None),
        PriceObservation.id != new_obs.id).order_by(PriceObservation.observed_at.desc())).first()
    fired = []
    for a in db.scalars(select(Alert).where(Alert.product_id == product_id, Alert.enabled.is_(True))):
        hit = (a.kind == "target_price" and new_obs.price <= a.threshold) or \
              (a.kind == "pct_drop" and prev and prev.price and
               (prev.price - new_obs.price) / prev.price * 100 >= a.threshold)
        if hit:
            a.last_triggered_at = now()
            db.add(Notification(user_id=a.user_id, alert_id=a.id,
                                message=f"Alert {a.id} triggered at {new_obs.price} {new_obs.currency} ({new_obs.source})"))
            fired.append(a)
    return fired  # in-app only; email/push are not configured and not claimed
