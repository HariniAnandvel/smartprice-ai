import io
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, Spacer
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.lineplots import LinePlot

def build_pdf(product: str, summary: dict, obs: list, is_demo: bool) -> bytes:
    buf = io.BytesIO(); st = getSampleStyleSheet()
    els = [Paragraph(f"Price Report: {product}", st["Title"])]
    if is_demo: els.append(Paragraph("<b>Contains demonstration data.</b>", st["Normal"]))
    if summary["enough_data"]:
        els.append(Paragraph(f"Change: {summary['change_abs']} ({summary['change_pct']}%). "
                             f"Low {summary['min']}, high {summary['max']}, {summary['points']} observations.", st["Normal"]))
        pts = [(i, o.price) for i, o in enumerate(obs) if o.price is not None]
        d = Drawing(400, 180); lp = LinePlot(); lp.x, lp.y, lp.width, lp.height = 30, 20, 350, 140
        lp.data = [pts]; d.add(lp); els += [Spacer(1, 10), d]
    else:
        els.append(Paragraph(summary["note"], st["Normal"]))
    rows = [["Source", "Price", "Cur", "Observed at"]] + [
        [o.source, "n/a" if o.price is None else o.price, o.currency, o.observed_at.strftime("%Y-%m-%d %H:%M")] for o in obs[-40:]]
    els += [Spacer(1, 10), Table(rows, repeatRows=1)]
    els.append(Paragraph("Methodology: prices are persisted observations; unavailable prices are excluded from "
                         "statistics, never treated as zero. Latest 40 rows shown.", st["Italic"]))
    SimpleDocTemplate(buf, pagesize=A4).build(els)
    return buf.getvalue()
