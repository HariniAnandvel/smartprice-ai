import httpx
from ..core.config import settings
from . import analytics

def answer(question: str, name: str, summary: dict) -> dict:
    """Uses the LLM only if LLM_API_KEY is set; sends only the computed summary, never raw DB."""
    if not settings.LLM_API_KEY:
        return {**analytics.insight_text(name, summary),
                "note": "No LLM key configured; question not interpreted. Showing deterministic analysis."}
    try:
        r = httpx.post("https://api.anthropic.com/v1/messages", timeout=30,
            headers={"x-api-key": settings.LLM_API_KEY, "anthropic-version": "2023-06-01"},
            json={"model": "claude-sonnet-4-6", "max_tokens": 500,
                  "system": "Answer only from the provided price summary. If it lacks the answer, say so.",
                  "messages": [{"role": "user", "content": f"Product: {name}\nSummary: {summary}\nQuestion: {question}"}]})
        r.raise_for_status()
        return {"mode": "llm", "text": r.json()["content"][0]["text"]}
    except (httpx.HTTPError, KeyError, IndexError):
        return {**analytics.insight_text(name, summary), "note": "LLM call failed; showing deterministic analysis."}
