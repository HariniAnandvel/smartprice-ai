from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from .config import settings

args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(settings.DATABASE_URL, connect_args=args)
SessionLocal = sessionmaker(bind=engine, autoflush=False)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def migrate_schema(eng=None):
    """Upgrade an older SQLite database in place (adds dataset columns, drops the old
    per-row uniqueness constraint that made re-imports crash). No-op for new databases.
    Safe to re-run: it resumes if an earlier attempt stopped half way (SQLite DDL is not transactional)."""
    from sqlalchemy import inspect
    eng = eng or engine
    if eng.dialect.name != "sqlite":
        return
    from ..models import PriceObservation
    insp = inspect(eng)
    tables = insp.get_table_names()
    OLD = "price_observations_old"
    if "price_observations" in tables:
        cols = {c["name"] for c in insp.get_columns("price_observations")}
        has_uq = any(u.get("name") == "uq_obs" for u in insp.get_unique_constraints("price_observations"))
        if "dataset_id" in cols and not has_uq:
            if OLD in tables:  # an earlier attempt stopped half way and create_all made the new table: finish the copy
                with eng.begin() as cx:
                    if cx.exec_driver_sql("SELECT COUNT(*) FROM price_observations").scalar() == 0:
                        old_cols = {c["name"] for c in inspect(eng).get_columns(OLD)}
                        shared = ", ".join(c for c in old_cols if c in PriceObservation.__table__.columns)
                        cx.exec_driver_sql(f"INSERT INTO price_observations ({shared}) SELECT {shared} FROM {OLD}")
                    cx.exec_driver_sql(f"DROP TABLE {OLD}")
            return
        index_names = [ix["name"] for ix in insp.get_indexes("price_observations")]  # read BEFORE renaming
        with eng.begin() as cx:
            if OLD in tables:
                cx.exec_driver_sql(f"DROP TABLE {OLD}")  # stale leftover of a failed attempt
            cx.exec_driver_sql(f"ALTER TABLE price_observations RENAME TO {OLD}")
            for name in index_names:
                cx.exec_driver_sql(f'DROP INDEX IF EXISTS "{name}"')
    elif OLD not in tables:
        return
    old_cols = {c["name"] for c in inspect(eng).get_columns(OLD)}
    with eng.begin() as cx:
        PriceObservation.__table__.create(cx, checkfirst=True)
        shared = ", ".join(c for c in old_cols if c in PriceObservation.__table__.columns)
        cx.exec_driver_sql(f"INSERT INTO price_observations ({shared}) SELECT {shared} FROM {OLD}")
        cx.exec_driver_sql(f"DROP TABLE {OLD}")
