from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    SECRET_KEY: str = "dev-only-change-me"
    DATABASE_URL: str = "sqlite:///./smartprice.db"
    CORS_ORIGINS: str = "http://localhost:5173"
    LLM_API_KEY: str = ""
    ENVIRONMENT: str = "development"  # set to "production" when deployed
    MAX_UPLOAD_MB: int = 10
    MAX_UPLOAD_ROWS: int = 200_000
    TOKEN_MINUTES: int = 60 * 8
    class Config:
        env_file = ".env"

settings = Settings()
