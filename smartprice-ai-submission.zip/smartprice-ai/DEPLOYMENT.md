# Deployment guide (backend on Render, frontend on Vercel)

> Status: **not deployed yet.** `render.yaml` is an untested template. No public URL exists until you complete these steps and test it. Free-tier limits change; check each provider's current terms.

## 0. Prerequisites
- The code is on GitHub (public repository).
- Free accounts on Render (render.com) and Vercel (vercel.com), both can sign in with GitHub.

## 1. Backend → Render
1. Render dashboard → **New → Blueprint** (uses `render.yaml`) or **New → Web Service** with: Root Directory `backend`, Build `pip install -r requirements.txt`, Start `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.
2. Environment variables: `ENVIRONMENT=production`, `SECRET_KEY` = a long random value (`python -c "import secrets;print(secrets.token_urlsafe(48))"`), `PYTHON_VERSION=3.12.3`. Leave `LLM_API_KEY` empty unless you have your own key (optional).
3. Deploy, then open `https://<your-service>.onrender.com/api/health`. Expected: `{"ok":true}`.
4. Limits: on the free plan the service sleeps when idle (first request can take about a minute) and the SQLite file is **not persistent** — data resets on restart/redeploy. Fine for a demo; use a managed database for real use (not implemented or tested here).

## 2. Frontend → Vercel
1. Vercel → **Add New → Project** → import the repository.
2. Root Directory: `frontend`. Framework preset: Vite. Build command `npm run build`, output `dist`.
3. Environment variable: `VITE_API_URL=https://<your-service>.onrender.com` (no trailing slash).
4. Deploy. `frontend/vercel.json` already rewrites all routes to `index.html` so page refreshes and deep links work.

## 3. Connect them (CORS)
In Render set `CORS_ORIGINS=https://<your-project>.vercel.app` (comma-separate several origins), then restart the service. Without this the browser blocks API calls.

## 4. Test the public deployment
1. Open the Vercel URL in a private window. 2. Register and log in. 3. Upload `sample-data/smartprice_demo_data.csv` and confirm the dashboard fills. 4. Refresh the page; the dataset should remain (until the free backend restarts). 5. Download a CSV and a PDF report. 6. Open the browser console and check there are no red errors.

## 5. Troubleshooting
- "Cannot reach the server": wrong `VITE_API_URL`, or the backend is asleep; open `/api/health` first and wait.
- Login works locally but not online: `CORS_ORIGINS` missing or has a trailing slash.
- Backend fails to start with a `SECRET_KEY` message: set a real `SECRET_KEY` (this is the production guard working).
- Blank page on refresh: check `vercel.json` is inside `frontend/`.
