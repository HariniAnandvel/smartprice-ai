# Upload → Analysis repair: what changed and why

## Root causes (found by reading the code)
1. **Backend `/api/import/csv` only accepted columns named exactly `name`, `source`, `price`.** Any other header (e.g. `product_name`) raised `KeyError` for every row; the error was swallowed and counted as "skipped" with no reason. The sample CSV imported **0 rows**.
2. It silently truncated files over 2 MB, accepted only UTF-8 CSV (no XLSX/XLS), checked nothing about the file contents, and re-importing the same file hit a DB uniqueness constraint (HTTP 500).
3. **The frontend only showed a toast** ("Imported N, skipped M"). Nothing was stored in state, there was no preview/mapping, no dataset id, and the dashboard never learned a file existed. The file input was also not reset, so re-picking the same file did nothing.
4. There was **no dataset concept**: the dashboard showed only the first product's history; nothing could be selected, listed after refresh or deleted.
5. **Route transitions never ran between in-app pages** (constant `Routes` key + page wrappers inside nested routes); a lazy page suspending would also blank the whole layout.

## What was built
Backend (`backend/app`)
- `services/ingest.py` – extension + file-signature + size validation, CSV (delimiter/encoding detection) / XLSX / XLS reading, synonym + fuzzy column mapping with confidence and ambiguity flags, price parsing (₹, $, `1,299.50`, `1.299,50`), row-level rejection with reasons, duplicate removal, honest date handling (missing dates are flagged `date_inferred`, never invented).
- `api/datasets.py` – `POST /datasets/preview`, `POST /datasets` (multipart), `GET /datasets`, `/datasets/{id}`, `/analysis`, `/records`, `DELETE`. SHA-256 duplicate-upload detection (409, override with `force`).
- `services/dataset_analysis.py` – pandas analysis from the stored rows: counts, mean/median/min/max/std, per-product and cross-source gaps, distribution, categories, IQR outliers (method stated), trends only when dated history exists, data-quality warnings, insights derived from the numbers.
- `models` – `Dataset` table; observations carry `dataset_id`, category, brand, rating, `date_inferred`. `core/db.py::migrate_schema` upgrades an existing SQLite file in place (keeps data, removes the old uniqueness constraint, resumes if interrupted).
- Existing endpoints (`products`, `analytics`, `competitors`, `insights`, reports) accept `?dataset_id=`. Demo seeding is idempotent and creates a dataset flagged DEMO. URL collection feeds a "Live collection" dataset. The old `/import/csv` still works but now uses the same pipeline.

Frontend (`frontend/src`)
- `pages/Upload.tsx` – drag/drop zone with 3D-tilt illustration, real byte-level progress (XHR), validating/reading/mapping/analysing/completed/partial/failed/cancelled states, cancellation, mapping review, data preview, processing log, retry, duplicate handling, upload history with open/delete. The success animation fires only after the backend returns the saved dataset.
- `components/datasets.tsx` – one dataset context (persisted selection, validated against the backend, version counter so pages refetch); dataset selector in the top bar.
- `pages/Dashboard.tsx` – every number/chart comes from `/datasets/{id}/analysis`; honest empty and "no history" states; DEMO DATA badge; animated counters and staggered entrance.
- All other pages are scoped to the selected dataset.
- `layouts/AppLayout.tsx` – keyed `AnimatePresence` page transitions (fade/slide/blur, reduced-motion aware), `Suspense` inside the layout so the sidebar never blanks.
- `services/api.ts` – structured `ApiError`, explicit "cannot reach the server" message, `uploadForm` with progress/abort.

## Tests that were executed
- Backend: `cd backend && pytest` → 31 passed (6 original + 25 new).
- Frontend: `cd frontend && npm test` → 15 passed; `npx tsc --noEmit` clean; `npm run build` succeeds.
- Manual API run against a live uvicorn: your earlier `smartprice_demo_data.csv` → 360 rows read, 359 valid, 1 unavailable, 4 products, planted price drop flagged, duplicate re-upload rejected (409), `.exe` rejected (415).

## NOT verified / not done
- **Nothing was opened in a real browser** (none available here): the 3D hero, the dropzone illustration, glass styling, responsive layouts at tablet/mobile and the page transitions are untested visually. Frontend tests run in jsdom only.
- The wider "premium redesign" was only partly done: new Upload/Dashboard pages, layout transitions, counters and the dropzone visual. Landing hero, Alerts, Settings, Reports styling and a full responsive audit are untouched.
- PDF upload is not supported (not needed for price data). Excel: first sheet only. XLS needs `xlrd`.
- Upload progress is real for bytes sent; server-side processing time is shown as indeterminate.
- Not tested: a live LLM provider, live-site scraping, email/push (not implemented).
- Auth token is still in localStorage (fine locally; use HTTP-only cookies for production).
- Shared-element transitions and chart-entrance choreography beyond the dashboard are not implemented.
