# SmartPrice AI Ultra

A full-stack price-intelligence web app. Upload a price file (CSV / XLSX / XLS) or collect a public product page, and the app parses the real contents, saves them as a dataset, and analyses them: statistics, competitor gaps, price history, unusual prices, data-quality warnings, alerts and downloadable reports.

> Demo data is always labelled **DEMO DATA**. Sample files in `sample-data/` are synthetic, not real market prices.

## Features
- **Upload pipeline:** drag & drop, file-signature/size validation, automatic column detection with a confirmation step, data preview, real upload progress, cancel/retry, duplicate-file detection, upload history that survives a refresh.
- **Analysis (computed from stored rows, never invented):** record/product/source counts, mean/median/min/max, per-product and cross-source price gaps, price distribution, IQR outlier detection, trends only when dated history exists, data-quality warnings, deterministic insights.
- **Datasets:** switch between uploads; every page (dashboard, trends, competitors, insights, reports) follows the selected dataset.
- **Collection:** public product pages via structured JSON-LD data; private/internal addresses blocked; robots.txt respected; no login/CAPTCHA bypass.
- **Alerts:** target-price and %-drop alerts evaluated on new data; in-app notifications only (email/push are not implemented).
- **Reports:** CSV and PDF export. **Settings:** profile, theme, simplified motion, password change, data wipe, audit log.
- **AI:** optional LLM answers only if `LLM_API_KEY` is set (not tested against a live provider); otherwise a clearly labelled deterministic fallback.

## Technologies
Backend: Python 3.11+, FastAPI, SQLAlchemy (SQLite), pandas, openpyxl, xlrd, JWT (python-jose), bcrypt, ReportLab, pytest.
Frontend: React 18, TypeScript, Vite, Tailwind CSS, Framer Motion, React Three Fiber / three.js (landing page), Recharts, Vitest.

## Install and run (Windows / macOS / Linux)
Prerequisites: Python 3.11+ and Node.js 20+ (LTS).

Backend (terminal 1):
```
cd backend
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env          # macOS/Linux: cp .env.example .env
uvicorn app.main:app --reload   # API docs: http://localhost:8000/docs
```
Frontend (terminal 2):
```
cd frontend
npm install
npm run dev                     # http://localhost:5173
```
The database (`smartprice.db`) is created automatically; older databases are upgraded in place.

## Configuration
Backend `backend/.env` (see `.env.example`): `ENVIRONMENT`, `SECRET_KEY`, `DATABASE_URL`, `CORS_ORIGINS`, `MAX_UPLOAD_MB`, `MAX_UPLOAD_ROWS`, `LLM_API_KEY` (optional).
Frontend `frontend/.env`: `VITE_API_URL` (backend URL, default `http://localhost:8000`).
With `ENVIRONMENT=production` the backend refuses to start unless `SECRET_KEY` is changed.

## Usage
1. Register and log in. 2. Open **Upload & data** and drop `sample-data/smartprice_demo_data.csv`. 3. Check the column mapping and click **Analyse & save**. 4. Open the dashboard; switch datasets from the top bar. 5. Try Trends, Competitors, Alerts, Reports (CSV/PDF) and Settings.

## Tests
```
cd backend && pytest        # backend: parser, pipeline, analysis, auth, migration
cd frontend && npm test     # frontend: upload flow, dashboard, navigation, API errors
cd frontend && npx tsc --noEmit && npm run build
```

## Deployment (summary — details in `DEPLOYMENT.md`)
Backend on Render (`render.yaml`, untested template), frontend on Vercel (`frontend/vercel.json`, set `VITE_API_URL`). On free hosting the SQLite file is not persistent.

## Known limitations
See `CHANGES.md` and the Testing section of the prompt documentation. Notably: the visual design and 3D scene have not been checked in a real browser by the author of this repair; PDF upload unsupported; Excel reads the first sheet only; auth token is stored in localStorage; no live LLM or live-site collection testing.

Documentation of the AI-assisted development process: `docs/PROMPT_DOCUMENTATION.md`.
