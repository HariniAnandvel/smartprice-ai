import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { api, setToken } from '../services/api'
import { GlassCard, GlassButton, GradientText } from '../components/ui'

const loginS = z.object({ email: z.string().email('Enter a valid email'), password: z.string().min(1, 'Password required') })
const regS = z.object({ name: z.string().min(1, 'Name required'), email: z.string().email('Enter a valid email'),
  password: z.string().min(8, 'At least 8 characters'), confirm: z.string() }).refine(d => d.password === d.confirm, { path: ['confirm'], message: 'Passwords do not match' })

export default function Auth({ mode }: { mode: 'login' | 'register' }) {
  const reg = mode === 'register'
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<any>({ resolver: zodResolver(reg ? regS : loginS) })
  const [show, setShow] = useState(false); const [err, setErr] = useState(''); const nav = useNavigate()
  const submit = async (v: any) => {
    setErr('')
    try {
      const r = reg ? await api('/auth/register', { method: 'POST', body: JSON.stringify({ name: v.name, email: v.email, password: v.password }) })
                    : await api('/auth/login', { method: 'POST', form: { username: v.email, password: v.password } })
      setToken(r.access_token); nav('/dashboard')
    } catch (e: any) { setErr(e.message) }
  }
  const F = ({ name, label, type = 'text' }: { name: string; label: string; type?: string }) => <div>
    <label htmlFor={name} className="text-sm text-slate-300">{label}</label>
    <div className="relative"><input id={name} type={type === 'password' && show ? 'text' : type} className="input mt-1" {...register(name)} aria-invalid={!!errors[name]} />
      {name === 'password' && <button type="button" aria-label="Toggle password visibility" className="absolute right-3 top-4 text-slate-400" onClick={() => setShow(!show)}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>}</div>
    {errors[name] && <p className="text-rose-400 text-xs mt-1">{String(errors[name]?.message)}</p>}</div>
  return <div className="min-h-screen grid place-items-center p-4"><GlassCard className="w-full max-w-md p-8">
    <h1 className="text-2xl font-bold mb-1"><GradientText>{reg ? 'Create account' : 'Welcome back'}</GradientText></h1>
    <p className="text-slate-400 text-sm mb-6">SmartPrice AI Ultra</p>
    <form onSubmit={handleSubmit(submit)} className="space-y-4" noValidate>
      {reg && <F name="name" label="Name" />}<F name="email" label="Email" type="email" /><F name="password" label="Password" type="password" />
      {reg && <F name="confirm" label="Confirm password" type="password" />}
      {err && <p role="alert" className="text-rose-400 text-sm">{err}</p>}
      <GlassButton type="submit" disabled={isSubmitting} className="w-full">{isSubmitting ? 'Please wait…' : reg ? 'Sign up' : 'Log in'}</GlassButton></form>
    <p className="text-sm text-slate-400 mt-5">{reg ? 'Have an account? ' : 'New here? '}<Link className="text-cyan-300" to={reg ? '/login' : '/register'}>{reg ? 'Log in' : 'Create account'}</Link></p>
  </GlassCard></div>
}
