import { Suspense, lazy, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useSimple } from '../components/prefs'
import { Radar, BellRing, LineChart, ShieldCheck, Menu, X } from 'lucide-react'
import { GlassCard, GlassButton, GradientText } from '../components/ui'
const Hero3D = lazy(() => import('../components/Hero3D'))

const features = [
  { i: Radar, t: 'Permitted data collection', d: 'Public pages, robots.txt respected, CSV import fallback.' },
  { i: LineChart, t: 'Honest trend analytics', d: 'Only real observations. No fabricated history.' },
  { i: BellRing, t: 'Price alerts', d: 'Target-price and percentage-drop rules evaluated on every new price.' },
  { i: ShieldCheck, t: 'Secure by design', d: 'SSRF protection, hashed passwords, validated inputs.' }]

export default function Landing() {
  const reduce = useSimple(); const [menu, setMenu] = useState(false)
  const webgl = typeof document !== 'undefined' && !!document.createElement('canvas').getContext('webgl')
  const nav = <><a href="#features" className="hover:text-cyan-300">Features</a><a href="#workflow" className="hover:text-cyan-300">Workflow</a>
    <Link to="/login" className="hover:text-cyan-300">Log in</Link></>
  return <div className="scroll-smooth">
    <header className="glass sticky top-3 mx-3 z-20 rounded-2xl px-5 py-3 flex items-center justify-between">
      <b className="gradient-text">SmartPrice AI</b>
      <nav className="hidden md:flex gap-6 text-sm">{nav}</nav>
      <button className="md:hidden" aria-label="Menu" onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button></header>
    {menu && <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="glass md:hidden mx-3 mt-2 rounded-2xl p-4 flex flex-col gap-3" onClick={() => setMenu(false)}>{nav}</motion.div>}
    <section className="max-w-6xl mx-auto grid md:grid-cols-2 items-center gap-6 px-5 py-16 min-h-[80vh]">
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }}>
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight"><GradientText>Smarter Prices.</GradientText><br />Bigger Opportunities.</h1>
        <p className="text-slate-300 mt-5 max-w-lg">Collect permitted public product data, track price history, compare competitors, and get explainable recommendations from your own records.</p>
        <div className="flex gap-3 mt-8 flex-wrap"><Link to="/dashboard"><GlassButton>Explore Dashboard</GlassButton></Link><a href="#features"><GlassButton variant="ghost">Discover Features</GlassButton></a></div>
      </motion.div>
      <div className="h-80 md:h-[28rem]">{webgl ? <Suspense fallback={null}><Hero3D reduce={reduce} /></Suspense>
        : <div className="h-full rounded-full bg-gradient-to-br from-sky-500/30 to-fuchsia-500/30 blur-2xl" />}</div></section>
    <section id="features" className="max-w-6xl mx-auto px-5 py-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {features.map(({ i: I, t, d }, k) => <motion.div key={t} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: k * .08 }}>
        <GlassCard className="p-6 h-full"><I className="text-cyan-300 mb-3" /><h3 className="font-semibold">{t}</h3><p className="text-sm text-slate-400 mt-1">{d}</p></GlassCard></motion.div>)}</section>
    <section id="workflow" className="max-w-4xl mx-auto px-5 py-16 text-center">
      <h2 className="text-3xl font-bold mb-8">How it works</h2>
      <div className="grid sm:grid-cols-3 gap-4">{['Collect or import prices', 'Analyze real trends', 'Act on alerts & reports'].map((s, n) =>
        <GlassCard key={s} className="p-6"><div className="text-3xl font-bold gradient-text">{n + 1}</div><p className="mt-2">{s}</p></GlassCard>)}</div></section>
    <footer className="text-center text-slate-500 text-sm py-10">© SmartPrice AI Ultra</footer></div>
}
