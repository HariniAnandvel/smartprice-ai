import { useState } from 'react'
import { getToken } from '../services/api'
import { GlassCard, GlassButton, GradientText, EmptyState } from '../components/ui'
import { useProducts, useToast } from '../components/extra'

export default function Reports() {
  const { items, id, Select, dq } = useProducts(); const [busy, setBusy] = useState(''); const toast = useToast()
  const get = async (fmt: 'csv' | 'pdf') => { setBusy(fmt)
    try { const r = await fetch(`${import.meta.env.VITE_API_URL ?? 'http://localhost:8000'}/api/reports/${id}/${fmt}${dq}`, { headers: { Authorization: `Bearer ${getToken()}` } })
      if (!r.ok) throw new Error(`Report failed (${r.status})`)
      const a = document.createElement('a'); a.href = URL.createObjectURL(await r.blob()); a.download = `report-${id}.${fmt}`; a.click(); toast(`${fmt.toUpperCase()} report downloaded`) }
    catch (x: any) { toast(x.message, true) } finally { setBusy('') } }
  if (items && !items.length) return <EmptyState title="No data to report" text="Add price data first." />
  return <div className="space-y-4 max-w-2xl"><h1 className="text-2xl font-bold"><GradientText>Reports</GradientText></h1>
    <GlassCard className="p-5 space-y-4">{Select}<div className="flex gap-3"><GlassButton disabled={!id || !!busy} onClick={() => get('csv')}>{busy === 'csv' ? 'Generating…' : 'Export CSV'}</GlassButton>
      <GlassButton variant="ghost" disabled={!id || !!busy} onClick={() => get('pdf')}>{busy === 'pdf' ? 'Generating…' : 'Download PDF'}</GlassButton></div>
      <p className="text-xs text-slate-400">PDF includes a price chart, source table, timestamps and methodology. Unavailable prices are excluded, never treated as zero.</p></GlassCard></div>
}
