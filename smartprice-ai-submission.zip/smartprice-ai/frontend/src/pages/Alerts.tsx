import { useEffect, useState } from 'react'
import { api } from '../services/api'
import { GlassCard, GlassButton, GradientText, EmptyState } from '../components/ui'
import { useProducts, useToast, ConfirmDialog } from '../components/extra'

export default function Alerts() {
  const { items, id, Select } = useProducts(); const [list, setList] = useState<any[]>([]); const [kind, setKind] = useState('target_price'); const [th, setTh] = useState(''); const [del, setDel] = useState<number | null>(null); const [edit, setEdit] = useState<number | null>(null); const toast = useToast()
  const load = () => api('/alerts').then(setList); useEffect(() => { load() }, [])
  const name = (pid: number) => items?.find(p => p.id === pid)?.name ?? `Product ${pid}`
  const save = async (e: React.FormEvent) => { e.preventDefault()
    try { if (edit) await api(`/alerts/${edit}`, { method: 'PATCH', body: JSON.stringify({ kind, threshold: +th }) }); else await api('/alerts', { method: 'POST', body: JSON.stringify({ product_id: id, kind, threshold: +th }) })
      setEdit(null); setTh(''); load(); toast('Alert saved') } catch (x: any) { toast(x.message, true) } }
  const toggle = async (a: any) => { await api(`/alerts/${a.id}`, { method: 'PATCH', body: JSON.stringify({ enabled: !a.enabled }) }); load() }
  return <div className="space-y-4 max-w-3xl"><h1 className="text-2xl font-bold"><GradientText>Price alerts</GradientText></h1>
    <GlassCard className="p-5"><form onSubmit={save} className="grid sm:grid-cols-4 gap-3 items-end">{!edit && Select}
      <label className="text-sm text-slate-300">Condition<select className="input mt-1" value={kind} onChange={e => setKind(e.target.value)}><option value="target_price" className="bg-slate-900">Price at or below</option><option value="pct_drop" className="bg-slate-900">Drop of at least %</option></select></label>
      <label className="text-sm text-slate-300">Threshold<input className="input mt-1" type="number" step="any" min="0.01" required value={th} onChange={e => setTh(e.target.value)} /></label>
      <GlassButton type="submit" disabled={!id}>{edit ? 'Update' : 'Create'}</GlassButton></form>
      <p className="text-xs text-slate-400 mt-3">Triggered alerts appear as in-app notifications. Email and push are not configured.</p></GlassCard>
    {list.length ? list.map(a => <GlassCard key={a.id} className="p-4 flex flex-wrap gap-3 justify-between items-center text-sm"><div><b>{name(a.product_id)}</b> · {a.kind === 'target_price' ? `≤ ${a.threshold}` : `drop ≥ ${a.threshold}%`}
      <div className="text-slate-400 text-xs">{a.last_triggered_at ? `Last triggered ${new Date(a.last_triggered_at).toLocaleString()}` : 'Never triggered'}</div></div>
      <div className="flex gap-3"><button onClick={() => toggle(a)} className="text-cyan-300">{a.enabled ? 'Disable' : 'Enable'}</button><button onClick={() => { setEdit(a.id); setKind(a.kind); setTh(String(a.threshold)) }}>Edit</button><button className="text-rose-300" onClick={() => setDel(a.id)}>Delete</button></div></GlassCard>)
      : <EmptyState title="No alerts" text="Create one above." />}
    {del && <ConfirmDialog text="Delete this alert?" onNo={() => setDel(null)} onYes={async () => { await api(`/alerts/${del}`, { method: 'DELETE' }); setDel(null); load() }} />}</div>
}
