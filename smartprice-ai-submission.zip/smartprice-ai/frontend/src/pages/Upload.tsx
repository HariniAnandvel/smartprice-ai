import { useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { FileSpreadsheet, Trash2, XCircle, AlertTriangle } from 'lucide-react'
import { api, uploadForm, ApiError } from '../services/api'
import { GlassCard, GlassButton, GradientText, Skeleton } from '../components/ui'
import { useToast, ConfirmDialog } from '../components/extra'
import { useSimple } from '../components/prefs'
import { useDatasets, StatusBadge } from '../components/datasets'

const MAX_MB = 10   // mirrors backend MAX_UPLOAD_MB; the backend is authoritative
const FIELDS: [string, string, boolean][] = [['product', 'Product name', true], ['price', 'Price', true], ['source', 'Source / store', false], ['currency', 'Currency', false],
  ['date', 'Date / timestamp', false], ['category', 'Category', false], ['brand', 'Brand', false], ['rating', 'Rating', false]]
type Phase = 'idle' | 'validating' | 'mapping' | 'saving' | 'done' | 'partial' | 'failed' | 'cancelled'
const fmtSize = (n: number) => n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`

function DropVisual({ active }: { active: boolean }) {
  const simple = useSimple(); const [t, setT] = useState({ x: 0, y: 0 })
  const sheets = [0, 1, 2]
  return <div className="h-40 grid place-items-center" style={{ perspective: 700 }} onMouseMove={e => { if (simple) return; const r = e.currentTarget.getBoundingClientRect(); setT({ x: ((e.clientY - r.top) / r.height - .5) * -22, y: ((e.clientX - r.left) / r.width - .5) * 26 }) }} onMouseLeave={() => setT({ x: 0, y: 0 })}>
    <motion.div aria-hidden style={{ transformStyle: 'preserve-3d', rotateX: 55 + t.x, rotateZ: -28 + t.y }} animate={simple ? {} : { y: active ? -8 : [0, -6, 0] }} transition={{ duration: active ? .2 : 4, repeat: active ? 0 : Infinity, ease: 'easeInOut' }} className="relative w-28 h-36">
      {sheets.map(i => <div key={i} className="absolute inset-0 rounded-xl border border-cyan-300/40" style={{ transform: `translateZ(${i * 18}px)`, background: `linear-gradient(135deg, rgba(56,189,248,${.22 - i * .05}), rgba(167,139,250,${.2 - i * .04}))`, boxShadow: active ? '0 0 30px rgba(34,211,238,.45)' : '0 8px 24px rgba(0,0,0,.35)' }}>
        {i === 2 && <div className="p-3 space-y-2">{[70, 90, 55, 80].map((w, k) => <div key={k} className="h-1.5 rounded bg-white/40" style={{ width: `${w}%` }} />)}</div>}</div>)}
    </motion.div></div>
}

function SuccessMark({ partial }: { partial: boolean }) {
  const simple = useSimple(); const c = partial ? '#fbbf24' : '#34d399'
  return <div className="relative w-20 h-20 mx-auto" aria-hidden>
    {!simple && [0, 1].map(i => <motion.span key={i} className="absolute inset-0 rounded-full border-2" style={{ borderColor: c }} initial={{ scale: .6, opacity: .8 }} animate={{ scale: 1.9, opacity: 0 }} transition={{ duration: 1.1, delay: i * .25 }} />)}
    <motion.svg viewBox="0 0 52 52" className="w-20 h-20" initial={simple ? false : { scale: .6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 18 }}>
      <circle cx="26" cy="26" r="24" fill="none" stroke={c} strokeWidth="3" />
      <motion.path d={partial ? 'M26 14v16M26 37v1' : 'M14 27l8 8 16-17'} fill="none" stroke={c} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" initial={simple ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: .5, delay: .2 }} /></motion.svg></div>
}

export default function Upload() {
  const { datasets, selectedId, select, refresh } = useDatasets(); const nav = useNavigate(); const toast = useToast()
  const [phase, setPhase] = useState<Phase>('idle'); const [drag, setDrag] = useState(false); const [file, setFile] = useState<File | null>(null)
  const [prev, setPrev] = useState<any>(null); const [mapping, setMapping] = useState<Record<string, string | null>>({}); const [confirmed, setConfirmed] = useState(false)
  const [progress, setProgress] = useState<number | null>(null); const [stage, setStage] = useState(''); const [name, setName] = useState('')
  const [err, setErr] = useState<{ message: string; dup?: any } | null>(null); const [result, setResult] = useState<any>(null); const [analysis, setAnalysis] = useState<any>(null)
  const [log, setLog] = useState<{ t: string; m: string }[]>([]); const [del, setDel] = useState<number | null>(null)
  const abort = useRef<AbortController | null>(null); const input = useRef<HTMLInputElement>(null)
  const say = (m: string) => setLog(l => [...l, { t: new Date().toLocaleTimeString(), m }])
  const reset = () => { abort.current?.abort(); setPhase('idle'); setFile(null); setPrev(null); setErr(null); setResult(null); setAnalysis(null); setProgress(null); setStage(''); setConfirmed(false); setName('') }

  const fail = (e: any, what: string) => {
    if (e?.name === 'AbortError') { setPhase('cancelled'); say(`${what} cancelled by you`); return }
    const dup = e instanceof ApiError && e.data?.code === 'duplicate' ? e.data : undefined
    setErr({ message: e.message || 'Something went wrong', dup }); setPhase('failed'); say(`${what} failed: ${e.message}`)
  }
  const pick = (f?: File | null) => {
    if (!f) return; reset(); setLog([])
    const ext = f.name.split('.').pop()?.toLowerCase()
    if (!['csv', 'xlsx', 'xls'].includes(ext || '')) { setFile(f); setErr({ message: `'.${ext}' files are not supported. Upload a .csv, .xlsx or .xls file.` }); setPhase('failed'); return }
    if (f.size > MAX_MB * 1e6) { setFile(f); setErr({ message: `File is ${fmtSize(f.size)}; the limit is ${MAX_MB} MB.` }); setPhase('failed'); return }
    setFile(f); setName(f.name.replace(/\.[^.]+$/, '')); preview(f)
  }
  const preview = async (f: File) => {
    abort.current = new AbortController(); setErr(null); setPhase('validating'); setStage('uploading'); setProgress(0); say(`Uploading ${f.name} (${fmtSize(f.size)})`)
    const fd = new FormData(); fd.append('file', f)
    try {
      const p = await uploadForm('/datasets/preview', fd, { signal: abort.current.signal, onProgress: setProgress, onSent: () => { setStage('reading'); setProgress(null); say('Upload complete. The server is checking the file signature and reading its contents') } })
      setPrev(p); setMapping(Object.fromEntries(Object.entries<any>(p.mapping).map(([k, v]) => [k, v.column]))); setConfirmed(false)
      say(`Read ${p.rows.toLocaleString()} rows and ${p.columns.length} columns`); setPhase('mapping')
    } catch (e) { fail(e, 'Validation') }
  }
  const save = async (force = false) => {
    if (!file) return
    abort.current = new AbortController(); setErr(null); setPhase('saving'); setStage('uploading'); setProgress(0); say('Sending the file with your column mapping')
    const fd = new FormData(); fd.append('file', file); fd.append('mapping', JSON.stringify(mapping)); fd.append('name', name); fd.append('force', String(force))
    try {
      const r = await uploadForm('/datasets', fd, { signal: abort.current.signal, onProgress: setProgress, onSent: () => { setStage('analysing'); setProgress(null); say('Server is normalising rows, saving them and running the analysis') } })
      say(`Saved dataset #${r.dataset.id}: ${r.dataset.rows_valid} valid rows, ${r.dataset.rows_skipped} rejected`)
      try { setAnalysis(await api(`/datasets/${r.dataset.id}/analysis`)); say('Loaded the saved analysis from the server') } catch (e: any) { say(`Saved, but the analysis could not be loaded: ${e.message}`) }
      await refresh(); select(r.dataset.id); setResult(r); setPhase(r.dataset.status === 'partial' ? 'partial' : 'done')
      if (r.alerts_triggered) say(`${r.alerts_triggered} price alert(s) triggered`)
    } catch (e) { fail(e, 'Import') }
  }
  const remove = async () => { if (del == null) return; try { await api(`/datasets/${del}`, { method: 'DELETE' }); toast('Dataset deleted'); await refresh() } catch (e: any) { toast(e.message, true) } setDel(null) }

  const needs = prev && ['product', 'price'].some(f => prev.mapping[f].needs_confirmation && prev.mapping[f].column === mapping[f]) && !confirmed
  const canSave = !!mapping.product && !!mapping.price && mapping.product !== mapping.price && !needs
  const busy = phase === 'validating' || phase === 'saving'
  const q = result?.dataset?.quality

  return <div className="space-y-4 max-w-5xl"><h1 className="text-2xl font-bold"><GradientText>Upload &amp; datasets</GradientText></h1>
    <p className="text-sm text-slate-400 -mt-2">Your file is read and analysed by the backend, saved as a dataset, and every page then uses it. Supported: CSV, XLSX, XLS up to {MAX_MB} MB.</p>

    {(phase === 'idle' || phase === 'cancelled' || (phase === 'failed' && !prev)) && <GlassCard className="p-5">
      <div role="button" tabIndex={0} aria-label="Choose a file to upload" onClick={() => input.current?.click()} onKeyDown={e => (e.key === 'Enter' || e.key === ' ') && input.current?.click()}
        onDragOver={e => { e.preventDefault(); setDrag(true) }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files?.[0]) }}
        className={`rounded-2xl border-2 border-dashed cursor-pointer text-center px-6 py-6 transition-all ${drag ? 'border-cyan-300 bg-cyan-400/10 scale-[1.01]' : 'border-white/20 hover:border-cyan-400/60 hover:bg-white/5'}`}>
        <DropVisual active={drag} />
        <p className="font-semibold">{drag ? 'Drop to upload' : 'Drag a file here, or click to browse'}</p>
        <p className="text-xs text-slate-400 mt-1">CSV · XLSX · XLS — the contents are validated, not just the file name</p></div>
      <input ref={input} type="file" accept=".csv,.xlsx,.xls" aria-label="Data file" className="hidden" onChange={e => { pick(e.target.files?.[0]); e.target.value = '' }} />
      {phase === 'cancelled' && <div className="mt-4 flex items-center gap-3 text-amber-300 text-sm"><XCircle size={18} />Cancelled. Nothing was saved.{file && <GlassButton variant="ghost" className="!py-1.5 !px-3 ml-auto" onClick={() => pick(file)}>Retry</GlassButton>}</div>}
      {phase === 'failed' && err && <div role="alert" className="mt-4 text-rose-300 text-sm flex gap-2"><XCircle size={18} className="shrink-0" />{err.message}</div>}</GlassCard>}

    {busy && <GlassCard className="p-6" ><div className="flex items-center gap-3"><FileSpreadsheet className="text-cyan-300" /><div className="min-w-0 flex-1"><p className="font-semibold truncate">{file?.name}</p>
      <p className="text-xs text-slate-400">{stage === 'uploading' ? 'Uploading' : stage === 'reading' ? 'Validating and reading file contents on the server' : 'Normalising, analysing and saving on the server'}</p></div>
      <GlassButton variant="ghost" className="!py-2 !px-4" onClick={() => abort.current?.abort()}>Cancel</GlassButton></div>
      <div className="mt-4 h-2 rounded-full bg-white/10 overflow-hidden" role="progressbar" aria-label="Upload progress" aria-valuenow={progress == null ? undefined : Math.round(progress * 100)}>
        {progress == null ? <motion.div className="h-full w-1/3 rounded-full bg-gradient-to-r from-sky-400 to-violet-400" animate={{ x: ['-100%', '300%'] }} transition={{ duration: 1.2, repeat: Infinity, ease: 'linear' }} />
          : <div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-violet-400 transition-all" style={{ width: `${Math.round(progress * 100)}%` }} />}</div>
      <p className="text-xs text-slate-400 mt-2">{progress == null ? 'Server-side processing (duration unknown)' : `${Math.round(progress * 100)}% of the file sent`}</p></GlassCard>}

    {prev && (phase === 'mapping' || (phase === 'failed' && err)) && <>
      <GlassCard className="p-5"><div className="flex flex-wrap gap-x-6 gap-y-1 text-sm items-center"><b>{prev.filename}</b><span>{prev.rows.toLocaleString()} rows</span><span>{prev.columns.length} columns</span><span>{fmtSize(prev.file_size)}</span>
        <span className={prev.exact_duplicate_rows ? 'text-amber-300' : 'text-slate-400'}>{prev.exact_duplicate_rows} exact duplicate rows</span></div>
        {prev.duplicate_of && <p className="mt-3 text-sm text-amber-300 flex gap-2"><AlertTriangle size={16} className="shrink-0 mt-0.5" />This exact file was already imported as “{prev.duplicate_of.name}”. <button className="underline" onClick={() => { select(prev.duplicate_of.id); nav('/dashboard') }}>Open it</button> or continue to import it again.</p>}
        {phase === 'failed' && err && <div role="alert" className="mt-3 text-rose-300 text-sm flex gap-2"><XCircle size={18} className="shrink-0" /><span>{err.message}{err.dup && <> <button className="underline" onClick={() => { select(err.dup.dataset_id); nav('/dashboard') }}>Open the existing dataset</button> or <button className="underline" onClick={() => save(true)}>import it again anyway</button>.</>}</span></div>}</GlassCard>
      <GlassCard className="p-5"><h2 className="font-semibold mb-1">Check the column mapping</h2><p className="text-xs text-slate-400 mb-4">Detected from your headers. Fields marked amber were uncertain — nothing is guessed silently.</p>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">{FIELDS.map(([f, label, req]) => { const m = prev.mapping[f]; const unsure = m.needs_confirmation && m.column === mapping[f]
          return <label key={f} className="text-sm"><span className="flex justify-between text-slate-300">{label}{req && <span className="text-rose-300 text-xs">required</span>}</span>
            <select className={`input mt-1 py-2.5 ${unsure ? '!border-amber-400/70' : ''}`} value={mapping[f] ?? ''} onChange={e => { setMapping({ ...mapping, [f]: e.target.value || null }); setConfirmed(false) }}>
              <option value="" className="bg-slate-900">— none —</option>{prev.columns.map((c: any) => <option key={c.name} value={c.name} className="bg-slate-900">{c.name}</option>)}</select>
            <span className={`text-[11px] ${unsure ? 'text-amber-300' : 'text-slate-500'}`}>{m.column && m.column === mapping[f] ? `${Math.round(m.confidence * 100)}% match${unsure ? ' · please confirm' : ''}` : mapping[f] ? 'chosen by you' : req ? 'choose a column' : 'optional'}</span></label> })}</div>
        {needs && <label className="mt-4 flex items-center gap-2 text-sm text-amber-200"><input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} />I checked that the product and price columns are correct</label>}
        <div className="mt-4 flex flex-wrap gap-3 items-end"><label className="text-sm text-slate-300 flex-1 min-w-[12rem]">Dataset name<input className="input mt-1 py-2.5" value={name} maxLength={300} onChange={e => setName(e.target.value)} /></label>
          <GlassButton disabled={!canSave || phase !== 'mapping'} onClick={() => save(!!prev.duplicate_of)}>Analyse &amp; save</GlassButton><GlassButton variant="ghost" onClick={reset}>Choose another file</GlassButton></div></GlassCard>
      <GlassCard className="p-5"><h2 className="font-semibold mb-3">Preview (first {prev.preview.length} rows of your file)</h2><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-slate-400 text-left"><tr>{prev.columns.map((c: any) => <th key={c.name} className="pr-4 pb-2 whitespace-nowrap">{c.name}<div className="text-[10px] font-normal">{c.type}{c.missing ? ` · ${c.missing} blank` : ''}</div></th>)}</tr></thead>
        <tbody>{prev.preview.map((r: any, i: number) => <tr key={i} className="border-t border-white/5">{prev.columns.map((c: any) => <td key={c.name} className="pr-4 py-1.5 whitespace-nowrap max-w-[16rem] truncate">{r[c.name]}</td>)}</tr>)}</tbody></table></div></GlassCard></>}

    <AnimatePresence>{(phase === 'done' || phase === 'partial') && result && <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}><GlassCard className="p-6 text-center space-y-3">
      <SuccessMark partial={phase === 'partial'} /><h2 className="text-xl font-bold">{phase === 'partial' ? 'Processed with some rows rejected' : 'Analysis complete'}</h2>
      <p className="text-sm text-slate-300">“{result.dataset.name}” was saved as dataset #{result.dataset.id}. {result.dataset.rows_valid.toLocaleString()} of {result.dataset.rows_total.toLocaleString()} rows were usable{analysis?.summary ? ` — ${analysis.summary.unique_products} product(s), ${analysis.summary.sources} source(s)` : ''}.</p>
      {q && <p className="text-xs text-slate-400">{q.rows_skipped} rejected · {q.duplicates_removed} duplicates removed · {q.unavailable_price} without a price · {q.dates_inferred} without a usable date</p>}
      {q?.issues?.length > 0 && <ul className="text-xs text-amber-200 text-left max-w-xl mx-auto list-disc pl-5">{q.issues.slice(0, 5).map((i: any, k: number) => <li key={k}>Row {i.row}: {i.reason}</li>)}</ul>}
      <div className="flex gap-3 justify-center pt-2"><GlassButton onClick={() => nav('/dashboard')}>Open analysis dashboard</GlassButton><GlassButton variant="ghost" onClick={() => { reset(); setLog([]) }}>Upload another file</GlassButton></div></GlassCard></motion.div>}</AnimatePresence>

    {log.length > 0 && <GlassCard className="p-5"><h2 className="font-semibold mb-2 text-sm">Processing log</h2><ul className="text-xs text-slate-300 space-y-1 font-mono">{log.map((l, i) => <li key={i}><span className="text-slate-500">{l.t}</span> {l.m}</li>)}</ul></GlassCard>}

    <GlassCard className="p-5"><h2 className="font-semibold mb-3">Upload history</h2>{datasets == null ? <Skeleton /> : datasets.length === 0 ? <p className="text-sm text-slate-400">No datasets yet. Upload a file above, or load demo data from the Collection page.</p> :
      <div className="divide-y divide-white/5">{datasets.map(d => <div key={d.id} className="flex flex-wrap items-center gap-3 py-3 text-sm">
        <div className="min-w-0 flex-1"><p className="font-medium truncate">{d.name}</p><p className="text-xs text-slate-400">{new Date(d.created_at).toLocaleString()} · {d.rows_valid.toLocaleString()} / {d.rows_total.toLocaleString()} rows{d.file_type ? ` · ${d.file_type}` : ''}</p></div>
        <StatusBadge s={d.status} demo={d.is_demo} />{d.id === selectedId && <span className="text-xs text-cyan-300">selected</span>}
        <GlassButton variant="ghost" className="!py-1.5 !px-3" onClick={() => { select(d.id); nav('/dashboard') }}>Open</GlassButton>
        <button aria-label={`Delete ${d.name}`} className="text-rose-300 p-2" onClick={() => setDel(d.id)}><Trash2 size={16} /></button></div>)}</div>}</GlassCard>
    {del != null && <ConfirmDialog text="Delete this dataset and its stored records?" onNo={() => setDel(null)} onYes={remove} />}
    <p className="text-xs text-slate-500">Live URL collection is on the <Link className="underline" to="/scrape">Collection page</Link>.</p></div>
}
