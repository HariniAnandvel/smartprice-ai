import { useEffect, useState } from 'react'
import { api } from '../services/api'
import { GlassCard, GlassButton, GradientText, EmptyState } from '../components/ui'
import { useProducts, useToast, ConfirmDialog } from '../components/extra'

export default function Competitors() {
  const { id, Select, dq } = useProducts(); const [list, setList] = useState<any[]>([]); const [cmp, setCmp] = useState<any[]>([]); const [n, setN] = useState(''); const [dom, setDom] = useState(''); const [del, setDel] = useState<number | null>(null); const toast = useToast()
  const load = () => api('/competitors').then(setList); useEffect(() => { load() }, [])
  useEffect(() => { if (id) api(`/competitors/${id}${dq}`).then(setCmp).catch(() => setCmp([])) }, [id, dq])
  const add = async (e: React.FormEvent) => { e.preventDefault(); try { await api('/competitors', { method: 'POST', body: JSON.stringify({ name: n, domain: dom }) }); setN(''); setDom(''); load(); toast('Competitor added') } catch (x: any) { toast(x.message, true) } }
  return <div className="space-y-4"><h1 className="text-2xl font-bold"><GradientText>Competitor intelligence</GradientText></h1>
    <GlassCard className="p-5"><h2 className="font-semibold mb-3">Price comparison</h2><div className="mb-3 max-w-sm">{Select}</div>
      {cmp.length ? <div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-slate-400 text-left"><tr><th>Source</th><th>Price</th><th>Gap vs lowest</th><th>Observed</th></tr></thead>
        <tbody>{cmp.map(c => <tr key={c.source} className="border-t border-white/5"><td className="py-2">{c.source}</td><td>{c.available ? `${c.price} ${c.currency}` : 'Unavailable'}</td><td>{c.gap_pct == null ? '—' : `${c.gap_pct}%`}</td><td className="text-slate-400">{new Date(c.observed_at).toLocaleDateString()}</td></tr>)}</tbody></table></div>
        : <p className="text-sm text-slate-400">No source data for this product yet.</p>}</GlassCard>
    <GlassCard className="p-5"><h2 className="font-semibold mb-3">Monitored competitors</h2>
      <form onSubmit={add} className="flex gap-2 flex-wrap mb-4"><input className="input max-w-[12rem]" required placeholder="Name" value={n} onChange={e => setN(e.target.value)} aria-label="Name" />
        <input className="input max-w-xs" required placeholder="example.com" value={dom} onChange={e => setDom(e.target.value)} aria-label="Domain" /><GlassButton type="submit">Add</GlassButton></form>
      {list.length ? list.map(c => <div key={c.id} className="flex justify-between py-2 border-t border-white/5 text-sm"><span>{c.name} <span className="text-slate-500">{c.domain}</span></span><button className="text-rose-300" onClick={() => setDel(c.id)}>Remove</button></div>) : <EmptyState title="None yet" text="Add competitor domains to monitor." />}</GlassCard>
    {del && <ConfirmDialog text="Remove this competitor?" onNo={() => setDel(null)} onYes={async () => { await api(`/competitors/${del}`, { method: 'DELETE' }); setDel(null); load() }} />}</div>
}
