import { useEffect, useState } from 'react'
import { api } from '../services/api'
import { GlassCard, GlassButton, GradientText, EmptyState, Skeleton } from '../components/ui'
import { useProducts, useToast } from '../components/extra'

export default function Insights() {
  const { items, id, Select, dq } = useProducts(); const [ins, setIns] = useState<any>(null); const [q, setQ] = useState(''); const [ans, setAns] = useState<any>(null); const [busy, setBusy] = useState(false); const toast = useToast()
  useEffect(() => { if (id) { setIns(null); setAns(null); api(`/insights/${id}${dq}`).then(setIns).catch(e => toast(e.message, true)) } }, [id, dq])
  const ask = async (e: React.FormEvent) => { e.preventDefault(); setBusy(true); try { setAns(await api(`/insights/${id}/ask${dq}`, { method: 'POST', body: JSON.stringify({ question: q }) })) } catch (x: any) { toast(x.message, true) } finally { setBusy(false) } }
  if (items && !items.length) return <EmptyState title="Nothing to analyze" text="Add price data first." />
  const badge = (m: string) => <span className="text-xs rounded-full bg-white/10 px-3 py-1">Analysis mode: {m === 'llm' ? 'AI model' : 'deterministic'}</span>
  return <div className="space-y-4 max-w-3xl"><h1 className="text-2xl font-bold"><GradientText>AI insights</GradientText></h1><div className="max-w-sm">{Select}</div>
    <GlassCard className="p-5">{!ins ? <Skeleton /> : <><div className="mb-2">{badge(ins.mode)}</div><p>{ins.text}</p>
      <p className="text-xs text-slate-400 mt-3">Why: computed from persisted price observations (first vs latest price, observed low/high). No confidence score is shown because no forecasting model is used.</p></>}</GlassCard>
    <GlassCard className="p-5"><form onSubmit={ask} className="flex gap-2"><input className="input" required maxLength={500} placeholder="Ask about this product's prices…" value={q} onChange={e => setQ(e.target.value)} aria-label="Question" />
      <GlassButton type="submit" disabled={busy}>{busy ? '…' : 'Ask'}</GlassButton></form>
      {ans && <div className="mt-4"><div className="mb-2">{badge(ans.mode)}</div><p>{ans.text}</p>{ans.note && <p className="text-xs text-amber-300 mt-2">{ans.note}</p>}</div>}</GlassCard></div>
}
