import { useEffect, useState } from 'react'
import { api } from '../services/api'
import { usePrefs } from '../components/prefs'
import { GlassCard, GlassButton, GradientText } from '../components/ui'
import { useToast, ConfirmDialog } from '../components/extra'

export default function Settings() {
  const [s, setS] = useState<any>(null); const [pw, setPw] = useState({ current_password: '', new_password: '' }); const [wipe, setWipe] = useState(false); const toast = useToast(); const { setPrefs } = usePrefs()
  useEffect(() => { api('/settings').then(setS) }, [])
  if (!s) return null
  const run = async (f: () => Promise<any>, ok: string) => { try { await f(); toast(ok) } catch (x: any) { toast(x.message, true) } }
  const pref = (k: string, label: string) => <label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={!!s.prefs[k]} onChange={e => { const p = { ...s.prefs, [k]: e.target.checked }; setS({ ...s, prefs: p }); setPrefs(p) }} />{label}</label>
  return <div className="space-y-4 max-w-2xl"><h1 className="text-2xl font-bold"><GradientText>Settings</GradientText></h1>
    <GlassCard className="p-5 space-y-3"><h2 className="font-semibold">Profile & preferences</h2><label className="text-sm text-slate-300">Name<input className="input mt-1" value={s.name} onChange={e => setS({ ...s, name: e.target.value })} /></label>
      <p className="text-sm text-slate-400">{s.email}</p><label className="text-sm text-slate-300 block">Appearance<select className="input mt-1" value={s.prefs.theme || 'dark'} onChange={e => { const p = { ...s.prefs, theme: e.target.value }; setS({ ...s, prefs: p }); setPrefs(p) }}><option value="dark" className="bg-slate-900">Dark glass</option><option value="light" className="bg-slate-900">Light glass</option></select></label>{pref('reduced_motion', 'Simplified animations')}{pref('notify_in_app', 'In-app alert notifications')}
      <GlassButton onClick={() => run(() => api('/settings', { method: 'PATCH', body: JSON.stringify({ name: s.name, prefs: s.prefs }) }), 'Settings saved')}>Save</GlassButton></GlassCard>
    <GlassCard className="p-5 space-y-3"><h2 className="font-semibold">Change password</h2>
      <input className="input" type="password" placeholder="Current password" aria-label="Current password" value={pw.current_password} onChange={e => setPw({ ...pw, current_password: e.target.value })} />
      <input className="input" type="password" placeholder="New password (8+ chars)" aria-label="New password" value={pw.new_password} onChange={e => setPw({ ...pw, new_password: e.target.value })} />
      <GlassButton onClick={() => run(async () => { await api('/settings/password', { method: 'POST', body: JSON.stringify(pw) }); setPw({ current_password: '', new_password: '' }) }, 'Password updated')}>Update password</GlassButton></GlassCard>
    <GlassCard className="p-5"><h2 className="font-semibold mb-2">Data management</h2><p className="text-sm text-slate-400 mb-3">Deletes all your products, observations, alerts, notifications and reports.</p><GlassButton variant="ghost" onClick={() => setWipe(true)}>Delete my data</GlassButton></GlassCard>
    {wipe && <ConfirmDialog text="Permanently delete all your tracked data?" onNo={() => setWipe(false)} onYes={() => { setWipe(false); run(() => api('/settings/data', { method: 'DELETE' }), 'Data deleted') }} />}</div>
}
