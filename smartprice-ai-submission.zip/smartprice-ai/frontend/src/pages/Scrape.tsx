import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { useDatasets } from '../components/datasets'
import { api } from '../services/api'
import { GlassCard, GlassButton, GradientText } from '../components/ui'
import { useToast } from '../components/extra'

export default function Scrape() {
  const [url, setUrl] = useState(''); const [busy, setBusy] = useState(false); const [res, setRes] = useState<any>(null); const [err, setErr] = useState(''); const [hist, setHist] = useState<any[]>([]); const toast = useToast()
  const loadH = () => api('/collect/history').then(setHist).catch(() => {}); useEffect(() => { loadH() }, [])
  const run = async (e: React.FormEvent) => { e.preventDefault(); setBusy(true); setErr(''); setRes(null)
    try { setRes(await api('/collect', { method: 'POST', body: JSON.stringify({ url }) })); loadH() } catch (x: any) { setErr(x.message) } finally { setBusy(false) } }
  const { refresh, select } = useDatasets()
  const seed = async () => { try { const r = await api('/demo/seed', { method: 'POST' }); await refresh(); select(r.dataset_id); toast(r.seeded ? 'Demo data loaded (labelled DEMO DATA)' : 'Demo data was already loaded') } catch (x: any) { toast(x.message, true) } }
  const color: any = { success: 'text-emerald-300', partial: 'text-amber-300', blocked: 'text-rose-300', failed: 'text-rose-300' }
  return <div className="space-y-4 max-w-3xl"><h1 className="text-2xl font-bold"><GradientText>Data collection</GradientText></h1>
    <GlassCard className="p-5"><form onSubmit={run} className="space-y-3"><label className="text-sm text-slate-300">Public product page URL
      <input className="input mt-1" type="url" required value={url} onChange={e => setUrl(e.target.value)} placeholder="https://…" /></label>
      <p className="text-xs text-slate-400">Source: structured product data (JSON-LD). robots.txt is respected; private/internal addresses are blocked; CAPTCHAs and logins are never bypassed.</p>
      <GlassButton type="submit" disabled={busy}>{busy ? 'Collecting…' : 'Collect'}</GlassButton></form>
      {err && <p role="alert" className="text-rose-400 mt-3">{err}</p>}
      {res && <div className="mt-4 text-sm"><b className={color[res.status]}>{res.status.toUpperCase()}</b> {res.message}
        {res.name && <p>{res.name}: {res.price ?? 'price unavailable'} {res.currency}</p>}{res.alerts_triggered > 0 && <p className="text-cyan-300">{res.alerts_triggered} alert(s) triggered</p>}</div>}</GlassCard>
    <GlassCard className="p-5"><h2 className="font-semibold mb-2">Files &amp; demo data</h2><p className="text-sm text-slate-300 mb-3">Import CSV, XLSX or XLS files with column mapping, preview and real analysis on the upload page.</p>
      <Link to="/upload"><GlassButton>Go to upload</GlassButton></Link><GlassButton variant="ghost" className="ml-3" onClick={seed}>Load demo data</GlassButton></GlassCard>
    <GlassCard className="p-5"><h2 className="font-semibold mb-2">Collection history</h2>{hist.length ? hist.map((h, i) => <p key={i} className="text-sm py-1 border-b border-white/5 truncate">
      <b className={color[h.status]}>{h.status}</b> {h.url} <span className="text-slate-500">{new Date(h.at).toLocaleString()}</span></p>) : <p className="text-sm text-slate-400">No collections yet.</p>}</GlassCard></div>
}
