import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { animate, motion } from 'framer-motion'
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Boxes, Gauge, IndianRupee, Rows3 } from 'lucide-react'
import { api } from '../services/api'
import { GlassCard, GlassButton, Skeleton, EmptyState, ErrorState, GradientText } from '../components/ui'
import { useSimple } from '../components/prefs'
import { useDatasets, StatusBadge, DatasetSelect } from '../components/datasets'

const COLORS = ['#22d3ee', '#a78bfa', '#f472b6', '#34d399']
const tip = { contentStyle: { background: '#0b1230', border: '1px solid #334', borderRadius: 12 } }

function Num({ v, dec = 0 }: { v: number | null | undefined; dec?: number }) {
  const simple = useSimple(); const [n, setN] = useState(v ?? 0)
  useEffect(() => { if (v == null) return; if (simple) { setN(v); return } const c = animate(n, v, { duration: .7, ease: 'easeOut', onUpdate: setN }); return () => c.stop() /* eslint-disable-next-line */ }, [v, simple])
  return <>{v == null ? 'n/a' : n.toLocaleString(undefined, { maximumFractionDigits: dec, minimumFractionDigits: dec })}</>
}
const Stat = ({ label, children, hint, icon }: { label: string; children: React.ReactNode; hint?: string; icon: React.ReactNode }) =>
  <GlassCard className="p-5 h-full"><div className="flex justify-between text-slate-400 text-sm">{label}{icon}</div><div className="text-3xl font-bold mt-2 tabular-nums">{children}</div>{hint && <div className="text-xs text-slate-400 mt-1">{hint}</div>}</GlassCard>

export default function Dashboard() {
  const { datasets, selected, selectedId, version, refresh, select, error: dsErr } = useDatasets()
  const [a, setA] = useState<any>(null); const [trend, setTrend] = useState<any[]>([]); const [srcs, setSrcs] = useState<string[]>([]); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const load = useCallback(async () => {
    if (selectedId == null) return
    setErr(''); setA(null); setTrend([])
    try {
      const r = await api(`/datasets/${selectedId}/analysis`); setA(r)
      const main = r.products?.find((p: any) => p.change_pct != null)
      if (main) {
        const t = await api(`/analytics/${main.id}?dataset_id=${selectedId}`); const by: any = {}
        t.series.filter((x: any) => x.price != null).forEach((x: any) => { const k = x.t.slice(0, 10); by[k] = { ...(by[k] || { d: k }), [x.source]: x.price } })
        setTrend(Object.values(by)); setSrcs([...new Set<string>(t.series.map((x: any) => x.source))])
      }
    } catch (e: any) { setErr(e.message); if (/not found/i.test(e.message)) refresh() }
  }, [selectedId, refresh])
  useEffect(() => { load() }, [load, version])
  const seed = async () => { setBusy(true); try { const r = await api('/demo/seed', { method: 'POST' }); await refresh(); select(r.dataset_id) } finally { setBusy(false) } }

  if (dsErr && !datasets?.length) return <ErrorState message={dsErr} retry={refresh} />
  if (datasets == null) return <div className="grid gap-4"><div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">{[0, 1, 2, 3].map(i => <Skeleton key={i} />)}</div><Skeleton className="h-80" /></div>
  if (!datasets.length) return <EmptyState title="No data yet" text="Upload a CSV or Excel file to see real analysis here, or load clearly-labelled demo data."
    action={<div className="flex gap-3 justify-center"><Link to="/upload"><GlassButton>Upload a file</GlassButton></Link><GlassButton variant="ghost" onClick={seed} disabled={busy}>{busy ? 'Loading…' : 'Load demo data'}</GlassButton></div>} />
  if (err) return <ErrorState message={err} retry={load} />
  if (!a) return <div className="grid gap-4"><div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">{[0, 1, 2, 3].map(i => <Skeleton key={i} />)}</div><Skeleton className="h-80" /></div>

  const s = a.summary, ps = a.price_stats, cur = s?.primary_currency && s.primary_currency !== 'UNK' ? s.primary_currency : ''
  const stagger = { hidden: {}, show: { transition: { staggerChildren: .07 } } }; const item = { hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0 } }
  return <motion.div key={selectedId} variants={stagger} initial="hidden" animate="show" className="space-y-4">
    <motion.div variants={item} className="flex flex-wrap items-center gap-3"><h1 className="text-2xl font-bold"><GradientText>Dashboard</GradientText></h1>
      <span className="text-slate-300 truncate max-w-xs">{a.dataset.name}</span><StatusBadge s={a.dataset.status} demo={a.is_demo} />
      <div className="sm:hidden w-full"><DatasetSelect /></div></motion.div>
    {!a.enough_data ? <EmptyState title="No usable prices in this dataset" text={a.insights?.[0] || 'Nothing to analyse.'} action={<Link to="/upload"><GlassButton>Upload another file</GlassButton></Link>} /> : <>
      <motion.div variants={item} className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Stat label="Valid price records" icon={<Rows3 size={18} />} hint={`${a.dataset.rows_total.toLocaleString()} rows in file · ${a.dataset.rows_skipped} rejected`}><Num v={s.valid_prices} /></Stat>
        <Stat label="Unique products" icon={<Boxes size={18} />} hint={`${s.sources} source(s)`}><Num v={s.unique_products} /></Stat>
        <Stat label="Median price" icon={<IndianRupee size={18} />} hint={ps ? `mean ${ps.mean.toLocaleString()} ${cur}` : undefined}><Num v={ps?.median} dec={2} /> <span className="text-sm text-slate-400">{cur}</span></Stat>
        <Stat label="Price range" icon={<Gauge size={18} />} hint="lowest – highest"><span className="text-2xl">{ps ? `${ps.min.toLocaleString()} – ${ps.max.toLocaleString()}` : 'n/a'}</span></Stat></motion.div>
      <motion.div variants={item} className="grid lg:grid-cols-5 gap-4">
        <GlassCard className="p-5 lg:col-span-3"><h2 className="font-semibold mb-1">Price distribution</h2><p className="text-xs text-slate-400 mb-3">Number of price records per price band, from your uploaded data.</p>
          <div className="h-64"><ResponsiveContainer><BarChart data={a.distribution}><CartesianGrid stroke="rgba(255,255,255,.08)" /><XAxis dataKey="range" stroke="#94a3b8" tick={{ fontSize: 11 }} interval="preserveStartEnd" /><YAxis stroke="#94a3b8" allowDecimals={false} /><Tooltip {...tip} /><Bar dataKey="count" fill="#22d3ee" radius={[6, 6, 0, 0]} animationDuration={700} /></BarChart></ResponsiveContainer></div></GlassCard>
        <GlassCard className="p-5 lg:col-span-2"><h2 className="font-semibold mb-3">Insights</h2><ul className="space-y-2 text-sm">{a.insights.map((t: string, i: number) => <li key={i} className="flex gap-2"><span className="text-cyan-300">▸</span>{t}</li>)}</ul>
          <p className="text-xs text-slate-500 mt-3">Deterministic: each statement is computed from the stored records.</p></GlassCard></motion.div>
      <motion.div variants={item}><GlassCard className="p-5"><h2 className="font-semibold mb-1">Price history</h2>
        {trend.length ? <><p className="text-xs text-slate-400 mb-3">{a.products.find((p: any) => p.change_pct != null)?.name} — dated observations from your file.</p>
          <div className="h-72"><ResponsiveContainer><LineChart data={trend}><CartesianGrid stroke="rgba(255,255,255,.08)" /><XAxis dataKey="d" stroke="#94a3b8" tick={{ fontSize: 11 }} /><YAxis stroke="#94a3b8" domain={['auto', 'auto']} /><Tooltip {...tip} /><Legend />{srcs.map((x, i) => <Line key={x} dataKey={x} stroke={COLORS[i % 4]} dot={false} connectNulls strokeWidth={2} animationDuration={800} />)}</LineChart></ResponsiveContainer></div></>
          : <p className="text-sm text-amber-300">{a.trends.note}</p>}</GlassCard></motion.div>
      <motion.div variants={item}><GlassCard className="p-5"><h2 className="font-semibold mb-3">Products &amp; competitor gaps</h2><div className="overflow-x-auto"><table className="w-full text-sm"><thead className="text-slate-400 text-left"><tr><th className="pb-2">Product</th><th>Records</th><th>Sources</th><th>Lowest</th><th>Latest</th><th>Cross-source gap</th><th>Change</th></tr></thead>
        <tbody>{a.products.slice(0, 12).map((p: any) => <tr key={p.id} className="border-t border-white/5"><td className="py-2 pr-3 max-w-[18rem] truncate">{p.name}</td><td>{p.observations}</td><td>{p.sources}</td><td>{p.min.toLocaleString()}</td><td>{p.latest.toLocaleString()}</td>
          <td>{p.spread_pct == null ? <span className="text-slate-500">needs ≥2 sources</span> : `${p.spread_pct}% (cheapest: ${p.cheapest_source})`}</td><td>{p.change_pct == null ? <span className="text-slate-500">no dated history</span> : `${p.change_pct}%`}</td></tr>)}</tbody></table></div></GlassCard></motion.div>
      <motion.div variants={item} className="grid lg:grid-cols-2 gap-4">
        <GlassCard className="p-5"><h2 className="font-semibold mb-2">Data quality</h2>{a.quality.warnings.length ? <ul className="text-sm space-y-1 text-amber-200 list-disc pl-5">{a.quality.warnings.map((w: string, i: number) => <li key={i}>{w}</li>)}</ul> : <p className="text-sm text-emerald-300">No data-quality problems detected.</p>}
          {a.quality.issues?.length > 0 && <details className="mt-3 text-xs text-slate-300"><summary className="cursor-pointer">Rejected rows ({a.quality.issue_count})</summary><ul className="mt-2 space-y-0.5">{a.quality.issues.slice(0, 15).map((i: any, k: number) => <li key={k}>Row {i.row} · {i.field}: {i.reason}</li>)}</ul></details>}</GlassCard>
        <GlassCard className="p-5"><h2 className="font-semibold mb-1">Unusual prices</h2><p className="text-xs text-slate-400 mb-2">{a.outliers.method}</p>
          {a.outliers.items.length ? <ul className="text-sm space-y-1">{a.outliers.items.slice(0, 6).map((o: any, i: number) => <li key={i}>{o.product} @ {o.source}: <b>{o.price.toLocaleString()}</b> <span className="text-slate-400">(expected {o.expected_range[0]}–{o.expected_range[1]}) · {o.observed_at.slice(0, 10)}</span></li>)}</ul>
            : <p className="text-sm text-slate-400">None flagged (needs a series of at least 5 prices per product and source).</p>}</GlassCard></motion.div></>}
  </motion.div>
}
