import { useEffect, useMemo, useState } from 'react'
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { api } from '../services/api'
import { GlassCard, GradientText, Skeleton, EmptyState, ErrorState, MetricCard } from '../components/ui'
import { useProducts } from '../components/extra'

const COLORS = ['#22d3ee', '#a78bfa', '#f472b6', '#34d399']
export default function Analytics() {
  const { items, id, err, Select, dq } = useProducts(); const [d, setD] = useState<any>(null); const [e2, setE2] = useState(''); const [days, setDays] = useState(0)
  useEffect(() => { if (id) { setD(null); api(`/analytics/${id}${dq}`).then(setD).catch(e => setE2(e.message)) } }, [id, dq])
  const { rows, sources, stat } = useMemo(() => {
    if (!d) return { rows: [], sources: [] as string[], stat: null as any }
    const cut = days ? Date.now() - days * 864e5 : 0; const s = d.series.filter((x: any) => x.price != null && new Date(x.t).getTime() >= cut)
    const by: any = {}; s.forEach((x: any) => { const k = x.t.slice(0, 10); by[k] = { ...(by[k] || { d: k }), [x.source]: x.price } })
    const p = s.map((x: any) => x.price); const f = p[0], l = p[p.length - 1]
    return { rows: Object.values(by) as any[], sources: [...new Set<string>(s.map((x: any) => x.source))], stat: p.length > 1 ? { min: Math.min(...p), max: Math.max(...p), abs: +(l - f).toFixed(2), pct: +((l - f) / f * 100).toFixed(2) } : null }
  }, [d, days])
  if (err || e2) return <ErrorState message={err || e2} />
  if (items && !items.length) return <EmptyState title="No price history" text="Collect or import data first (Data collection page)." />
  return <div className="space-y-4"><h1 className="text-2xl font-bold"><GradientText>Price trends</GradientText></h1>
    <div className="flex gap-3 flex-wrap items-end">{Select}<label className="text-sm text-slate-300">Range<select className="input mt-1" value={days} onChange={e => setDays(+e.target.value)}>
      {[[0, 'All time'], [7, 'Last 7 days'], [30, 'Last 30 days']].map(([v, l]) => <option key={v} value={v} className="bg-slate-900">{l}</option>)}</select></label></div>
    {!d ? <Skeleton className="h-96" /> : <>
      {stat ? <div className="grid sm:grid-cols-4 gap-4"><MetricCard label="Lowest" value={String(stat.min)} /><MetricCard label="Highest" value={String(stat.max)} /><MetricCard label="Change" value={String(stat.abs)} /><MetricCard label="Change %" value={`${stat.pct}%`} /></div>
        : <GlassCard className="p-4 text-amber-300 text-sm">Not enough observations in this range to compute a trend. Nothing is estimated.</GlassCard>}
      <GlassCard className="p-5"><div className="h-80"><ResponsiveContainer><LineChart data={rows}><CartesianGrid stroke="rgba(255,255,255,.08)" /><XAxis dataKey="d" stroke="#94a3b8" /><YAxis stroke="#94a3b8" domain={['auto', 'auto']} />
        <Tooltip contentStyle={{ background: '#0b1230', borderRadius: 12 }} /><Legend />{sources.map((s, i) => <Line key={s} dataKey={s} stroke={COLORS[i % 4]} dot={false} connectNulls />)}</LineChart></ResponsiveContainer></div>
        {stat && <p className="text-sm text-slate-300 mt-3">Price moved {stat.abs < 0 ? 'down' : stat.abs > 0 ? 'up' : 'sideways'} {Math.abs(stat.pct)}% in this range, based on persisted observations only. {d.is_demo && 'Demonstration data.'}</p>}</GlassCard></>}</div>
}
