import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { vi, beforeEach, test, expect } from 'vitest'
import Auth from '../pages/Auth'
import { PrefsProvider } from '../components/prefs'
import { api } from '../services/api'

beforeEach(() => { localStorage.clear(); vi.restoreAllMocks() })

test('api explains when the backend is unreachable instead of failing silently', async () => {
  vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')))
  await expect(api('/datasets')).rejects.toMatchObject({ status: 0, message: expect.stringContaining('Cannot reach the server') })
})

test('api keeps structured error details (duplicate upload)', async () => {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false, status: 409, json: async () => ({ detail: { code: 'duplicate', message: 'Already imported', dataset_id: 7 } }) }))
  await expect(api('/datasets', { method: 'POST', body: '{}' })).rejects.toMatchObject({ status: 409, message: 'Already imported', data: { dataset_id: 7 } })
})

test('api surfaces backend error detail', async () => {
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false, status: 409, json: async () => ({ detail: 'Email already registered' }) }))
  await expect(api('/auth/register', { method: 'POST', body: '{}' })).rejects.toThrow('Email already registered')
})

test('register form validates before calling the backend', async () => {
  const f = vi.fn(); vi.stubGlobal('fetch', f)
  render(<MemoryRouter><PrefsProvider><Auth mode="register" /></PrefsProvider></MemoryRouter>)
  await userEvent.type(screen.getByLabelText('Email'), 'nope')
  await userEvent.type(screen.getByLabelText('Password'), 'short')
  await userEvent.click(screen.getByRole('button', { name: /sign up/i }))
  expect(await screen.findByText('Enter a valid email')).toBeInTheDocument()
  expect(f).not.toHaveBeenCalled()
})

test('light theme and simplified motion are applied to the document', async () => {
  localStorage.setItem('sp_prefs', JSON.stringify({ theme: 'light', reduced_motion: true }))
  render(<PrefsProvider><div /></PrefsProvider>)
  await waitFor(() => { expect(document.documentElement.dataset.theme).toBe('light'); expect(document.documentElement.dataset.motion).toBe('simple') })
})
