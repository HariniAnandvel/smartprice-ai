import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { vi, beforeEach, test, expect } from 'vitest'

const h = vi.hoisted(() => ({ api: vi.fn(), uploadForm: vi.fn() }))
vi.mock('../services/api', async orig => ({ ...(await orig<any>()), api: h.api, uploadForm: h.uploadForm, getToken: () => 'tok', setToken: () => {} }))

import { ApiError } from '../services/api'
import Upload from '../pages/Upload'
import Dashboard from '../pages/Dashboard'
import AppLayout from '../layouts/AppLayout'
import { DatasetProvider } from '../components/datasets'
import { PrefsProvider } from '../components/prefs'
import { ToastProvider } from '../components/extra'

const ds = (id: number, name: string, extra: any = {}) => ({ id, name, status: 'completed', is_demo: false, rows_total: 10, rows_valid: 10, rows_skipped: 0, created_at: '2026-10-01T00:00:00Z', ...extra })
const mapping = (needs = false) => Object.fromEntries(['product', 'price', 'source', 'currency', 'date', 'category', 'brand', 'rating'].map(f =>
  [f, { column: { product: 'item', price: 'amount', source: 'store' }[f] ?? null, confidence: needs ? .75 : 1, needs_confirmation: needs && (f === 'product' || f === 'price'), candidates: [] }]))
const preview = (needs = false, dup: any = null) => ({ filename: 'prices.csv', file_type: 'csv', file_size: 2048, rows: 3, exact_duplicate_rows: 0, duplicate_of: dup,
  columns: ['item', 'amount', 'store'].map(n => ({ name: n, type: 'text', non_empty: 3, missing: 0, samples: [] })), mapping: mapping(needs),
  preview: [{ item: 'Kettle', amount: '999', store: 'ShopA' }, { item: 'Toaster', amount: '1,499', store: 'ShopB' }] })
const analysis = (id: number, name: string, products: number) => ({ dataset: ds(id, name), is_demo: false, enough_data: true, insights: [`${products} product(s) across 2 source(s).`],
  summary: { records: 10, valid_prices: 10, unique_products: products, sources: 2, primary_currency: 'INR', has_history: false, unavailable: 0 },
  price_stats: { mean: 1200, median: 1100, min: 900, max: 1500, std: 5, currency: 'INR' }, distribution: [{ range: '900–1,500', count: 10 }], categories: [],
  quality: { warnings: [], issues: [] }, outliers: { method: 'IQR', items: [] }, trends: { available: false, note: 'No price history: add dates.' },
  products: [{ id: id, name: `Product of ${name}`, observations: 10, sources: 2, min: 900, max: 1500, mean: 1200, latest: 1000, spread_pct: 5, change_pct: null, cheapest_source: 'ShopA' }] })

const wrap = (ui: React.ReactNode, path = '/') => render(<MemoryRouter initialEntries={[path]}><PrefsProvider><ToastProvider><DatasetProvider>{ui}</DatasetProvider></ToastProvider></PrefsProvider></MemoryRouter>)
const file = (name = 'prices.csv', type = 'text/csv') => new File(['item,amount,store\nKettle,999,ShopA'], name, { type })

beforeEach(() => { localStorage.clear(); h.api.mockReset(); h.uploadForm.mockReset() })

test('upload: file is sent to the backend, mapping is reviewed, success appears only after the backend confirms', async () => {
  let finish: (v: any) => void = () => {}
  h.api.mockImplementation(async (p: string) => p === '/datasets' ? [] : p.endsWith('/analysis') ? analysis(5, 'prices', 2) : [])
  h.uploadForm.mockImplementation((path: string) => path === '/datasets/preview' ? Promise.resolve(preview()) : new Promise(r => { finish = r }))
  wrap(<Upload />)
  await userEvent.upload(screen.getByLabelText('Data file'), file())
  expect(await screen.findByText('Check the column mapping')).toBeInTheDocument()
  expect(screen.getByText('Kettle')).toBeInTheDocument()                                  // real parsed preview rows
  const [path, fd] = h.uploadForm.mock.calls[0]; expect(path).toBe('/datasets/preview'); expect((fd as FormData).get('file')).toBeInstanceOf(File)
  await userEvent.click(screen.getByRole('button', { name: /analyse & save/i }))
  const [p2, fd2] = h.uploadForm.mock.calls[1]; expect(p2).toBe('/datasets')
  expect(JSON.parse((fd2 as FormData).get('mapping') as string)).toMatchObject({ product: 'item', price: 'amount', source: 'store' })
  expect(screen.queryByText('Analysis complete')).not.toBeInTheDocument()               // not yet: backend has not answered
  finish({ dataset: ds(5, 'prices'), alerts_triggered: 0 })
  expect(await screen.findByText('Analysis complete')).toBeInTheDocument()
  expect(h.api).toHaveBeenCalledWith('/datasets/5/analysis')                              // saved analysis fetched by the returned id
})

test('upload: unsupported file type is rejected before any request', async () => {
  h.api.mockResolvedValue([]); wrap(<Upload />)
  await userEvent.upload(screen.getByLabelText('Data file'), file('notes.txt', 'text/plain'), { applyAccept: false })
  expect(await screen.findByRole('alert')).toHaveTextContent(/not supported/i); expect(h.uploadForm).not.toHaveBeenCalled()
})

test('upload: backend unreachable shows the connection problem and never a success state', async () => {
  h.api.mockResolvedValue([]); h.uploadForm.mockRejectedValue(new ApiError('Cannot reach the server at http://localhost:8000. Check that the backend is running', 0))
  wrap(<Upload />); await userEvent.upload(screen.getByLabelText('Data file'), file())
  expect(await screen.findByRole('alert')).toHaveTextContent(/Cannot reach the server/); expect(screen.queryByText('Analysis complete')).not.toBeInTheDocument()
})

test('upload: ambiguous column mapping must be confirmed before saving', async () => {
  h.api.mockResolvedValue([]); h.uploadForm.mockResolvedValue(preview(true)); wrap(<Upload />)
  await userEvent.upload(screen.getByLabelText('Data file'), file())
  const btn = await screen.findByRole('button', { name: /analyse & save/i }); expect(btn).toBeDisabled()
  await userEvent.click(screen.getByLabelText(/I checked that the product and price columns/i)); expect(btn).toBeEnabled()
})

test('upload: duplicate file is flagged and the user can open the existing dataset', async () => {
  h.api.mockResolvedValue([ds(3, 'Old')]); h.uploadForm.mockResolvedValue(preview(false, { id: 3, name: 'Old' })); wrap(<Upload />)
  await userEvent.upload(screen.getByLabelText('Data file'), file())
  expect(await screen.findByText(/already imported as “Old”/)).toBeInTheDocument()
})

test('upload: cancelling stops the import and saves nothing', async () => {
  h.api.mockResolvedValue([]); let sig: AbortSignal | undefined
  h.uploadForm.mockImplementation((_p: string, _f: FormData, o: any) => new Promise((_, rej) => { sig = o.signal; o.signal.addEventListener('abort', () => rej(new DOMException('x', 'AbortError'))) }))
  wrap(<Upload />); await userEvent.upload(screen.getByLabelText('Data file'), file())
  await userEvent.click(await screen.findByRole('button', { name: 'Cancel' }))
  expect(await screen.findByText(/Cancelled\. Nothing was saved/)).toBeInTheDocument(); expect(sig?.aborted).toBe(true)
})

test('dashboard: shows real analysis of the selected dataset and refreshes when switching datasets', async () => {
  h.api.mockImplementation(async (p: string) => p === '/datasets' ? [ds(1, 'Alpha'), ds(2, 'Beta')] : p === '/datasets/1/analysis' ? analysis(1, 'Alpha', 4) : p === '/datasets/2/analysis' ? analysis(2, 'Beta', 9) : [])
  wrap(<Dashboard />)
  expect(await screen.findByText('Product of Alpha')).toBeInTheDocument()
  await userEvent.selectOptions(screen.getAllByLabelText('Dataset')[0], '2')
  expect(await screen.findByText('Product of Beta')).toBeInTheDocument()
  expect(screen.queryByText('Product of Alpha')).not.toBeInTheDocument()
  expect(localStorage.getItem('sp_dataset')).toBe('2')                                    // selection survives navigation / refresh
})

test('dashboard: empty state when no dataset exists, and honest message when there is no price history', async () => {
  h.api.mockResolvedValue([]); const v = wrap(<Dashboard />)
  expect(await screen.findByText('No data yet')).toBeInTheDocument(); v.unmount()
  h.api.mockImplementation(async (p: string) => p === '/datasets' ? [ds(1, 'Alpha')] : analysis(1, 'Alpha', 1)); wrap(<Dashboard />)
  expect(await screen.findByText(/No price history: add dates/)).toBeInTheDocument()
})

test('dashboard: demo data is clearly labelled', async () => {
  h.api.mockImplementation(async (p: string) => p === '/datasets' ? [ds(1, 'Demo', { is_demo: true })] : { ...analysis(1, 'Demo', 1), is_demo: true, dataset: ds(1, 'Demo', { is_demo: true }) })
  wrap(<Dashboard />); expect((await screen.findAllByText('DEMO DATA')).length).toBeGreaterThan(0)
})

test('navigation: sidebar links switch pages through the animated outlet', async () => {
  h.api.mockImplementation(async (p: string) => p === '/datasets' ? [] : p === '/auth/me' ? { name: 'Tester' } : [])
  render(<MemoryRouter initialEntries={['/dashboard']}><PrefsProvider><ToastProvider><Routes><Route element={<AppLayout />}>
    <Route path="/dashboard" element={<p>dashboard page</p>} /><Route path="/upload" element={<p>upload page</p>} /></Route></Routes></ToastProvider></PrefsProvider></MemoryRouter>)
  expect(await screen.findByText('dashboard page')).toBeInTheDocument()
  await userEvent.click(within(screen.getByRole('navigation')).getByRole('link', { name: /upload & data/i }))
  expect(await screen.findByText('upload page')).toBeInTheDocument()
  await waitFor(() => expect(screen.queryByText('dashboard page')).not.toBeInTheDocument())
})
