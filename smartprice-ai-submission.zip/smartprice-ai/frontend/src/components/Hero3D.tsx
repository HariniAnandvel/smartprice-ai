import { Canvas, useFrame } from '@react-three/fiber'
import { Float, MeshDistortMaterial } from '@react-three/drei'
import { useRef } from 'react'
import type { Mesh } from 'three'

function Orb({ reduce }: { reduce: boolean }) {
  const ref = useRef<Mesh>(null)
  useFrame((s) => { if (ref.current && !reduce) { ref.current.rotation.y += .004; ref.current.position.x = s.pointer.x * .4; ref.current.position.y = s.pointer.y * .3 } })
  return <Float speed={reduce ? 0 : 2} floatIntensity={1.2}><mesh ref={ref}>
    <icosahedronGeometry args={[1.5, 3]} /><MeshDistortMaterial color="#6d5efc" emissive="#22d3ee" emissiveIntensity={.25} roughness={.15} metalness={.8} distort={reduce ? 0 : .3} speed={2} wireframe />
  </mesh></Float>
}

export default function Hero3D({ reduce }: { reduce: boolean }) {
  return <Canvas dpr={[1, 1.5]} camera={{ position: [0, 0, 5], fov: 50 }} aria-hidden>
    <ambientLight intensity={.6} /><pointLight position={[5, 5, 5]} intensity={40} color="#22d3ee" /><pointLight position={[-5, -3, 2]} intensity={30} color="#e879f9" />
    <Orb reduce={reduce} /></Canvas>
}
