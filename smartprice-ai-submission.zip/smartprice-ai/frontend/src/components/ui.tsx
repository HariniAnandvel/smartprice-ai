import { motion } from 'framer-motion'
import { useSimple } from './prefs'
import { AlertTriangle, Inbox } from 'lucide-react'
import type { ReactNode, ButtonHTMLAttributes } from 'react'

export const GlassCard = ({ children, className = '' }: { children: ReactNode; className?: string }) =>
  <div className={`glass rounded-2xl ${className}`}>{children}</div>

export const GradientText = ({ children }: { children: ReactNode }) => <span className="gradient-text">{children}</span>

export function GlassButton({ variant = 'primary', className = '', ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'ghost' }) {
  const v = variant === 'primary' ? 'bg-gradient-to-r from-sky-500 to-violet-500 text-white shadow-lg shadow-sky-500/20' : 'glass text-slate-100'
  return <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: .97 }}
    className={`rounded-xl px-5 py-3 font-semibold disabled:opacity-50 ${v} ${className}`} {...(p as any)} />
}

export function AnimatedBackground() {
  const reduce = useSimple()
  const blob = (c: string, pos: string) => <motion.div aria-hidden className={`absolute w-[40rem] h-[40rem] rounded-full blur-3xl opacity-25 ${c} ${pos}`}
    animate={reduce ? {} : { x: [0, 40, 0], y: [0, -30, 0] }} transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }} />
  return <div className="fixed inset-0 -z-10 overflow-hidden bg-midnight">
    {blob('bg-sky-500', '-top-40 -left-40')}{blob('bg-violet-600', 'top-1/3 -right-48')}{blob('bg-fuchsia-600', '-bottom-48 left-1/4')}</div>
}

export function MetricCard({ label, value, hint, icon }: { label: string; value: string; hint?: string; icon?: ReactNode }) {
  return <GlassCard className="p-5"><div className="flex justify-between text-slate-400 text-sm">{label}{icon}</div>
    <div className="text-3xl font-bold mt-2">{value}</div>{hint && <div className="text-xs text-slate-400 mt-1">{hint}</div>}</GlassCard>
}

export const Skeleton = ({ className = 'h-24' }: { className?: string }) => <div className={`glass rounded-2xl animate-pulse ${className}`} />

export const EmptyState = ({ title, text, action }: { title: string; text: string; action?: ReactNode }) =>
  <GlassCard className="p-10 text-center"><Inbox className="mx-auto mb-3 text-cyan-300" /><h3 className="font-semibold">{title}</h3>
    <p className="text-slate-400 text-sm mt-1 mb-4">{text}</p>{action}</GlassCard>

export const ErrorState = ({ message, retry }: { message: string; retry?: () => void }) =>
  <GlassCard className="p-8 text-center" ><AlertTriangle className="mx-auto mb-3 text-rose-400" /><p role="alert">{message}</p>
    {retry && <GlassButton variant="ghost" className="mt-4" onClick={retry}>Retry</GlassButton>}</GlassCard>
