import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { MotionConfig, useReducedMotion } from 'framer-motion'
import { api, getToken } from '../services/api'

export type Prefs = { theme?: 'dark' | 'light'; reduced_motion?: boolean; notify_in_app?: boolean }
const Ctx = createContext<{ prefs: Prefs; setPrefs: (p: Prefs) => void; simple: boolean }>({ prefs: {}, setPrefs: () => {}, simple: false })
export const usePrefs = () => useContext(Ctx)
export const useSimple = () => usePrefs().simple

export function PrefsProvider({ children }: { children: ReactNode }) {
  const sys = !!useReducedMotion()
  const [prefs, set] = useState<Prefs>(() => { try { return JSON.parse(localStorage.getItem('sp_prefs') || '{}') } catch { return {} } })
  const setPrefs = useCallback((p: Prefs) => { set(p); try { localStorage.setItem('sp_prefs', JSON.stringify(p)) } catch { /* storage unavailable */ } }, [])
  useEffect(() => { if (getToken()) api('/settings').then(s => setPrefs(s.prefs || {})).catch(() => {}) }, [setPrefs])
  const simple = sys || !!prefs.reduced_motion
  useEffect(() => { document.documentElement.dataset.theme = prefs.theme || 'dark'; document.documentElement.dataset.motion = simple ? 'simple' : 'full' }, [prefs.theme, simple])
  return <Ctx.Provider value={{ prefs, setPrefs, simple }}><MotionConfig reducedMotion={simple ? 'always' : 'user'}>{children}</MotionConfig></Ctx.Provider>
}
