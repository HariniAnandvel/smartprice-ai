import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { api } from '../services/api'
import { GlassButton, GlassCard } from './ui'
import { useDatasets, DatasetSelect } from './datasets'

const ToastCtx = createContext<(m: string, bad?: boolean) => void>(() => {})
export const useToast = () => useContext(ToastCtx)
export function ToastProvider({ children }: { children: ReactNode }) {
  const [t, setT] = useState<{ m: string; bad?: boolean } | null>(null)
  const show = useCallback((m: string, bad?: boolean) => { setT({ m, bad }); setTimeout(() => setT(null), 3500) }, [])
  return <ToastCtx.Provider value={show}>{children}
    <div aria-live="polite" className="fixed bottom-5 right-5 z-50"><AnimatePresence>{t && <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
      className={`glass rounded-xl px-4 py-3 ${t.bad ? 'text-rose-300' : 'text-emerald-300'}`}>{t.m}</motion.div>}</AnimatePresence></div></ToastCtx.Provider>
}

export function ConfirmDialog({ text, onYes, onNo }: { text: string; onYes: () => void; onNo: () => void }) {
  return <div role="dialog" aria-modal className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4"><GlassCard className="p-6 max-w-sm">
    <p className="mb-5">{text}</p><div className="flex gap-3 justify-end"><GlassButton variant="ghost" onClick={onNo}>Cancel</GlassButton><GlassButton onClick={onYes}>Confirm</GlassButton></div></GlassCard></div>
}

export function useProducts() {
  const { selectedId, version, dq } = useDatasets()
  const [items, setItems] = useState<any[] | null>(null); const [err, setErr] = useState('')
  const [sp] = useSearchParams(); const q = (sp.get('q') || '').toLowerCase()
  const [id, setId] = useState<number | null>(null)
  useEffect(() => {
    setItems(null); setErr('')
    api(`/products?size=100${selectedId != null ? `&dataset_id=${selectedId}` : ''}`).then(r => { setItems(r.items); const m = r.items.find((p: any) => q && p.name.toLowerCase().includes(q)); setId((m || r.items[0])?.id ?? null) }).catch(e => setErr(e.message))
  }, [q, selectedId, version])
  const Select = <label className="text-sm text-slate-300">Product <select className="input mt-1" value={id ?? ''} onChange={e => setId(Number(e.target.value))}>
    {(items || []).map(p => <option key={p.id} value={p.id} className="bg-slate-900">{p.name}{p.is_demo ? ' (demo)' : ''}</option>)}</select></label>
  return { items, id, err, Select, dq }
}

export function TopBar({ onLogout }: { onLogout: () => void }) {
  const nav = useNavigate(); const loc = useLocation(); const [n, setN] = useState<any[]>([]); const [open, setOpen] = useState<'' | 'n' | 'p'>(''); const [me, setMe] = useState<any>({})
  useEffect(() => { api('/notifications').then(setN).catch(() => {}); api('/auth/me').then(setMe).catch(() => {}) }, [])
  const unread = n.filter(x => !x.read).length
  const mark = async (id: number) => { await api(`/notifications/${id}/read`, { method: 'POST' }); setN(n.map(x => x.id === id ? { ...x, read: true } : x)) }
  return <div className="flex items-center gap-3 mb-4">
    <form className="flex-1" role="search" onSubmit={e => { e.preventDefault(); const q = String(new FormData(e.currentTarget).get('q') || '').trim(); const ok = ['/analytics', '/competitors', '/insights', '/alerts', '/reports']; nav(`${ok.includes(loc.pathname) ? loc.pathname : '/analytics'}${q ? `?q=${encodeURIComponent(q)}` : ''}`) }}><input name="q" aria-label="Search products" placeholder="Search products…" className="input" /></form>
    <DatasetSelect className="hidden sm:block w-64" />
    <div className="relative"><button className="glass rounded-xl px-3 py-3" aria-label="Notifications" onClick={() => setOpen(open === 'n' ? '' : 'n')}>🔔{unread > 0 && <b className="ml-1 text-cyan-300">{unread}</b>}</button>
      {open === 'n' && <div className="glass absolute right-0 mt-2 w-80 rounded-2xl p-3 z-30 max-h-80 overflow-auto">{n.length ? n.map(x => <button key={x.id} onClick={() => mark(x.id)} className={`block w-full text-left text-sm py-2 border-b border-white/5 ${x.read ? 'text-slate-500' : ''}`}>{x.message}</button>) : <p className="text-sm text-slate-400">No notifications.</p>}</div>}</div>
    <div className="relative"><button className="glass rounded-xl px-4 py-3" onClick={() => setOpen(open === 'p' ? '' : 'p')}>{me.name || 'Profile'}</button>
      {open === 'p' && <div className="glass absolute right-0 mt-2 w-48 rounded-2xl p-2 z-30"><a className="block px-3 py-2 hover:bg-white/10 rounded-lg" href="/settings">Settings</a><button className="block w-full text-left px-3 py-2 hover:bg-white/10 rounded-lg" onClick={onLogout}>Log out</button></div>}</div></div>
}
