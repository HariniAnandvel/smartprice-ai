import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { api, getToken } from '../services/api'

export type DS = { id: number; name: string; filename?: string | null; status: string; is_demo: boolean; rows_total: number; rows_valid: number; rows_skipped: number; created_at: string; file_type?: string | null }
type Ctx = { datasets: DS[] | null; selectedId: number | null; selected: DS | null; select: (id: number | null) => void; refresh: () => Promise<DS[]>; version: number; error: string; dq: string }
const C = createContext<Ctx>({ datasets: null, selectedId: null, selected: null, select: () => {}, refresh: async () => [], version: 0, error: '', dq: '' })
export const useDatasets = () => useContext(C)

/** One source of truth for "which dataset is the app looking at". Persisted, validated against the backend list,
 *  and bumps `version` after every refresh so pages re-fetch instead of showing stale charts. */
export function DatasetProvider({ children }: { children: ReactNode }) {
  const [datasets, setDatasets] = useState<DS[] | null>(null); const [error, setError] = useState(''); const [version, setVersion] = useState(0)
  const [selectedId, setSel] = useState<number | null>(() => { try { const v = localStorage.getItem('sp_dataset'); return v ? Number(v) : null } catch { return null } })
  const refresh = useCallback(async () => {
    try {
      const d = await api<DS[]>('/datasets'); setDatasets(d); setError('')
      setSel(cur => (d.some(x => x.id === cur) ? cur : d[0]?.id ?? null))   // a deleted/inaccessible dataset falls back gracefully
      setVersion(v => v + 1); return d
    } catch (e: any) { setError(e.message); setDatasets([]); return [] }
  }, [])
  useEffect(() => { if (getToken()) refresh() }, [refresh])
  useEffect(() => { try { selectedId == null ? localStorage.removeItem('sp_dataset') : localStorage.setItem('sp_dataset', String(selectedId)) } catch { /* storage unavailable */ } }, [selectedId])
  const selected = datasets?.find(d => d.id === selectedId) ?? null
  const dq = selectedId != null ? `?dataset_id=${selectedId}` : ''
  return <C.Provider value={{ datasets, selectedId, selected, select: setSel, refresh, version, error, dq }}>{children}</C.Provider>
}

export const StatusBadge = ({ s, demo }: { s: string; demo?: boolean }) => {
  const m: any = { completed: 'bg-emerald-400/15 text-emerald-300', partial: 'bg-amber-400/15 text-amber-300', failed: 'bg-rose-400/15 text-rose-300' }
  return <span className="inline-flex gap-1.5">{demo && <span className="text-[11px] rounded-full bg-fuchsia-400/20 text-fuchsia-200 px-2 py-0.5 font-semibold tracking-wide">DEMO DATA</span>}
    <span className={`text-[11px] rounded-full px-2 py-0.5 ${m[s] || 'bg-white/10'}`}>{s}</span></span>
}

export function DatasetSelect({ className = '' }: { className?: string }) {
  const { datasets, selectedId, select } = useDatasets()
  if (!datasets?.length) return null
  return <label className={`text-sm text-slate-300 ${className}`}><span className="sr-only">Dataset</span>
    <select aria-label="Dataset" className="input py-2.5" value={selectedId ?? ''} onChange={e => select(e.target.value ? Number(e.target.value) : null)}>
      {datasets.map(d => <option key={d.id} value={d.id} className="bg-slate-900">{d.is_demo ? '[DEMO] ' : ''}{d.name} · {d.rows_valid} rows</option>)}</select></label>
}
