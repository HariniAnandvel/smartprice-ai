export const BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:8000'
export const getToken = () => localStorage.getItem('sp_token')
export const setToken = (t: string | null) => (t ? localStorage.setItem('sp_token', t) : localStorage.removeItem('sp_token'))

/** Error carrying the HTTP status and the raw `detail` object the backend sent. status 0 = backend unreachable. */
export class ApiError extends Error {
  status: number; data: any
  constructor(message: string, status: number, data?: any) { super(message); this.status = status; this.data = data }
}

export function detailMessage(d: any, status: number): string {
  const x = d?.detail
  if (Array.isArray(x)) return x.map((i: any) => i.msg).join(', ')
  if (x && typeof x === 'object') return x.message || `Request failed (${status})`
  return x || `Request failed (${status})`
}
const unreachable = () => new ApiError(`Cannot reach the server at ${BASE}. Check that the backend is running (uvicorn app.main:app --reload).`, 0)
const onUnauthorized = (status: number) => { if (status === 401 && getToken()) { setToken(null); window.location.href = '/login' } }

export async function api<T = any>(path: string, opts: RequestInit & { form?: Record<string, string> } = {}): Promise<T> {
  const headers: Record<string, string> = {}
  const t = getToken(); if (t) headers.Authorization = `Bearer ${t}`
  let body = opts.body
  if (opts.form) { body = new URLSearchParams(opts.form) }
  else if (body && !(body instanceof FormData)) headers['Content-Type'] = 'application/json'
  let res: Response
  try { res = await fetch(BASE + '/api' + path, { ...opts, headers: { ...headers, ...(opts.headers as any) }, body }) }
  catch (e: any) { if (e?.name === 'AbortError') throw e; throw unreachable() }
  onUnauthorized(res.status)
  if (!res.ok) {
    const d = await res.json().catch(() => ({}))
    throw new ApiError(detailMessage(d, res.status), res.status, d?.detail)
  }
  return res.status === 204 ? (undefined as T) : res.json()
}

/** multipart upload with REAL byte-level progress (fetch cannot report upload progress) and cancellation. */
export function uploadForm<T = any>(path: string, form: FormData, o: { onProgress?: (fraction: number) => void; onSent?: () => void; signal?: AbortSignal } = {}): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', BASE + '/api' + path)
    const t = getToken(); if (t) xhr.setRequestHeader('Authorization', `Bearer ${t}`)
    xhr.upload.onprogress = e => { if (e.lengthComputable) o.onProgress?.(e.loaded / e.total) }
    xhr.upload.onload = () => o.onSent?.()
    xhr.onerror = () => reject(unreachable())
    xhr.onabort = () => reject(new DOMException('Upload cancelled', 'AbortError'))
    xhr.onload = () => {
      let d: any = null; try { d = JSON.parse(xhr.responseText) } catch { /* not JSON */ }
      onUnauthorized(xhr.status)
      if (xhr.status >= 200 && xhr.status < 300) resolve(d as T)
      else reject(new ApiError(detailMessage(d, xhr.status), xhr.status, d?.detail))
    }
    if (o.signal) { if (o.signal.aborted) return reject(new DOMException('Upload cancelled', 'AbortError')); o.signal.addEventListener('abort', () => xhr.abort()) }
    xhr.send(form)
  })
}
