import { Suspense, lazy } from 'react'
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { PrefsProvider, useSimple } from './components/prefs'
import { ToastProvider } from './components/extra'
import { AnimatedBackground, Skeleton } from './components/ui'
import AppLayout from './layouts/AppLayout'
import { getToken } from './services/api'

const Landing = lazy(() => import('./pages/Landing'))
const Auth = lazy(() => import('./pages/Auth'))
const Dashboard = lazy(() => import('./pages/Dashboard'))
const Upload = lazy(() => import('./pages/Upload'))
const Scrape = lazy(() => import('./pages/Scrape'))
const Analytics = lazy(() => import('./pages/Analytics'))
const Competitors = lazy(() => import('./pages/Competitors'))
const Insights = lazy(() => import('./pages/Insights'))
const Alerts = lazy(() => import('./pages/Alerts'))
const Reports = lazy(() => import('./pages/Reports'))
const Settings = lazy(() => import('./pages/Settings'))

function Page({ children }: { children: React.ReactNode }) {
  const reduce = useSimple()
  return <motion.div initial={reduce ? false : { opacity: 0, y: 14, filter: 'blur(6px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
    exit={reduce ? undefined : { opacity: 0, y: -10 }} transition={{ duration: .3, ease: [.22, 1, .36, 1] }}>{children}</motion.div>
}
const Guard = ({ children }: { children: React.ReactNode }) => getToken() ? <>{children}</> : <Navigate to="/login" replace />

function Routed() {
  const loc = useLocation()
  return <AnimatePresence mode="wait"><Suspense fallback={<div className="p-8"><Skeleton className="h-64" /></div>}>
    <Routes location={loc} key={['/', '/login', '/register'].includes(loc.pathname) ? loc.pathname : 'app'}>
      <Route path="/" element={<Page><Landing /></Page>} />
      <Route path="/login" element={<Page><Auth mode="login" /></Page>} />
      <Route path="/register" element={<Page><Auth mode="register" /></Page>} />
      <Route element={<Guard><AppLayout /></Guard>}><Route path="/dashboard" element={<Dashboard />} /><Route path="/upload" element={<Upload />} /><Route path="/scrape" element={<Scrape />} /><Route path="/analytics" element={<Analytics />} /><Route path="/competitors" element={<Competitors />} /><Route path="/insights" element={<Insights />} /><Route path="/alerts" element={<Alerts />} /><Route path="/reports" element={<Reports />} /><Route path="/settings" element={<Settings />} /></Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes></Suspense></AnimatePresence>
}
export default function App() { return <BrowserRouter><PrefsProvider><ToastProvider><AnimatedBackground /><Routed /></ToastProvider></PrefsProvider></BrowserRouter> }
