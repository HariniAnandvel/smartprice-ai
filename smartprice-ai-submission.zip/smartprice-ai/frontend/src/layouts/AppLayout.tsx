import { NavLink, useLocation, useNavigate, useOutlet } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { LayoutDashboard, LogOut, PanelLeftClose, PanelLeft, Database, UploadCloud, LineChart, Users, Sparkles, BellRing, FileText, Settings } from 'lucide-react'
import { TopBar } from '../components/extra'
import { Suspense, useState } from 'react'
import { DatasetProvider } from '../components/datasets'
import { Skeleton } from '../components/ui'
import { useSimple } from '../components/prefs'
import { setToken } from '../services/api'

const links = [{ to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }, { to: '/upload', label: 'Upload & data', icon: UploadCloud }, { to: '/scrape', label: 'Collection', icon: Database }, { to: '/analytics', label: 'Trends', icon: LineChart }, { to: '/competitors', label: 'Competitors', icon: Users }, { to: '/insights', label: 'AI Insights', icon: Sparkles }, { to: '/alerts', label: 'Alerts', icon: BellRing }, { to: '/reports', label: 'Reports', icon: FileText }, { to: '/settings', label: 'Settings', icon: Settings }]

function Transitioned() {
  const loc = useLocation(); const outlet = useOutlet(); const simple = useSimple()
  return <AnimatePresence mode="wait" initial={false}><motion.div key={loc.pathname}
    initial={simple ? false : { opacity: 0, y: 16, scale: .995, filter: 'blur(6px)' }} animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
    exit={simple ? { opacity: 0 } : { opacity: 0, y: -8, filter: 'blur(4px)' }} transition={{ duration: .26, ease: [.22, 1, .36, 1] }}>
    <Suspense fallback={<div className="grid gap-4"><Skeleton className="h-28" /><Skeleton className="h-72" /></div>}>{outlet}</Suspense></motion.div></AnimatePresence>
}

export default function AppLayout() {
  const [open, setOpen] = useState(true); const nav = useNavigate()
  return <DatasetProvider><div className="flex min-h-screen">
    <motion.aside animate={{ width: open ? 230 : 72 }} transition={{ duration: .25 }} className="glass m-3 rounded-2xl p-3 flex flex-col shrink-0">
      <button aria-label="Toggle sidebar" className="p-2 self-end text-slate-300" onClick={() => setOpen(!open)}>{open ? <PanelLeftClose /> : <PanelLeft />}</button>
      <div className="px-2 py-3 font-bold gradient-text whitespace-nowrap overflow-hidden">{open ? 'SmartPrice AI' : 'SP'}</div>
      <nav className="flex-1 space-y-1">{links.map(({ to, label, icon: I }) =>
        <NavLink key={to} to={to} className={({ isActive }) => `flex items-center gap-3 rounded-xl px-3 py-2 ${isActive ? 'bg-white/10 text-cyan-300' : 'text-slate-300 hover:bg-white/5'}`}>
          <I size={20} />{open && <span>{label}</span>}</NavLink>)}</nav>
      <button className="flex items-center gap-3 px-3 py-2 text-slate-300 hover:text-rose-300" onClick={() => { setToken(null); nav('/login') }}><LogOut size={20} />{open && 'Log out'}</button>
    </motion.aside>
    <main className="flex-1 p-4 md:p-6 min-w-0"><TopBar onLogout={() => { setToken(null); nav('/login') }} /><Transitioned /></main></div></DatasetProvider>
}
