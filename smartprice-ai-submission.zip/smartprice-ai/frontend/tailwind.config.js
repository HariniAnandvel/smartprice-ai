export default { content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { midnight: '#070b1f' }, fontFamily: { sans: ['Inter','system-ui','sans-serif'] } } } }
